let au = null;
let on = false;
let failed = false;

const snd = document.getElementById('snd');

const fail = () => {
  failed = true;
  on = false;
  if (snd) {
    snd.textContent = 'تعذر تشغيل الصوت';
    snd.setAttribute('aria-pressed', 'false');
  }
};

if (snd) {
  snd.addEventListener('click', async () => {
    if (!au) {
      au = new Audio('./assets/audio/sway.mp3');
      au.loop = true;
      au.volume = 0.55;
      au.addEventListener('error', fail);
    }

    if (failed) {
      failed = false;
      au = new Audio('./assets/audio/sway.mp3');
      au.loop = true;
      au.volume = 0.55;
      au.addEventListener('error', fail);
    }

    try {
      if (au.paused) {
        await au.play();
        on = true;
        snd.textContent = 'SOUND ON';
      } else {
        au.pause();
        on = false;
        snd.textContent = 'SOUND OFF';
      }

      snd.setAttribute('aria-pressed', String(on));
    } catch (e) {
      console.error('Audio playback error:', e);
      snd.textContent = 'تعذر تشغيل الصوت';
    }
  });
}