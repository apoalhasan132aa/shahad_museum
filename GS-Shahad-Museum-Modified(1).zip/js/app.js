/* UI: النوافذ (المعروضات + الألغاز) */
const UI=(()=>{
 const m=document.getElementById('modal'),box=document.getElementById('mbox'),$=id=>document.getElementById(id);let onClose=null;
 function show(html,cb){box.innerHTML=html;m.classList.add('on');onClose=cb;box.querySelector('[data-x]').focus()}
 function close(){m.classList.remove('on');box.innerHTML='';const f=onClose;onClose=null;if(f)f()}
 m.addEventListener('click',e=>{if(e.target===m||e.target.closest('[data-x]'))close()});
 addEventListener('keydown',e=>{if(e.key==='Escape'&&m.classList.contains('on'))close()});
 const X='<button data-x class="x" aria-label="إغلاق">×</button>';
 function exhibit(x,cb){const ph=x.img===undefined?'':`<div class="ph" role="button" tabindex="0" aria-label="تكبير الصورة">${x.img?`<img src="${x.img}" alt="${x.title}" loading="lazy" onerror="this.outerHTML='<span>ADD PHOTO</span>'">`:'<span>ADD PHOTO</span>'}</div>`;
 show(X+ph+`<h3>${x.title}</h3>${x.date?`<p style="color:#cdb6ff;font-size:16px;letter-spacing:.2em">${x.date}</p>`:''}<p style="white-space:pre-line">${x.text}</p>${x.audio?`<audio controls preload="none" src="${x.audio}" style="width:100%;margin-top:10px"></audio>`:''}${x.video?`<video controls playsinline preload="none" src="${x.video}" style="width:100%;margin-top:10px;border-radius:10px"></video>`:''}`,cb);
 const ph2=box.querySelector('.ph');if(ph2)ph2.addEventListener('click',()=>ph2.classList.toggle('full'))}

 function puzzle(p,done,cb){show(X+`<h3>${p.title}</h3><p>${p.q}</p><input id="pa" placeholder="${p.ph}" autocomplete="off" aria-label="الجواب"><button id="pc" class="go">${p.check}</button><p id="pf" aria-live="polite"></p>`,cb);
  const f=()=>{const ok=Puzzles.check($('pa').value,p.answers);$('pf').textContent=ok?p.ok:p.wrong;if(ok){$('pa').disabled=$('pc').disabled=true;setTimeout(()=>{close();done()},1400)}};
  $('pc').addEventListener('click',f);$('pa').addEventListener('keydown',e=>{if(e.key==='Enter')f()})}
 function recording(cfg,done){
  const v=document.createElement('div');v.style.cssText='position:fixed;inset:0;z-index:8;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:18px;padding:24px;box-sizing:border-box;background:rgba(5,3,10,.9);backdrop-filter:blur(8px);text-align:center;opacity:0;transition:opacity 1.2s';
  v.innerHTML=`<canvas width="320" height="110" style="width:min(320px,86%)"></canvas><p style="font-family:Amiri,serif;font-size:22px;margin:0;color:#eadcf0">${cfg.caption}</p><div style="width:min(280px,80%);height:3px;background:rgba(255,255,255,.15)"><i style="display:block;height:100%;width:0;background:#ff8fcf"></i></div><button class="go" style="display:none"></button>`;
  document.body.appendChild(v);requestAnimationFrame(()=>v.style.opacity=1);
  const cv=v.querySelector('canvas'),x=cv.getContext('2d'),bar=v.querySelector('i'),btn=v.querySelector('button'),cap=v.querySelector('p'),a=new Audio(cfg.src);
  let on=true,fin=false,prev=null;const hasBg=()=>typeof au!=='undefined'&&au;
  const end=()=>{if(fin)return;fin=true;on=false;a.pause();if(hasBg()&&prev!==null)au.volume=prev;v.style.opacity=0;setTimeout(()=>{v.remove();done()},1200)};
  const draw=t=>{if(!on)return;x.clearRect(0,0,320,110);x.strokeStyle='#ff8fcf';x.lineWidth=2;x.shadowColor='#ff8fcf';x.shadowBlur=10;x.beginPath();const amp=a.paused?3:26;for(let k=0;k<=320;k+=2){const y=55+Math.sin(k*.07+t/180)*Math.sin(k*.02+t/700)*amp+Math.sin(k*.3+t/60)*amp*.2;k?x.lineTo(k,y):x.moveTo(k,y)}x.stroke();requestAnimationFrame(draw)};requestAnimationFrame(draw);
  const manual=(txt,fn)=>{btn.textContent=txt;btn.style.display='block';btn.onclick=fn};
  a.addEventListener('timeupdate',()=>{if(a.duration)bar.style.width=a.currentTime/a.duration*100+'%'});
  a.addEventListener('ended',end);a.addEventListener('playing',()=>manual(cfg.skip,end));
  a.addEventListener('error',()=>{cv.style.opacity=.3;cap.textContent=cfg.missing;manual(cfg.cont,end)});
  if(hasBg()){prev=au.volume;au.volume=Math.min(prev,.12)}
  a.play().catch(()=>{if(a.error)return;manual(cfg.play,()=>{a.play().catch(()=>{})})})}
 return{exhibit,puzzle,close,recording}})();
