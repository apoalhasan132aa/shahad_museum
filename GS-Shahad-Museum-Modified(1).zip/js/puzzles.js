const Puzzles={
  norm(s){return s.toLowerCase().replace(/[\u064B-\u0652\u0640]/g,'').replace(/[أإآ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه').replace(/\s+/g,'').replace(/^ال/,'')},
  check(v,list){const n=this.norm(v);return !!n&&list.some(a=>n===this.norm(a))}
};
