/* ===== CONTENT — عدّلي النصوص من هنا (سيصبح content.js لاحقًا) ===== */
const CONTENT={
  ar:'متحف شهد', en:'SHAHAD MUSEUM', tag:'GS — A PRIVATE MUSEUM',
  next:'القسم الثاني', nextSub:'قريبًا…', replay:'إعادة المشهد',
  audio:'assets/audio/sway.mp3',
  garden:{
    title:'حديقتها', sub:'THE GARDEN OF HER', hint:'المسي المعروضات', lock:'شوفي المعروضات الثلاثة أول',
    exhibits:[
      {id:'rose',title:'THE ROSE',text:'شهد لو چانت ورده',img:'assets/images/rose.jpg'},
      {id:'cat',title:'THE CAT',text:'شهد لو چانت بزونه',img:'assets/images/cat.jpg'},
      {id:'quiet',title:'THE QUIET',text:'عن حبها للهدوء والأماكن الطبيعية.',img:'assets/images/quite.png'}
    ],
    puzzle:{title:'THE GATE',q:'شنو الشي اللي كل ما كان أبسط، صار أحلى؟',answers:['الكياتة','كياتة','الحب'],ok:'ACCESS GRANTED',wrong:'قريبة… جربي مرة ثانية',check:'تحقق',ph:'اكتبي الجواب'},
    next:{t:'القاعة التالية',s:'THE DETAILS — قريبًا…'}
  },
  details:{
    title:'التفاصيل', sub:'THE DETAILS', hint:'المسي الإطارات', lock:'شوفي الإطارات السبعة أول',
    exhibits:[
      {id:'cute',title:'THE CUTE ONE',text:'هيه شلون كيوت',img:'assets/images/cute.jpg'},
      {id:'beauty',title:'THE BEAUTY',text:'هيه شكد حلوة',img:'assets/images/beauty.jpg'},
      {id:'real',title:'THE REAL ONE',text:'و حلوة حتى من تطلع بواقعيتها',img:'assets/images/real.jpg'},
      {id:'shy',title:'THE SHY ONE',text:'عن جمال خجلها',img:'assets/images/shy.jpg'},
      {id:'voice',title:'HER VOICE',text:'تاثير صوتها',img:'assets/images/voice.jpg'},
      {id:'style',title:'HER STYLE',text:'عن أسلوبها وذوقها.',img:'assets/images/style.jpg'},
      {id:'talk',title:'THE WAY SHE TALKS',text:'شكد حلوة و كيوت من تحجي',img:'assets/images/talk.jpg'}
    ],
    puzzle:{title:'THE DOOR',q:'شنو الشي اللي ممكن ما ينتبهوله الناس، بس أنت تنتبهله بيها؟',answers:['كياتتها','الكياتة','كياتة'],ok:'ACCESS GRANTED',wrong:'قريبة… جربي مرة ثانية',check:'تحقق',ph:'اكتبي الجواب'},
    next:{t:'القاعة التالية',s:'THE CALLS — قريبًا…'}
  },
  calls:{
    title:'المكالمات', sub:'THE CALLS', hint:'المسي المحطات', lock:'شوفي المكالمات الثلاث أول',
    exhibits:[
      {id:'c1',title:'CALL 001',date:'اتذكر بوكتها من التسعه لهدعش',text:'اول مكالمه جانت تخبل و شته',img:'assets/images/c1.jpg',audio:''},
      {id:'c2',title:'CALL 002',date:'هنا 07/31 ساعه 9:50',text:'جنا ثنينا متوترين بس تخبلل',img:'assets/images/c2.png',audio:''},
      {id:'c3',title:'CALL 003',date:'هنا 08/02 ساعه 11:41',text:'هنا قل التوتر و احسن لان فتحت صوره',img:'assets/images/c3.png',audio:''}
    ],
    puzzle:{title:'THE LINE',q:'شنو الشي اللي ينتهي بمجرد ما ينقطع، بس أثره يبقى؟',answers:['المكالمة','مكالمة'],ok:'ACCESS GRANTED',wrong:'قريبة… جربي مرة ثانية',check:'تحقق',ph:'اكتبي الجواب'},
    recording:{src:'assets/audio/calls-final.mp3',caption:'تسجيل خاص…',missing:'اسمعيه كله بيبي',play:'اضغطي للتشغيل',skip:'تخطّي',cont:'متابعة'},
    next:{t:'القاعة التالية',s:'THE TREND ARCHIVE — قريبًا…'}
  },
  trends:{
    title:'الترندات', sub:'THE TREND ARCHIVE', hint:'المسي الشاشات', lock:'شوفي الترندات الأربعة أول',
    exhibits:[
      {id:'t1',title:'TREND 001',date:'جان منتشر ترند tv girl',text:'اول ترند النا و يخبللل رسمج يموت فديته',img:'assets/images/t1.jpg',video:''},
      {id:'t2',title:'TREND 002',date:'هنا جان منتشر ترند ماينكرافت',text:'يخبللل اني صممته بس نشرتيه كيوتت',img:'assets/images/t2.jpg',video:''},
      {id:'t3',title:'TREND 003',date:'هذا ذاك اليوم صار',text:'هذا هوة مو ترند بس اني احسبه بكيفي',img:'assets/images/t3.jpg',video:''},
      {id:'t4',title:'TREND 004',date:'هاي ترند مال تطقيم و ينشرون يخبل',text:'طبعا جان و بعده كل تطقيماتج يخبلن',img:'assets/images/t4.jpg',video:''}
    ],
    puzzle:{title:'THE ARCHIVE KEY',q:'شنو الشي اللي يصير أحلى لما نسويه سوه؟',answers:['الترند','الترندات','ترند','ترندات'],ok:'ACCESS GRANTED',wrong:'قريبة… جربي مرة ثانية',check:'تحقق',ph:'اكتبي الجواب'},
    next:{t:'القاعة التالية',s:"PLACES WE HAVEN'T BEEN — قريبًا…"}
  },
  places:{
    title:'الأماكن', sub:"PLACES WE HAVEN'T BEEN", hint:'المسي الدبابيس', lock:'شوفي الأماكن الأربعة أول',
    /* lon/lat = موقع الدبوس على الكرة — غيّريه لأي مكان تحبينه */
    exhibits:[
      {id:'p1',title:'DESTINATION UNKNOWN',lon:25,lat:50,text:'مكان ما رحنا له بعد…\nبس يمكن يومًا من الأيام نروح هناك و نمشي سوه',img:'assets/images/p1.jpg'},
      {id:'p2',title:'DESTINATION UNKNOWN',lon:100,lat:15,text:'مكان ما رحنا له بعد…\nبس يمكن يومًا من الأيام نكعد بهذا المكاني الهادء و بس اني و انتي ',img:'assets/images/p2.jpg'},
      {id:'p3',title:'DESTINATION UNKNOWN',lon:-100,lat:35,text:'مكان ما رحنا له بعد…\nبس يومًا من الأيام نروحله و نستكشف هيج اماكن وحدنا ',img:'assets/images/p3.jpg'},
      {id:'p4',title:'DESTINATION UNKNOWN',lon:-55,lat:-15,text:'مكان ما رحنا له بعد…\nبس يمكن يومًا من الأيام نمشي بنص هذا الجمال وحدنا',img:'assets/images/p4.jpg'}
    ],
    puzzle:{title:'DEPARTURES',q:'شنو الشي اللي ما رحنا له بعد، بس نحلم نكون فيه سوا؟',answers:['المكان','مكان','المستقبل','مستقبل'],ok:'ACCESS GRANTED',wrong:'قريبة… جربي مرة ثانية',check:'تحقق',ph:'اكتبي الجواب'},
    next:{t:'القاعة التالية',s:'THE MIRROR ROOM'}
  },
  mirror:{
    title:'THE MIRROR ROOM',
    sub:'الغرفة التي رأت شهد كما هي',
    hint:'REFLECTIONS DISCOVERED',
    lock:'بقيت بعض التفاصيل التي لم تريها بعد.',
    prompt:'تأمّلي هذه المرآة',
    nextBtn:'التالي', closeBtn:'إغلاق', doneBtn:'إنهاء الغرفة',
    mirrors:[
      {id:'m1',title:'THE FIRST GLANCE',kind:'quote',
       quote:'«بعض الوجوه لا تحتاج إلى أن تبحث عن الجمال؛ يكفي أن تظهر، فيصبح للجمال وجهٌ يُعرَف به.»',
       desc:'لم يكن الأمر ملامح جميلة فحسب؛ بل ذلك الحضور الذي يجعل التفاصيل العادية تبدو مختلفة.'},
      {id:'m2',title:'THE LITTLE DETAILS',kind:'list',
       items:['ضحكتكِ، حين تأتي بعفويتها.','خجلكِ الذي يمنح اللحظات طابعًا خاصًا.','طريقتكِ في الكلام، حتى حين لا تقصدين أن تكوني مميزة.','عفويتكِ وواقعيتكِ، بعيدًا عن التصنّع.','تلك الكياتة التي لا تحتاج إلى تفسير.']},
      {id:'m3',title:'THE WAY YOU ARE',kind:'traits',
       items:[['جمالكِ','ليس في الملامح وحدها، بل في حضوركِ كله.'],['كياتتكِ','ذلك الأسلوب الذي لا يُشبه أحدًا.'],['خجلكِ','الذي يجعل اللحظات أصدق.'],['عفويتكِ','تفاصيل صغيرة لا تتكرر.'],['أسلوبكِ في الكلام','كلماتكِ تترك أثرًا يبقى.'],['واقعيتكِ','جميلة بلا تكلّف.'],['طريقتكِ في التعبير','تعبّرين عن مشاعركِ بطريقتكِ الخاصة.']]},
      {id:'m4',title:'THE UNSEEN SIDE',kind:'stages',
       items:['«أحيانًا، لا يرى الإنسان في نفسه كل ما يراه فيه شخصٌ آخر.»','«قد تعتادين على تفاصيلكِ حتى تظني أنها عادية، بينما تكون هي بالذات ما يجعل حضوركِ مختلفًا.»','«لا أريدكِ أن تري نفسكِ بعينيّ بدلًا من عينيكِ؛ أريدكِ فقط أن تعرفي أن هناك من يرى فيكِ أشياء جميلة تستحق أن تريها أنتِ أيضًا.»']},
      {id:'m5',title:'THE FINAL MIRROR',kind:'final',final:true,
       quote:'«ولو استطعتُ أن أمنحكِ مرآةً واحدة، لما أردتُ لها أن تُريكِ وجهكِ فقط؛ أردتُها أن تُريكِ كم من الجمال تسكنه التفاصيل التي اعتدتِ عليها.»',
       letter:'يا شهد، هذه المرايا لا تصنع جمالًا، ولا تضيف إليكِ شيئًا لم يكن فيكِ. هي فقط تحاول أن تكشف لكِ بعض ما أراه أنا؛ في ملامحكِ، وفي ضحكتكِ، وفي خجلكِ، وفي طريقتكِ التي لا تشبه أحدًا. وإذا خرجتِ من هذه الغرفة بشيء واحد، فليكن أنكِ لستِ مضطرة إلى أن تصبحي شخصًا آخر كي تكوني مميزة. بعض الأشياء الجميلة فيكِ موجودة أصلًا، حتى في الأيام التي لا تنتبهين إليها.',
       sign:['YOU WERE ALWAYS MORE THAN A REFLECTION.','SHAHAD — THE ONE WHO INSPIRED THIS ROOM.']}
    ],
    next:{t:'القاعة التالية',s:'THE LOCKED ROOM'}
  },
  locked:{
    title:'THE LOCKED ROOM',
    sub:'ليست كل الأبواب مغلقة بالمفاتيح.',
    hint:'استكشفي القاعة… الباب ينتظر رمزًا',
    approach:'الباب لا ينتظر مفتاحًا… بل ينتظر أن تتعرّفي على الرمز.',
    puzzleTitle:'THE FINAL SYMBOL',
    puzzle:{q:'«ما الرمز الذي تبحث عنه هذه القاعة؟»',answers:['وردة','الوردة'],ok:'لقد تعرّفتِ على الرمز.',wrong:'ليس هذا الرمز الذي تبحث عنه القاعة… تأمّلي النقوش مرة أخرى.',check:'CONFIRM',ph:'اكتبي الرمز'},
    hints:[
      {id:'engrave',text:'«شيءٌ قد يكون رقيقًا، لكنه يترك أثرًا لا يُنسى.»',img:'assets/images/locked/engrave.jpg'},
      {id:'bronze',text:'«لا أحتاج إلى صوت كي أعبّر، ولا إلى كلمات كي أُهدى. قد أكون صغيرة، لكنني أستطيع أن أختصر شعورًا كاملًا.»',img:'assets/images/locked/bronze.jpg'}
    ],
    items:[
      {id:'rose1',title:'وردة منحوتة',text:'«حتى الحجر احتفظ بصورة شيءٍ كان يومًا حيًّا.»',img:'assets/images/locked/rose1.jpg'},
      {id:'rose2',title:'الصندوق الزجاجي',text:'«ليست قيمة الهدية بحجمها، بل بما تحمله من معنى.»',img:'assets/images/locked/rose2.jpg'},
      {id:'rose3',title:'نقش مخفي',text:'«بعض الرموز لا تُكتشف بالنظر السريع.»',img:'assets/images/locked/rose3.jpg'}
    ],
    next:{t:'الطريق مفتوح',s:'THE EMPTY HALL'}
  },
  empty:{
    title:'THE EMPTY HALL',
    sub:'قاعة الذكريات التي لم تُكتب بعد',
    hint:'امشي نحو الضوء في نهاية القاعة',
    // معرض صور الغرفة الفارغة: أضيفي/احذفي أسطراً هنا فقط. المجلد: assets/images/empty-hall/
    gallery:[
  {
    img:'assets/images/empty-hall/frame.jpg',
    caption:'إطار الذكريات'
  }
],
    exitHint:'القوس المضيء خلف المنصة هو الطريق للمتابعة…',
    intro1:'YOU EXPECTED A TREASURE.',
    intro2:'BUT SOME THINGS ARE STILL WAITING TO HAPPEN.',
    intro3:'«وصلتِ إلى نهاية الطريق الذي يقود إلى الماضي... لكن ليس كل ما يستحق أن يُحفظ قد حدث بعد.»',
    light:{title:'THE UNWRITTEN FUTURE',
      text:'«هذه القاعة ليست فارغة لأنها نسيت ما كان فيها... بل لأنها لم تكتب كل ما سيأتى بعد.»',
      understood:'افهمتُ معنى القاعة', wish:'أريد أن أترك ذكرى للمستقبل'},
    wishUI:{title:'A MEMORY NOT YET MADE',
      q:'«ما الذكرى التي تتمنين أن يأتي يوم وتصبح حقيقية؟»',
      ph:'اكتبي أمنية أو لحظة تتمنين أن تعيشيها يومًا ما...',
      seal:'SEAL THIS WISH', notNow:'NOT NOW', max:160,
      saved:'A FUTURE MEMORY HAS BEEN LEFT HERE.',
      savedSub:'«بعض الأشياء تبدأ بأمنية صغيرة.»',
      exists:'رسالتكِ المحفوظة', del:'حذف الرسالة', close:'إغلاق',
      empty:'اكتبي شيئًا أولًا...'},
    items:[
      {id:'pedestal',title:'قاعدة بلا تمثال',text:'«ليس كل مكان فارغ ينتظر شيئًا قديمًا... بعض الأماكن تنتظر شيئًا لم يوجد بعد.»'},
      {id:'frame',title:'إطار ذكريات',text:'«هناك صور لم تُلتقط بعد، ولحظات لم تصل بعد، وأيام لم نعرف شكلها حتى الآن.»',img:'assets/images/empty-hall/frame.jpg'},
      {id:'mark1',title:'WHAT WAS',text:'«ما حدث صار جزءًا من الحكاية.»'},
      {id:'mark2',title:'WHAT IS',text:'«ما نعيشه الآن ما زال يكتب نفسه.»'},
      {id:'mark3',title:'WHAT MAY BE',text:'«أما القادم، فما زال يحمل مساحة لأشياء جميلة.»'}
    ],
    
letter:{title:"THE BEAUTY OF WHAT HASN'T HAPPENED YET",
      text:`يا شهد،
بنيت لج هاي القاعة فارغة، مو لأن ما عدنا شي نحچي عنه، بالعكس، لأن أكو أشياء هواي بعدنا ما عشناها، وما أريد أكتب ذكريات قبل لا تصير.
أريد أخلي هنا مكان لكلشي بعده ما صار، للأيام اللي بعدنا ما عشناها، للضحكات اللي بعدني ما سامعها منج بالحقيقة، للصور اللي بعدنا ما متصورينها سوه، وللتفاصيل الصغيرة اللي هسه يمكن ما نعرفها، بس يمكن يوم من الأيام تصير من أحب الأشياء لقلوبنا.
ما أعرف شلون راح تكون أيامنا الجاية، وما أگدر أعرف شنو راح يصير، بس أتمنى نعيش أشياء حلوة تستاهل تنحفظ، وأشياء بسيطة من نتذكرها بعدين نبتسم بدون ما نحس.
لهذا خليت هاي القاعة فارغة، حتى من يصير عدنا شي حلو، نرجع هنا ونخليه بمكانه، صورة، ذكرى، موقف يضحكنا، أو حتى شي بسيط ما يسوى بنظر غيرنا، بس إله معنى خاص إلنا.
يمكن هسه تشوفينها مجرد قاعة فارغة، بس أني أشوفها مكان ينتظر أشياء بعد ما إجت، وأيام بعد ما عشناها، وحكايات بعد ما نعرف شلون راح تبدي.
وأحلى شي بيها، أني ما أريد أتخيل كلشي وأكتبه، أريد أعيش هالأشياء وياج، وبعدين أرجع هنا وأحطها، حتى من نكبر ونرجع نشوفها، نعرف شكد من لحظة بسيطة صارت ذكرى حلوة.
فخليتها فارغة إلج، يا شهد
مو لأن ما عندي شي أكتبه، ولا لأن حكايتنا ناقصة، بس لأن بعد أكو هواي أشياء حلوة أتمنى نعيشها سوه، وأريد إلها مكان خاص بين كل هالأشياء.
ويمكن بيوم من الأيام، نرجع لهاي القاعة، ونضحك على شكد جانت فارغة، وشكد صارت مليانة بأشياء جانت بالنسبة إلنا مجرد أمنيات.
ويمكن وقتها نفهم ليش خليتها فارغة من البداية.`,
      sign:"FOR THE MEMORIES WE HAVEN'T MADE YET.",
      open:'اقرئي الرسالة'},
    next:{t:'الطريق يستمر',s:'THE SKY'}

  },
  sky:{
    title:'THE SKY',
    sub:'سماء شهد — كونٌ صغير يحمل حكاية كبيرة',
    hint:'STARS DISCOVERED',
    prompt:'تأمّلي هذه النجمة',
    intro1:'SOME MEMORIES ARE WRITTEN ON EARTH.',
    intro2:'OTHERS LIVE AMONG THE STARS.',
    intro3:'«بعض الذكريات نعيشها... وبعض المعاني تبقى مضيئة في داخلنا، مهما ابتعدت المسافات.»',
    heart:{title:'THE CELESTIAL HEART',text:'«ليست كل النجوم بعيدة كما تبدو؛ بعضها يذكّرنا بشيء قريب إلى القلب.»'},
    stars:[
      {id:'s1',name:'THE LIGHT OF BEAUTY',c:0xfff2f8,halo:0xffffff,text:'«هناك جمال لا يحتاج إلى أن يثبت نفسه؛ يكفي أن يترك في القلب أثرًا لا يشبه غيره.»',sub:'هذه النجمة ترمز إلى الجمال الذي ألهم فكرة هذا المتحف.',pos:[-6,6.4,-18]},
      {id:'s2',name:'THE LITTLE LIGHT',c:0xffc9de,halo:0xff9fc9,text:'«بعض التفاصيل صغيرة إلى درجة أن العالم قد لا ينتبه إليها... لكنها عند شخصٍ ما قد تكون من أحب الأشياء إليه.»',sub:'هذه النجمة ترمز إلى الكياتة والتفاصيل الصغيرة التي تجعل شهد مميزة بنظري.',pos:[6,5,-13]},
      {id:'s3',name:'THE ECHO OF HER VOICE',c:0xd6e4ff,halo:0x9fc0ff,text:'«قد تنتهي الكلمات، لكن أثر بعضها يبقى أطول مما نتوقع.»',sub:'هذه النجمة ترمز إلى صوتها وطريقتها في الكلام، وإلى الأثر الذي يمكن أن تتركه الكلمات البسيطة.',pos:[-7.5,3.4,-9]},
      {id:'s4',name:'THE MOMENTS WE KEEP',c:0xffe2a8,halo:0xffc96a,text:'«ليست كل اللحظات العزيزة كبيرة أو استثنائية؛ أحيانًا تكون أبسط التفاصيل هي التي نحب أن نتذكرها.»',sub:'',pos:[5.5,7.4,-22]},
      {id:'s5',name:'BEYOND THE DISTANCE',c:0xe8ecff,halo:0xb99bff,text:'«ليست المسافة هي التي تحدد قيمة الشعور؛ أحيانًا تجعلنا ننتبه أكثر إلى الأشياء التي نتمنى أن نعيشها يومًا.»',sub:'',pos:[-4.5,8.6,-27]},
      {id:'s6',name:'THE UNWRITTEN STAR',c:0xfff4fa,halo:0xffd9ec,text:'«لا نعرف كل ما ينتظرنا، لكننا نستطيع أن نترك للمستقبل مساحة للأشياء الجميلة.»',sub:'هذه النجمة لا تمثل ذكرى حدثت بالفعل؛ إنها تمثل مساحة مفتوحة لكل ما قد يأتي.',pos:[3.5,6.4,-30]}
    ],
    finale1:'SIX LIGHTS. ONE UNIVERSE.',
    finale2:'«كل نجمة تحمل معنى، لكن جمال السماء يظهر حين نرى كيف تجتمع النجوم في صورة واحدة.»',
    constell:'«يمكن للنجوم أن تبدو متفرقة حين ننظر إلى كل واحدة وحدها. لكن حين نجمعها، نكتشف أن لكل واحدة مكانًا في الصورة.<br><br>وهكذا هي التفاصيل أيضًا؛ قد تبدو صغيرة أو عادية حين نراها منفردة، لكنها معًا تصنع معنى أكبر.»',
    constellTitle:'THE SKY OF SHAHAD',
    constellSub:'A universe made of little things.',
    exitReady:'السماء اكتملت… الطريق نحو النجمة الأخيرة مفتوح',
    exitLock:'اكتشفي النجوم الست أولًا…',
    next:{t:'الطريق مفتوح',s:'THE FINAL STAR — GS:UNWRITTEN'}
  },
  final:{
    title:'THE FINAL STAR',
    sub:'GS — UNWRITTEN',
    hint:'اقتربي من النجمة في المركز',
    intro1:'THE FINAL STAR',
    intro2:'Some things are remembered. Some things are still waiting.',
    intro3:'GS — UNWRITTEN',
    obj:{
      
moments:{name:'THE MOMENTS WE KEEP',title:'الذكريات اللي نصنعها سوية',
        text:'يا شهد،<br><br>أكو ذكريات ما تحتاج نخطط إلها، ولا نعرف من البداية إنها راح تصير شي حلو نتذكره بعدين. مرات تجي من أبسط الأشياء، من ضحكة بيناتنا، من حچي يطول وإحنا ما نحس بالوقت، أو من كلمة عادية تبقى ببالنا أكثر مما نتوقع.<br><br>وأحس أحلى شي بالذكريات مو شكد كانت اللحظة مميزة، إنما شلون كانت ويّا الشخص الصح.<br><br>أريد من عدنا نصنع هواي ذكريات، مو شرط تكون كلها أشياء كبيرة، حتى أبسط أيامنا أريد إلها مكان هنا، لأن بالنهاية هاي التفاصيل الصغيرة هي اللي راح تخلّي كلشي بيناتنا مميز.<br><br>وخليت هنا مساحة للذكريات اللي بعد ما صارت، للأيام اللي بعدنا ما عشناها، وللأشياء اللي بعدنا ما جرّبناها سويّة.<br><br>لأن مو كلشي حلو لازم يكون صار حتى نحچي عنه، أكو أشياء حلوة ننتظرها، وأتمنى يوم من الأيام نرجع لهنا ونشوف شكد شي حلو صار بيناتنا، وشكد من هالمساحة الفارغة امتلَت بينا. ♡'},
      words:{name:'THE WORDS I KEEP',title:'THE WORDS I KEEP',
        text:'شهد،<br><br>وصلتُ إلى آخر غرفة في هذا المتحف، لكنني لا أشعر أن الكلام انتهى.<br><br>حاولتُ أن أجمع هنا بعض التفاصيل التي أحبها، وبعض اللحظات التي تستحق أن تبقى، والأشياء التي قد لا أجد دائمًا الكلمات المناسبة لأقولها.<br><br>ما كتبته هنا ليس كل ما أريد قوله، وليس هذا المكان قادرًا على اختصار إنسانة كاملة في غرفة أو كلمات.<br><br>أردتُ فقط أن يكون لكِ مكان صغير، صُنِع بعناية، تستطيعين العودة إليه كلما رغبتِ.<br><br>وهنا، عند آخر نجمة، أترك مساحة لكل شيء لم نكتبه بعد.<br><br>— GS'},
      little:{name:'THE LITTLE THINGS',title:'THE LITTLE THINGS',items:[
        ['HER BEAUTY','Some kinds of beauty do not ask for attention; they simply change the atmosphere of a place.'],
        ['HER CUTENESS','It lives in the small, effortless details that are easy to miss and impossible to forget.'],
        ['HER VOICE','Some words stay with us longer than the moment they were spoken.'],
        ['HER WAY OF SPEAKING','A style of speaking can become a memory of its own.'],
        ['HER SHYNESS','A quiet kind of charm that makes ordinary moments feel softer.'],
        ['HER REALNESS','No performance, no pretending — just a person being genuinely herself.'],
        ['THE LITTLE DETAILS','Sometimes, it is the smallest details that make someone unforgettable.']]},
      unwritten:{name:'THE UNWRITTEN PAGE',title:'A MEMORY NOT YET MADE',
        text:'Not every beautiful thing has happened yet.',
        prompts:['SOMETHING I HOPE WE EXPERIENCE','SOMETHING I WANT TO TELL YOU','SOMETHING I WANT TO REMEMBER'],
        ph:'اكتبي هنا…',save:'SEAL IT',edit:'تعديل',del:'مسح',saved:'Left here, on this page.',local:'محفوظ على هذا الجهاز فقط — قد لا ينتقل إلى جهاز آخر.'}
    },
    star:{title:'GS — UNWRITTEN',
      lines:'For the memories we keep.<br><br>For the words we still want to say.<br><br>For the moments that have not happened yet.',
      text:'شهد،<br><br>هاي آخر غرفة بالمتحف، بس مو نهاية الحكاية.<br><br>يمكن كل اللي كتبته هنا ما يكفي حتى أوصف لج كلشي أريد أحچي عنه، ولا يكدر يجمع كل التفاصيل اللي تخلّيج مميزة عندي، بس على الأقل حاولت أخلي جزء من اللي بداخلي بمكان تكدرين ترجعين إله بأي وقت.<br><br>خليت هنا كلشي كدرت أكتبه، ومساحة للأشياء اللي بعدني ما كتبتها.<br><br>لأن ما أريد أملأ هالمكان بحكايات بعد ما صارت، أريد أخليها إلنا، حتى نعيشها بوقتها، وتصير ذكريات حقيقية نرجع نحچي عنها بعدين.<br><br>وإذا وصلتي لآخر غرفة اليوم، أريدج تطلعين منها وإنتِ تعرفين شغلة وحدة:<br><br>مو لازم تكون الحكاية كاملة حتى تكون حلوة، ومو لازم نعرف شنو ينتظرنا حتى نكون متحمسين نعيشه سويّة.<br><br>يمكن أحلى أجزاء حكايتنا هي اللي بعد ما إجت، واللي أتمنى يوم من الأيام نرجع لهنا ونشوف شكد شي حلو صار من وراها.<br><br>— GS'},
    completeBtn:'COMPLETE THE CONSTELLATION',
    cineTitle:'GS — UNWRITTEN',
    cineLines:'The museum ends here.<br><br>The unwritten remains unwritten.',
    revisit:'REVISIT THE FINAL STAR',
    home:'RETURN TO THE MUSEUM ENTRANCE',
    done:'اكتمل التكوين… يمكنكِ العودة لأي عنصر',
    next:{t:'اكتمل المتحف',s:'THE FINAL STAR — GS:UNWRITTEN'}
  }
};
/* ================================================================== */

/* ================================================================== */
