/* القسم 05 — THE TREND ARCHIVE v3 (PRISM VAULT) */
window.Trends=(()=>{
const S={active:false},C=CONTENT.trends,ex={},hits=[],viewed=new Set(),tp=new T.Vector3(),tl=new T.Vector3(),look=new T.Vector3(0,3,-8),zs=[6,3,-3,-9,-15,-19],scr=[],rings=[],prisms=[],mists=[];
let grp,focus=null,si=0,ti=0,nb,pb2,term,fc=0,ch2=1;
const gt=document.getElementById('gt'),gh=document.getElementById('gh'),say=m=>{gh.textContent=m||`${C.hint} · ${viewed.size}/4`};
const nav=()=>{nb.style.display=si<zs.length-1?'block':'none';pb2.style.display=si>0?'block':'none'},go=d=>{if(focus)return;si=Math.max(0,Math.min(zs.length-1,si+d));nav()};
function mkb(t,css,fn){const b=document.createElement('button');b.className='go';b.textContent=t;b.style.cssText='position:fixed;bottom:calc(140px + env(safe-area-inset-bottom,0px));background:rgba(12,8,22,.6);z-index:3;display:none;'+css;b.onclick=fn;document.body.appendChild(b);return b}
function tx(w,h,fn,rep){const c=document.createElement('canvas');c.width=w;c.height=h;fn(c.getContext('2d'),w,h);const t=new T.CanvasTexture(c);t.wrapS=t.wrapT=T.RepeatWrapping;t.repeat.set(rep[0],rep[1]);t.anisotropy=ANISO;t.encoding=T.sRGBEncoding;return t}
function drawScr(s,t,i){const x=s.x,w=270,h=480;
 if(s.img&&s.img.complete&&s.img.naturalWidth){const k=Math.max(w/s.img.naturalWidth,h/s.img.naturalHeight);x.drawImage(s.img,(w-s.img.naturalWidth*k)/2,(h-s.img.naturalHeight*k)/2,s.img.naturalWidth*k,s.img.naturalHeight*k);x.fillStyle='rgba(5,3,12,.35)';x.fillRect(0,0,w,h)}
 else{const g=x.createLinearGradient(0,0,0,h);g.addColorStop(0,'#1c0b26');g.addColorStop(.55,'#120716');g.addColorStop(1,'#07040d');x.fillStyle=g;x.fillRect(0,0,w,h);
  for(let k=0;k<9;k++){const bw=40+(Math.sin(t*.7+k*1.9+i)+1)*.5*160;x.fillStyle=k%2?'rgba(185,155,255,.16)':'rgba(255,95,168,.16)';x.fillRect(22,300+k*16,bw,7)}
  x.strokeStyle='rgba(207,208,232,.12)';x.lineWidth=1;for(let k=0;k<5;k++){x.beginPath();x.arc(w/2,210,26+k*16,0,6.283);x.stroke()}}
 x.fillStyle='rgba(7,4,13,.55)';x.fillRect(0,0,w,64);
 x.fillStyle='#ec5f9d';x.font='700 13px "Space Grotesk",sans-serif';x.fillText('TREND #0'+(i+1),20,28);
 x.fillStyle='#d9d3e4';x.font='600 15px "Cormorant Garamond",serif';x.fillText(C.exhibits[i].title,20,50);
 const sec=Math.floor(t)%60;x.fillStyle='#b39df0';x.font='12px monospace';x.textAlign='right';x.fillText('00:'+(sec<10?'0':'')+sec,w-18,30);x.textAlign='left';
 x.beginPath();x.arc(w/2,210,30,0,6.283);x.strokeStyle='rgba(255,255,255,.85)';x.lineWidth=2;x.stroke();
 x.fillStyle='rgba(255,255,255,.9)';x.beginPath();x.moveTo(w/2-9,192);x.lineTo(w/2+13,210);x.lineTo(w/2-9,228);x.fill();
 x.fillStyle='rgba(185,155,255,.18)';x.strokeStyle='#b39df0';x.beginPath();x.roundRect?x.roundRect(w-58,196,40,40,20):x.rect(w-58,196,40,20);x.fill();x.stroke();
 x.fillStyle='#ec5f9d';x.beginPath();x.moveTo(w-44,222);x.bezierCurveTo(w-58,210,w-50,200,w-44,208);x.bezierCurveTo(w-38,200,w-30,210,w-44,222);x.fill();
 x.fillStyle='rgba(255,95,168,.22)';x.strokeStyle='#ec5f9d';x.beginPath();x.roundRect?x.roundRect(55,428,160,34,17):x.rect(55,428,160,34);x.fill();x.stroke();
 x.fillStyle='#fff';x.font='500 15px "Cormorant Garamond",serif';x.textAlign='center';x.fillText('OPEN MEMORY',135,450);x.textAlign='left';
 x.fillStyle='rgba(207,208,232,.25)';x.fillRect(20,474,230,3);x.fillStyle='#ec5f9d';x.fillRect(20,474,230*((t*.05+i*.22)%1),3);
 if(Math.sin(t*3+i*5)>.965){const y=(Math.random()*430)|0;x.drawImage(x.canvas,0,y,w,10,14,y,w,10)}
 x.fillStyle='rgba(0,0,0,.14)';for(let k=0;k<h;k+=4)x.fillRect(0,k,w,1);s.tex.needsUpdate=true}
function drawTerm(t){const x=tsc.x;x.fillStyle='#0d0714';x.fillRect(0,0,384,240);
 x.strokeStyle='rgba(185,155,255,.35)';x.lineWidth=2;x.strokeRect(6,6,372,228);
 x.fillStyle='#b39df0';x.font='20px monospace';const L=['> TREND ARCHIVE v2.0','> SYNCING MEMORIES...','> '+viewed.size+'/4 TRENDS VIEWED','> ENTER ARCHIVE KEY'+(Math.floor(t*2)%2?' _':'')];L.forEach((l,k)=>x.fillText(l,20,52+k*36));
 x.fillStyle='#ec5f9d';x.fillRect(20,196,120+40*Math.abs(Math.sin(t)),4);
 x.fillStyle='rgba(0,0,0,.16)';for(let k=0;k<240;k+=3)x.fillRect(0,k,384,1);tsc.tex.needsUpdate=true}
let tsc;
function build(){
 grp=new T.Group();scene.add(grp);const r=rnd(55),add=(m,x,y,z)=>{m.position.set(x,y,z);grp.add(m);return m},mk=(w,h,d,m,x,y,z)=>add(new T.Mesh(new T.BoxGeometry(w,h,d),m),x,y,z);
 const dark=M(0x0d0a18,.35,.6),sil=M(0x9a9cba,.22,.9);
 const pk=new T.MeshBasicMaterial({color:0xff5fa8}),pu=new T.MeshBasicMaterial({color:0xb99bff});
 const gl=(c,op,s,x,y,z,p)=>{const q=new T.Sprite(new T.SpriteMaterial({map:GT,color:c,opacity:op,transparent:true,depthWrite:false,blending:T.AdditiveBlending}));q.scale.set(s,s,1);q.position.set(x,y,z);(p||grp).add(q);return q};
 const beam=(c,x,z)=>{const b=new T.Mesh(new T.ConeGeometry(1.5,4.8,24,1,true),new T.MeshBasicMaterial({color:c,transparent:true,opacity:.055,blending:T.AdditiveBlending,depthWrite:false,side:T.DoubleSide}));b.position.set(x,6.6,z);b.rotation.x=Math.PI;grp.add(b)};
 // أرضية سوداء لامعة + جدران شبه معدمة + لوحات بنفسجية خافتة
 add(new T.Mesh(new T.PlaneGeometry(20,32),new T.MeshStandardMaterial({color:0x08060f,roughness:.1,metalness:.85})),0,0,-10).rotation.x=-Math.PI/2;
 mk(.4,9,32,dark,-10.2,4.5,-10);mk(.4,9,32,dark,10.2,4.5,-10);mk(20.4,9,.4,dark,0,4.5,-26.2);mk(20.4,9,.4,dark,0,4.5,8.2);mk(20.4,.4,32,M(0x040308,.95),0,9.2,-10);
 [-1,1].forEach(s=>{for(let z=4;z>-26;z-=6){mk(.12,8.6,.12,sil,s*9.9,4.3,z);const pn=mk(2.6,4.6,.06,M(0x171126,.6,.3,0x0d0a18),s*9.9,4.3,z-3);pn.rotation.y=s<0?Math.PI/2:-Math.PI/2;mk(2.8,4.8,.04,sil,s*9.92,4.3,z-3).rotation.y=pn.rotation.y;mk(.06,.06,5.9,pk,s*9.9,.12,z-3)}});
 mk(3,.03,31,M(0x241026,.6,.3,0x140816),0,.02,-10);[-1.7,1.7].forEach(x=>mk(.06,.05,31,pu,x,.03,-10));
 // المنشورات
 for(let i=0;i<4;i++){const c=document.createElement('canvas');c.width=270;c.height=480;const t=new T.CanvasTexture(c);t.encoding=T.sRGBEncoding;const s={x:c.getContext('2d'),tex:t};if(C.exhibits[i].img){s.img=new Image();s.img.src=C.exhibits[i].img}scr.push(s);drawScr(s,0,i)}
 const prism=(sx,z,i)=>{const e=C.exhibits[i],g=new T.Group();g.position.set(sx,3.2,z);g.rotation.y=sx<0?Math.PI/2:-Math.PI/2;grp.add(g);
  const cg=new T.Group();g.add(cg);cg.scale.set(1,1.4,1);
  const cm=new T.MeshPhongMaterial({color:i%2?0xb99bff:0xff5fa8,transparent:true,opacity:.26,shininess:140,specular:0xffffff,side:T.DoubleSide});
  const c1=new T.Mesh(new T.ConeGeometry(1.05,1.7,6),cm);c1.position.y=.85;cg.add(c1);
  const c2=new T.Mesh(new T.ConeGeometry(1.05,1.7,6),cm);c2.rotation.x=Math.PI;c2.position.y=-.85;cg.add(c2);
  const core=new T.Mesh(new T.IcosahedronGeometry(.4,0),new T.MeshBasicMaterial({color:0xffffff}));g.add(core);
  gl(i%2?0xff5fa8:0xb99bff,.55,6,0,0,-.4,g);
  const fr=mk2(1.5,2.62,.06,sil,0,0,.72,g),sm=new T.Mesh(new T.PlaneGeometry(1.34,2.38),new T.MeshBasicMaterial({map:scr[i].tex}));sm.position.set(0,0,.76);g.add(sm);
  const lb=Museum.lab(e.title,2);lb.scale.set(3.2,.68,1);lb.position.set(0,-2.4,.3);g.add(lb);
  const disc=new T.Mesh(new T.CylinderGeometry(1.35,1.5,.07,24),sil);disc.position.y=-1.9;g.add(disc);
  const edge=new T.Mesh(new T.TorusGeometry(1.42,.035,8,40),i%2?pk:pu);edge.rotation.x=Math.PI/2;edge.position.y=-1.86;g.add(edge);
  const ring=new T.Mesh(new T.TorusGeometry(1.55,.02,8,48),i%2?pu:pk);ring.rotation.x=Math.PI/2.4;g.add(ring);rings.push(ring);
  const h=new T.Mesh(new T.SphereGeometry(2.4,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));h.position.set(0,0,.8);h.userData.id=e.id;g.add(h);hits.push(h);ex[e.id]=g.position;
  gl(i%2?0xff5fa8:0xb99bff,.22,4.2,sx*.7,.12,z);beam(i%2?0xb99bff:0xff5fa8,sx,z);
  prisms.push({cg,core,edge,ph:r()*6.283,y0:3.2,g,x:sx,z})};
 prism(-4.4,-3,0);prism(4.4,-9,1);prism(-4.4,-15,2);prism(4.4,-21,3);
 // المسلة النهائية (اللغز)
 const tg=new T.Group();tg.position.set(0,0,-24.6);grp.add(tg);const tb=(w,h,d,m,x,y,z)=>{const k=new T.Mesh(new T.BoxGeometry(w,h,d),m);k.position.set(x,y,z);tg.add(k);return k};
 const c2=document.createElement('canvas');c2.width=384;c2.height=240;tsc={x:c2.getContext('2d'),tex:new T.CanvasTexture(c2)};tsc.tex.encoding=T.sRGBEncoding;drawTerm(0);
 tb(3.2,5.4,.9,M(0x0a0714,.3,.7),0,2.7,0);tb(3.4,.14,1,sil,0,5.45,0);tb(3.4,.14,1,sil,0,.1,0);tb(.1,5.2,.1,pk,-1.62,2.7,.46);tb(.1,5.2,.1,pu,1.62,2.7,.46);
 tb(2.9,2,.12,M(0x120a1c,.4,.5),0,3.3,.5);
 const ts=new T.Mesh(new T.PlaneGeometry(2.6,1.63),new T.MeshBasicMaterial({map:tsc.tex}));ts.position.set(0,3.3,.57);tg.add(ts);
 tb(2.2,.2,.5,pk,0,5.62,0);
 term=new T.Mesh(new T.PlaneGeometry(2.6,1.63),new T.MeshBasicMaterial({color:0xb99bff,transparent:true,opacity:.02,blending:T.AdditiveBlending,depthWrite:false}));term.position.set(0,3.3,.6);tg.add(term);
 const tl2=Museum.lab('THE ARCHIVE KEY',4.6);tl2.position.set(0,.85,.6);tg.add(tl2);
 const th=new T.Mesh(new T.SphereGeometry(3,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));th.position.set(0,2.6,1.4);th.userData.id='term';tg.add(th);hits.push(th);ex.term=new T.Vector3(0,0,-24.6);
 beam(0xff5fa8,0,-24.6);gl(0xb99bff,.4,7,0,4,-24.2);
 // ضباب أرضي منجرف + غبار + أضواء
 for(let i=0;i<8;i++){const m=gl(0x8a6bbf,.09,7+r()*4,(r()-.5)*14,.35+r()*.5,4-r()*28);m.userData={sp:.1+r()*.25,x0:m.position.x,ph:r()*6.283};mists.push(m)}
 const MN=mobile?90:180,mp=new Float32Array(MN*3);for(let i=0;i<MN;i++)mp.set([(r()-.5)*18,r()*8.4,8-r()*32],i*3);
 grp.add(new T.Points(new T.BufferGeometry().setAttribute('position',new T.BufferAttribute(mp,3)),new T.PointsMaterial({map:GT,size:.12,color:0xd9c2ff,transparent:true,opacity:.5,depthWrite:false,blending:T.AdditiveBlending})));
 [[0xff5fa8,-3,-4.4],[0xb99bff,-9,4.4],[0xff5fa8,-15,-4.4],[0xb99bff,-21,4.4],[0xff5fa8,-24,0]].forEach(a=>{const l=new T.PointLight(a[0],1.35,20,2);l.position.set(a[2],5.6,a[1]);grp.add(l)})}
function mk2(w,h,d,m,x,y,z,p){const k=new T.Mesh(new T.BoxGeometry(w,h,d),m);k.position.set(x,y,z);p.add(k);return k}
function finish(){UI.close();GS.goToSection6()}
GS.goToSection6=()=>{veil.style.transition='opacity 1.6s ease';veil.style.background='#fff0fa';veil.style.opacity=1;setTimeout(()=>{S.hide();Places.enter()},1700)};
return Object.assign(S,{
 reset(){viewed.clear()},
 enter(){if(!grp){build();nb=mkb('تقدّمي ‹','left:calc(50% + 8px)',()=>go(1));pb2=mkb('› رجوع','right:calc(50% + 8px)',()=>go(-1))}
  View.reset();S.active=true;fogS.forEach(f=>f.visible=false);const h=scene.children.find(o=>o.isHemisphereLight);if(h){ch2=h.intensity;h.intensity=.3}grp.visible=true;
  scene.fog.color.set(0x0b0512);scene.fog.near=14;scene.fog.far=64;si=0;focus=null;ti=0;setTimeout(()=>{if(S.active)nav()},3500);cam.position.set(0,3,7.6);look.set(0,3,-8);
  veil.style.transition='background .9s ease, opacity 2.4s ease 2.4s';veil.style.background='#050308';veil.style.opacity=0;say();gh.classList.add('on');
  gt.innerHTML='<b>'+C.title+'</b><i>'+C.sub+'</i>';gt.classList.remove('show');void gt.offsetWidth;gt.classList.add('show')},
 hide(){S.active=false;grp.visible=false;nb.style.display=pb2.style.display='none';gh.classList.remove('on');gt.classList.remove('show');const h=scene.children.find(o=>o.isHemisphereLight);if(h)h.intensity=ch2;fogS.forEach(f=>f.visible=true)},
 leave(){if(!grp)return;S.active=false;grp.visible=false;nb.style.display=pb2.style.display='none';gh.classList.remove('on');gt.classList.remove('show');UI.close();const h=scene.children.find(o=>o.isHemisphereLight);if(h)h.intensity=ch2;fogS.forEach(f=>f.visible=true)},
 tap(e){v2.set(e.clientX/innerWidth*2-1,-(e.clientY/innerHeight)*2+1);ray.setFromCamera(v2,cam);const q=ray.intersectObjects(hits)[0];if(!q)return;const id=q.object.userData.id;
  if(id==='term'){if(viewed.size<4){say(C.lock);return}focus='term';UI.puzzle(C.puzzle,finish,()=>{focus=null})}
  else{focus=id;viewed.add(id);say();UI.exhibit(C.exhibits.find(x=>x.id===id),()=>{focus=null})}},
 update(dt,t){sx+=(nx-sx)*.04;const f=focus&&ex[focus];ti+=dt;
  if(f){if(focus==='term'){tp.set(0,3,-17);tl.set(0,3.2,-24.6)}else{tp.set(f.x*.3,3.2,f.z+5.2);tl.set(f.x,3.3,f.z)}}else{tp.set(sx*1.5,3,zs[si]);tl.set(-sx*1.5,3.2,zs[si]-12)}
  cam.position.lerp(tp,1-Math.exp(-dt*(ti<4?.8:2.2)));look.lerp(tl,1-Math.exp(-dt*2.5));cam.lookAt(look);View.apply(cam,dt,!!focus);
  term.material.opacity=viewed.size>3?.1+.05*Math.sin(t*2):.02;
  if(!reduce){rings.forEach((m,i)=>{m.rotation.z+=dt*(.3+i*.12)});
   prisms.forEach((p,i)=>{p.ph+=dt*.6;p.g.position.y=p.y0+Math.sin(p.ph)*.16;p.cg.rotation.y+=dt*.25;p.core.scale.setScalar(1+.18*Math.sin(t*2.4+i*1.7));p.edge.rotation.z+=dt*.5});
   mists.forEach(m=>{m.userData.ph+=dt*m.userData.sp;m.position.x=m.userData.x0+Math.sin(m.userData.ph)*1.6});
   if(++fc%3===0){scr.forEach((s,i)=>drawScr(s,t,i));drawTerm(t)}}
  R.render(scene,cam)}
})})();