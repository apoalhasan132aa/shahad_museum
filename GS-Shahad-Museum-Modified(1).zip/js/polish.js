/* لمسات الجودة: انعكاسات بيئية + ظلال القمر (ديسكتوب) + ڤينييت + دقة تكيفية */
(()=>{
 const es=new T.Scene();
 es.add(new T.Mesh(new T.SphereGeometry(50,32,16),new T.ShaderMaterial({side:T.BackSide,vertexShader:'varying vec3 p;void main(){p=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:'varying vec3 p;void main(){float h=normalize(p).y*.5+.5;gl_FragColor=vec4(mix(vec3(.02,.02,.025),vec3(.08,.08,.09),h),1.);}'})));
 [[0xc8c8cc,0,30,0,20,20],[0xb8b8bc,-30,10,10,12,18],[0xb8b8bc,30,12,-10,12,18],[0xc0c0c4,0,8,-35,26,10]].forEach(a=>{const m=new T.Mesh(new T.PlaneGeometry(a[4],a[5]),new T.MeshBasicMaterial({color:a[0],side:T.DoubleSide}));m.position.set(a[1],a[2],a[3]);m.lookAt(0,0,0);es.add(m)});
 let ENV=null;try{const pm=new T.PMREMGenerator(R);ENV=pm.fromScene(es,.04).texture;pm.dispose()}catch(err){console.warn('env',err)}
 const tag=()=>{if(!ENV)return;scene.traverse(o=>{if(!o.isMesh)return;(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>{if(m.isMeshStandardMaterial&&!m.userData.env&&(m.metalness>=.35||m.roughness<=.3)){m.userData.env=1;m.envMap=ENV;m.envMapIntensity=.14;m.needsUpdate=true}})})};
 const hsl={},gm=c=>{c.getHSL(hsl);let H=hsl.h,S=hsl.s,L=hsl.l;if(H>=.47&&H<.6&&S>.3){H=.08;S=.6;L=Math.min(.85,L+.05)}else if(H>=.6&&H<.72&&S>.25){H=.8;S*=.75}else if(S<.25&&L<.4){H=.93;S=.2}c.setHSL(H,S,L)};
 const grade=()=>scene.traverse(o=>{if(o.isLight){if(!o.userData.gr){o.userData.gr=1;gm(o.color);if(o.groundColor)gm(o.groundColor)}return}(o.material?(Array.isArray(o.material)?o.material:[o.material]):[]).forEach(m=>{if(m.color&&!m.userData.gr&&!m.isShaderMaterial){m.userData.gr=1;gm(m.color)}})});
 const soften=()=>scene.traverse(o=>{
  if(o.isLight&&!o.userData.sf){o.userData.sf=1;o.intensity*=o.isPointLight?.85:.92}
  if(o.isSprite||o.isPoints||o.isMesh)(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>{if(!m||m.userData.sf)return;m.userData.sf=1;
   if(m.blending===T.AdditiveBlending)m.opacity*=.6;
   else if(m.isMeshStandardMaterial){if(!m.transparent)m.roughness=Math.max(m.roughness,.32);m.metalness=Math.min(m.metalness,.7);if(m.emissive&&m.emissive.getHex())m.emissiveIntensity*=.65}
   else if(m.isMeshBasicMaterial&&!m.map&&m.color)m.color.multiplyScalar(.88)})});
 const run=()=>{grade();soften();tag()};run();let cnt=-1;setInterval(()=>{if(scene.children.length!==cnt){cnt=scene.children.length;run()}},1200);
 if(!mobile){const c=moonL.shadow.camera;moonL.castShadow=true;moonL.shadow.mapSize.set(1024,1024);c.left=-45;c.right=45;c.top=45;c.bottom=-45;c.near=10;c.far=140;c.updateProjectionMatrix();moonL.shadow.bias=-.0004;moonL.shadow.autoUpdate=false;moonL.shadow.needsUpdate=true;setInterval(()=>{moonL.shadow.needsUpdate=true},600);
  B.g.traverse(o=>{if(!o.isMesh)return;const m=Array.isArray(o.material)?o.material[0]:o.material;if(!m.transparent&&m.visible!==false)o.castShadow=o.receiveShadow=true});ground.receiveShadow=true}
 const vg=document.createElement('div');vg.style.cssText='position:fixed;left:0;top:0;width:100%;height:100%;pointer-events:none;z-index:1;background:radial-gradient(ellipse at center,transparent 55%,rgba(26,3,18,.4))';document.body.appendChild(vg);
 let n=0,t0=performance.now();const f=()=>{n++;const t=performance.now();if(t-t0>1200){const fps=n*1000/(t-t0);n=0;t0=t;const pr=R.getPixelRatio();const fl=mobile?.75:1;if(!document.hidden&&fps<45&&pr>fl){R.setPixelRatio(Math.max(fl,pr-.35));resize()}}requestAnimationFrame(f)};requestAnimationFrame(f);
})();
