/* القسم 09 — THE SKY (سماء شهد — كون صغير يحمل حكاية كبيرة) */
window.Sky=(()=>{
const S={active:false},C=CONTENT.sky,ex={},hits=[],viewed=new Set(),tp=new T.Vector3(),tl=new T.Vector3(),look=new T.Vector3(0,3,-12),zs=[6,0,-6,-12,-17,-22];
let grp,focus=null,si=0,ti=0,nb,pb2,fc=0,ch6=1,cine,intro=0,introT=0,heartG,heartRing,heartStar,starObjs={},lines={},finale=0,exitGlow,skyPts=[],nearId=null,dots=[],constellationSeen=false,exBtn=null;
const gt=document.getElementById('gt'),gh=document.getElementById('gh');
const say=m=>{gh.textContent=m||`${C.hint}: ${viewed.size} / 6`};
const nav=()=>{nb.style.display=(si<zs.length-1&&!intro&&!finale)?'block':'none';pb2.style.display=(si>0&&!intro&&!finale)?'block':'none'},go=d=>{if(focus||intro||finale)return;si=Math.max(0,Math.min(zs.length-1,si+d));nav()};
function mkb(t,css,fn){const b=document.createElement('button');b.className='go';b.textContent=t;b.style.cssText='position:fixed;bottom:calc(140px + env(safe-area-inset-bottom,0px));background:rgba(12,8,22,.6);z-index:3;display:none;'+css;b.onclick=fn;document.body.appendChild(b);return b}
const LS={get seen(){try{return localStorage.getItem('gs_sky_seen')==='1'}catch(e){return false}},set seen(v){try{localStorage.setItem('gs_sky_seen',v?'1':'0')}catch(e){}}};
// ==== السماء: طبقات نجوم بجسيمات ====
function starLayer2(n,size,spread,y0,y1,zNear,zFar,color,op){const pos=new Float32Array(n*3);for(let i=0;i<n;i++)pos.set([(Math.random()-.5)*spread,y0+Math.random()*(y1-y0),zNear+Math.random()*(zFar-zNear)],i*3);
 const m=new T.PointsMaterial({map:GT,size:size,color:color,transparent:true,opacity:op,depthWrite:false,blending:T.AdditiveBlending});const p=new T.Points(new T.BufferGeometry().setAttribute('position',new T.BufferAttribute(pos,3)),m);grp.add(p);skyPts.push(m);return p}
function buildCine(){if(cine)return;cine=document.createElement('div');cine.style.cssText='position:fixed;inset:0;z-index:7;display:none;align-items:center;justify-content:center;pointer-events:none;background:rgba(2,2,10,.2)';const t=document.createElement('div');t.id='skCine';t.style.cssText='color:#f0ecf2;font:italic 400 clamp(18px,3vw,26px)/1.8 "Cormorant Garamond","Amiri",serif;text-align:center;max-width:620px;padding:0 24px;opacity:0;transition:opacity 1.6s ease;text-shadow:0 2px 30px rgba(0,0,0,.9)';cine.appendChild(t);document.body.appendChild(cine)}
function cineText(txt){const t=document.getElementById('skCine');t.style.opacity=0;setTimeout(()=>{t.textContent=txt;t.style.opacity=1},900)}
function endIntro(){if(!intro)return;intro=0;cine.style.opacity=0;setTimeout(()=>{cine.style.display='none';cine.style.opacity=1},1200);LS.seen=true;nav();say()}
// ==== نافذة النجمة ====
let ov=null;
function buildOv(){if(ov)return;ov=document.createElement('div');ov.id='skOv';ov.style.cssText='position:fixed;inset:0;z-index:8;display:none;align-items:center;justify-content:center;background:rgba(3,3,12,.55);backdrop-filter:blur(3px);padding:18px';
 const card=document.createElement('div');card.style.cssText='max-width:520px;width:100%;background:linear-gradient(165deg,rgba(20,18,40,.97),rgba(9,8,22,.97));border:1px solid rgba(185,155,255,.35);border-radius:14px;padding:24px 22px 18px;direction:rtl;text-align:center;box-shadow:0 0 60px rgba(185,155,255,.14)';
 card.innerHTML=`<div id="skT" style="color:#f6dbe6;font:700 14px 'Space Grotesk',sans-serif;letter-spacing:2px;margin-bottom:12px;direction:ltr"></div><div id="skB" style="color:#f0ecf2;font:italic 400 clamp(17px,2.3vw,20px)/1.9 'Cormorant Garamond','Amiri',serif;min-height:90px"></div><div style="margin-top:14px"><button id="skC" style="${btnS()}">${'إغلاق'}</button></div>`;
 ov.appendChild(card);document.body.appendChild(ov);ov.addEventListener('click',e=>{if(e.target===ov)closeOv()});document.getElementById('skC').onclick=()=>closeOv();
 window.addEventListener('keydown',e=>{if(e.key==='Escape'&&ov.style.display=='flex')closeOv()})}
function btnS(){return 'background:rgba(185,155,255,.1);border:1px solid rgba(185,155,255,.5);color:#d9d2ee;border-radius:20px;padding:9px 22px;font:600 15px "Cormorant Garamond",serif;cursor:pointer'}
function starOv(st){buildOv();focus=st.id;document.getElementById('skT').textContent=st.name;
 const B=document.getElementById('skB');B.style.transition='opacity .8s ease';B.style.opacity=0;
 setTimeout(()=>{B.innerHTML='<p style="margin:0 0 8px">'+st.text+'</p>'+(st.sub?'<p id="skSub" style="margin:0;font-size:.88em;color:#b9b3d6;opacity:0;transition:opacity 1.4s ease">'+st.sub+'</p>':'');
 B.style.opacity=1;if(st.sub)setTimeout(()=>{const s2=document.getElementById('skSub');if(s2)s2.style.opacity=.85},1400)},420);
 ov.style.display='flex';
 if(!viewed.has(st.id)){viewed.add(st.id);say();revealLine(st.id)}}
function closeOv(){if(ov)ov.style.display='none';focus=null}
// ==== الحدث الختامي ====
function revealLine(id){const L=lines[id];if(L)L.target=.7}
function startFinale(){if(finale)return;finale=1;nav();buildCine();cine.style.display='flex';
 skyPts.forEach(m=>m.userData={dim:1});
 setTimeout(()=>cineText(C.finale1),700);setTimeout(()=>cineText(C.finale2),4800);
 setTimeout(()=>{cine.style.opacity=0;setTimeout(()=>{cine.style.display='none';cine.style.opacity=1},1200);finale=0;say(C.exitReady);nav();showConstellation()},9600)}
// ==== بناء المشهد ====
function build(){
 grp=new T.Group();scene.add(grp);const r=rnd(7),add=(m,x,y,z)=>{m.position.set(x,y,z);grp.add(m);return m},mk=(w,h,d,m,x,y,z)=>add(new T.Mesh(new T.BoxGeometry(w,h,d),m),x,y,z);
 const sil=M(0x8a8fb0,.3,.8),darkM=M(0x14121f,.6,.4);
 const glow=(c,op,s,x,y,z,p)=>{const q=new T.Sprite(new T.SpriteMaterial({map:GT,color:c,opacity:op,transparent:true,depthWrite:false,blending:T.AdditiveBlending}));q.scale.set(s,s,1);q.position.set(x,y,z);(p||grp).add(q);return q};
 // خلفية كونية: طبقات ثلاث + شريط نجمي + سحب
 scene.fog&&0; // لا شيء
 starLayer2(mobile?420:850,.55,90,6,34,-46,4,0xcfd2ee,.75);   // بعيدة
 starLayer2(mobile?220:450,.9,70,4,30,-42,-2,0xd9d2f2,.85);   // وسطى
 starLayer2(mobile?90:180,1.5,50,2,26,-36,-6,0xffffff,.95);   // قريبة
 // الشريط النجمي (مجرة رقيقة مائلة)
 const MN=mobile?500:1000,mp=new Float32Array(MN*3);
 for(let i=0;i<MN;i++){const t2=(i/MN-.5);mp.set([t2*70+(Math.random()-.5)*7,12+t2*9+(Math.random()-.5)*5,-24+(Math.random()-.5)*16],i*3)}
 grp.add(new T.Points(new T.BufferGeometry().setAttribute('position',new T.BufferAttribute(mp,3)),new T.PointsMaterial({map:GT,size:.8,color:0x9fa8d8,transparent:true,opacity:.4,depthWrite:false,blending:T.AdditiveBlending})));
 // سحب كونية شفافة
 for(let i=0;i<5;i++){const cl=glow(0x5a5f9a,.05,16+Math.random()*8,(Math.random()-.5)*40,8+Math.random()*10,-20-Math.random()*14)}
 // أرضية داكنة شبه عاكسة
 add(new T.Mesh(new T.PlaneGeometry(44,58),new T.MeshStandardMaterial({color:0x0d0e1a,roughness:.32,metalness:.6})),0,0,-16).rotation.x=-Math.PI/2;
 // خطوط فضية رفيعة + دوائر هادئة
 for(let z=6;z>-40;z-=5.5)mk(30,.015,.07,sil,0,.02,z);
 [-8,8].forEach(x=>mk(.07,.015,46,sil,x,.02,-16));
 [8,2,-4].forEach(z=>{const ring=new T.Mesh(new T.TorusGeometry(3.2,.05,8,48),sil);ring.rotation.x=Math.PI/2;ring.position.set(0,.05,z);grp.add(ring)});
 // مسار مضيء يقود للقلب
 for(let i=0;i<14;i++){const z=4-i*2.6;const d=add(new T.Mesh(new T.CircleGeometry(.09,10),new T.MeshBasicMaterial({color:0xd9d2f2,transparent:true,opacity:.5})),0,.03,z);d.rotation.x=-Math.PI/2;d.userData.ph=i*.5;dots.push(d)}
 // قوس أفق بعيد
 const arch=new T.Mesh(new T.TorusGeometry(16,1.1,10,60,Math.PI),darkM);arch.position.set(0,0,-44);grp.add(arch);
 glow(0x3a3f7a,.12,30,0,8,-43);
 // ==== THE CELESTIAL HEART ====
 heartG=new T.Group();heartG.position.set(0,4.2,-26);grp.add(heartG);
 const hb=(w,h,d,m,x,y,z)=>{const k=new T.Mesh(new T.BoxGeometry(w,h,d),m);k.position.set(x,y,z);heartG.add(k);return k};
 const plat=new T.Mesh(new T.CylinderGeometry(3,3.4,.3,36),darkM);plat.position.y=-3.4;heartG.add(plat);
 const platR=new T.Mesh(new T.TorusGeometry(3,.06,8,56),sil);platR.rotation.x=Math.PI/2;platR.position.y=-3.24;heartG.add(platR);
 heartRing=new T.Mesh(new T.TorusGeometry(2.1,.045,8,64),new T.MeshBasicMaterial({color:0xb99bff,transparent:true,opacity:.55}));heartG.add(heartRing);
 const ring2=new T.Mesh(new T.TorusGeometry(1.5,.03,8,56),new T.MeshBasicMaterial({color:0xff9fc9,transparent:true,opacity:.4}));ring2.rotation.x=Math.PI/3;heartG.add(ring2);heartG.userData.ring2=ring2;
 heartStar=new T.Mesh(new T.OctahedronGeometry(.5,0),new T.MeshBasicMaterial({color:0xfff4fa}));heartG.add(heartStar);
 glow(0xffd9ec,.6,6,0,0,0,heartG);glow(0xb99bff,.3,8,0,0,-.6,heartG);
 const hpl=new T.PointLight(0xffe9f4,1,30,2);hpl.position.set(0,5,-26);grp.add(hpl);
 const hh=new T.Mesh(new T.SphereGeometry(3,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));hh.userData.id='heart';heartG.add(hh);hits.push(hh);ex.heart=new T.Vector3(0,4.2,-26);
 // ==== النجوم الست ====
 C.stars.forEach((st,ix)=>{const g=new T.Group();g.position.set(st.pos[0],st.pos[1],st.pos[2]);grp.add(g);
  const core=new T.Mesh(new T.OctahedronGeometry(ix===5?.42:.3,0),new T.MeshBasicMaterial({color:st.c}));g.add(core);
  const halo=glow(st.halo,.5,ix===5?4:2.8,0,0,0,g);
  if(st.id==='s3'){for(let k2=1;k2<=2;k2++){const wk=new T.Mesh(new T.TorusGeometry(.6+k2*.35,.014,6,40),new T.MeshBasicMaterial({color:0x9fc0ff,transparent:true,opacity:.4}));wk.rotation.x=Math.PI/2.3;g.add(wk);(starObjs[st.id]=starObjs[st.id]||{rings:[]}).rings.push(wk)}}
  if(st.id==='s4'){for(let k2=0;k2<6;k2++){const a=k2/6*Math.PI*2;glow(0xffe2a8,.6,.1,Math.cos(a)*.7,Math.sin(a)*.4,0,g)}}
  if(st.id==='s2'){for(let k2=0;k2<4;k2++){glow(0xffc9de,.5,.08,(Math.random()-.5)*.9,(Math.random()-.5)*.9,(Math.random()-.5)*.4,g)}}
  if(st.id==='s5'){const beamL=glow(0xb99bff,.18,.5,0,0,0,g);beamL.scale.set(.5,7,1)}
  const h=new T.Mesh(new T.SphereGeometry(2.5,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));h.userData.id=st.id;g.add(h);hits.push(h);ex[st.id]=g.position;
  starObjs[st.id]=Object.assign(starObjs[st.id]||{},{g,core,halo,base:.5,max:.95,ph:r()*6.283});
  // خط ضوئي للقلب
  const lg=new T.BufferGeometry();lg.setAttribute('position',new T.BufferAttribute(new Float32Array([0,0,0,-st.pos[0],-st.pos[1]+4.2,-st.pos[2]+26]),3));
  const lm=new T.LineBasicMaterial({color:st.halo,transparent:true,opacity:0,blending:T.AdditiveBlending});
  const line=new T.Line(lg,lm);heartG.add(line);lines[st.id]={m:lm,target:0}});
 // ==== المخرج: نجمة أخيرة بعيدة ====
 exitGlow=glow(0xfff4fa,0,4,0,7,-40);
 const eh=new T.Mesh(new T.SphereGeometry(2.6,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));eh.position.set(0,6.4,-40);eh.userData.id='exit';grp.add(eh);hits.push(eh);ex.exit=new T.Vector3(0,6.4,-40);
 // إضاءة بيئية خافتة
 const a1=new T.PointLight(0x8a90c8,.5,44,2);a1.position.set(0,10,-8);grp.add(a1);
 const a2=new T.PointLight(0x8a90c8,.4,44,2);a2.position.set(0,10,-26);grp.add(a2);
 buildCine()}
function showConstellation(){constellationSeen=true;say(C.exitReady);
 buildOv();document.getElementById('skT').textContent=C.constellTitle;
 document.getElementById('skB').innerHTML='<p style="text-align:right;margin:0 0 10px">'+C.constell+'</p><p style="color:#b39df0;letter-spacing:1px;font-style:normal;font-family:\'Space Grotesk\',sans-serif;font-size:12px;margin:0">'+C.constellSub+'</p>';
 ov.style.display='flex'}
function restoreLines(){Object.keys(lines).forEach(k2=>{if(viewed.has(k2))lines[k2].target=.7});if(viewed.size>=6)S.finaleFired=true}
function finish(){closeOv();focus=null;veil.style.transition='opacity 1.8s ease';veil.style.background='#020208';veil.style.opacity=1;setTimeout(()=>{S.hide();Final.enter()},1900)}
return Object.assign(S,{
 reset(){viewed.clear();finale=0;constellationSeen=false;if(exBtn)exBtn.style.display='none';constellationSeen=false;if(exBtn)exBtn.style.display='none';S.finaleFired=false;constellationSeen=false;Object.keys(lines).forEach(k=>{lines[k].target=0;lines[k].m.opacity=0});if(exitGlow)exitGlow.material.opacity=0},
 enter(){if(!grp){build();nb=mkb('تقدّمي ‹','left:calc(50% + 8px)',()=>go(1));pb2=mkb('› رجوع','right:calc(50% + 8px)',()=>go(-1));buildOv();exBtn=mkb('تابعي ‹','left:50%;transform:translateX(-50%);bottom:calc(205px + env(safe-area-inset-bottom,0px));border-color:#f6dbe6;color:#fff0f8',()=>{if(constellationSeen)finish()})}
  View.reset();S.active=true;fogS.forEach(f=>f.visible=false);const h=scene.children.find(o=>o.isHemisphereLight);if(h){ch6=h.intensity;h.intensity=.12}grp.visible=true;
  scene.fog.color.set(0x05060f);scene.fog.near=26;scene.fog.far=96;si=0;focus=null;ti=0;restoreLines();
  veil.style.transition='background .9s ease, opacity 2.4s ease 2.4s';veil.style.background='#020208';veil.style.opacity=0;
  gh.classList.add('on');gt.innerHTML='<b>'+C.title+'</b><i>'+C.sub+'</i>';gt.classList.remove('show');void gt.offsetWidth;gt.classList.add('show');
  if(!LS.seen){intro=1;introT=0;cine.style.display='flex';cam.position.set(0,3.4,7.6);look.set(0,3.4,-12);
   setTimeout(()=>{if(intro)cineText(C.intro1)},800);setTimeout(()=>{if(intro)cineText(C.intro2)},5000);setTimeout(()=>{if(intro)cineText(C.intro3)},9200);setTimeout(()=>{endIntro()},14600)}
  else{intro=0;say();setTimeout(()=>{if(S.active)nav()},800)}},
 hide(){S.active=false;grp.visible=false;nb.style.display=pb2.style.display='none';gh.classList.remove('on');gt.classList.remove('show');closeOv();if(exBtn)exBtn.style.display='none';if(intro)endIntro();const h=scene.children.find(o=>o.isHemisphereLight);if(h)h.intensity=ch6;fogS.forEach(f=>f.visible=true)},
 leave(){if(!grp)return;S.active=false;grp.visible=false;nb.style.display=pb2.style.display='none';gh.classList.remove('on');gt.classList.remove('show');closeOv();focus=null;if(intro)endIntro();const h=scene.children.find(o=>o.isHemisphereLight);if(h)h.intensity=ch6;fogS.forEach(f=>f.visible=true)},
 tap(e){if(intro){endIntro();return}if(ov&&ov.style.display=='flex')return;
  v2.set(e.clientX/innerWidth*2-1,-(e.clientY/innerHeight)*2+1);ray.setFromCamera(v2,cam);const q=ray.intersectObjects(hits)[0];if(!q)return;const id=q.object.userData.id;
  if(id==='heart'){if(viewed.size>=6){showConstellation()}else{say(C.exitLock)}return}
  if(id==='exit'){if(viewed.size>=6&&constellationSeen){finish()}else{say(viewed.size<6?C.exitLock:'تأمّلي التكوين في قلب السماء أولًا');setTimeout(()=>{if(!focus)say()},2400)}return}
  const st=C.stars.find(x=>x.id===id);if(st)starOv(st)},
 update(dt,t){sx+=(nx-sx)*.04;const f=focus&&ex[focus];ti+=dt;
  if(intro){introT+=dt;cam.position.z=7.6-introT*.2;cam.position.y=3.4+Math.sin(introT*.25)*.08;cam.position.x=sx*1.4;look.set(0,3.4,-12);cam.lookAt(look);View.apply(cam,dt,true)}
  else if(finale){cam.position.lerp(new T.Vector3(0,4.4,-17),1-Math.exp(-dt*1.1));look.lerp(new T.Vector3(0,4.2,-26),1-Math.exp(-dt*1.6));cam.lookAt(look);View.apply(cam,dt,true)}
  else{if(f){tp.set(f.x*.42,f.y-.6,f.z+7.5);tl.set(f.x,f.y,f.z)}else{tp.set(sx*1.6,3.1,zs[si]);tl.set(-sx*1.6,3.4,zs[si]-13)}
   cam.position.lerp(tp,1-Math.exp(-dt*(ti<4?.8:2.1)));look.lerp(tl,1-Math.exp(-dt*2.3));cam.lookAt(look);View.apply(cam,dt,!!focus)}
  // توهج ونبض
  let nz=null;if(!focus&&!finale){let best=4;C.stars.forEach(st=>{const d=Math.hypot(cam.position.z-st.pos[2],cam.position.x-st.pos[0]);if(d<5&&d<best){best=d;nz=st.id}})}
  nearId=nz;
  Object.keys(starObjs).forEach(k2=>{const o=starObjs[k2];o.ph+=dt;o.core.rotation.y+=dt*.6;
   const tgt=(nearId===k2||focus===k2)?o.max:(viewed.has(k2)?o.base+.15:o.base);
   o.halo.material.opacity+=(tgt-o.halo.material.opacity)*.05;
   o.g.position.y+=Math.sin(o.ph*.7)*dt*.12});
  Object.keys(lines).forEach(k2=>{const L=lines[k2];L.m.opacity+=((L.target||0)-L.m.opacity)*.03});
  heartRing.rotation.z+=dt*.18;heartG.userData.ring2.rotation.y+=dt*.24;heartStar.rotation.y+=dt*.4;
  heartStar.scale.setScalar(1+.12*Math.sin(t*1.5));
  skyPts.forEach((m,i)=>{m.opacity=(i===0?.7:i===1?.82:.92)+.08*Math.sin(t*.7+i*2)});
  if(dots.length)dots.forEach(d=>{d.material.opacity=.35+.25*Math.sin(t*1.4+d.userData.ph)});
  if(exBtn)exBtn.style.display=(constellationSeen&&!focus&&!intro&&!finale)?'block':'none';
  const done=viewed.size>=6;
  if(done&&!S.finaleFired){S.finaleFired=true;startFinale()}
  exitGlow.material.opacity+=((done&&constellationSeen?.85:0)-exitGlow.material.opacity)*.04;
  if(!focus&&!finale&&!intro){if(nearId){const st=C.stars.find(x=>x.id===nearId);gh.textContent=C.prompt+' — '+st.name}else if(performance.now()%4200<70)say()}
  R.render(scene,cam)}
})})();