/* القسم 06 — PLACES WE HAVEN'T BEEN : مرصد السفر وكرة الأرض */
window.Places=(()=>{
const S={active:false},C=CONTENT.places,E=C.exhibits,hits=[],viewed=new Set(),tp=new T.Vector3(),tl=new T.Vector3(),look=new T.Vector3(0,5,-8),UP=new T.Vector3(0,1,0);
let grp,gg,focus=null,tgy=null,ti=0,fc=0,fl,bd,hemi,hv2=1;const arcs=[],arcM=[],pins=[];let tnow=0,busy=false;
const gt=document.getElementById('gt'),gh=document.getElementById('gh'),say=m=>{gh.textContent=m||`${C.hint} · ${viewed.size}/${E.length}`};
const ll=(lon,lat,r)=>{const p=(lon+180)/360*6.2832,t=(90-lat)/180*Math.PI;return new T.Vector3(-Math.cos(p)*Math.sin(t)*r,Math.cos(t)*r,Math.sin(p)*Math.sin(t)*r)};
const CONT=[[[-168,66],[-140,70],[-95,72],[-80,63],[-62,58],[-55,48],[-70,42],[-76,35],[-81,25],[-97,26],[-105,22],[-117,32],[-125,42],[-125,50],[-140,60]],[[-80,10],[-60,10],[-35,-6],[-40,-22],[-58,-38],[-68,-55],[-74,-50],[-71,-30],[-80,-5]],[[-10,36],[-9,43],[-2,48],[5,53],[10,58],[30,70],[40,66],[40,50],[28,42],[20,38],[12,38],[0,38]],[[-17,21],[-10,35],[10,37],[32,31],[44,12],[51,11],[40,-15],[33,-26],[20,-35],[12,-17],[8,4],[-8,5],[-17,14]],[[40,66],[60,72],[100,77],[140,72],[170,66],[160,55],[142,46],[130,35],[122,30],[120,22],[108,10],[100,3],[92,22],[80,8],[73,20],[58,25],[50,30],[36,35],[28,42],[40,50]],[[114,-22],[130,-12],[142,-11],[153,-26],[147,-38],[135,-35],[115,-34]],[[-55,60],[-20,70],[-25,82],[-60,80]],[[130,32],[140,36],[142,44],[137,37]],[[-6,50],[1,52],[-3,58],[-6,56]]];
function drawMap(c,base){const x=c.getContext('2d'),w=c.width,h=c.height;x.fillStyle=base?'#160a20':'#000';x.fillRect(0,0,w,h);
 if(base){x.strokeStyle='rgba(255,201,176,.08)';x.lineWidth=1;for(let i=0;i<=24;i++){x.beginPath();x.moveTo(i*w/24,0);x.lineTo(i*w/24,h);x.stroke()}for(let i=0;i<=12;i++){x.beginPath();x.moveTo(0,i*h/12);x.lineTo(w,i*h/12);x.stroke()}}
 const ps=CONT.map(a=>{const p=new Path2D();a.forEach((q,i)=>{const X=(q[0]+180)/360*w,Y=(90-q[1])/180*h;i?p.lineTo(X,Y):p.moveTo(X,Y)});p.closePath();return p});
 x.fillStyle=base?'#f2c4a4':'#ffc9a8';for(let Y=4;Y<h;Y+=8)for(let X=4;X<w;X+=8)if(ps.some(p=>x.isPointInPath(p,X,Y))){x.beginPath();x.arc(X,Y,2.4,0,6.283);x.fill()}}
function passTex(i){const c=document.createElement('canvas');c.width=512;c.height=256;const x=c.getContext('2d'),g=x.createLinearGradient(0,0,512,256);g.addColorStop(0,'#f3e6e8');g.addColorStop(1,'#e8d2d8');x.fillStyle=g;x.beginPath();x.roundRect?x.roundRect(4,4,504,248,18):x.rect(4,4,504,248);x.fill();x.strokeStyle='#c99a7a';x.lineWidth=3;x.stroke();
 x.setLineDash([6,6]);x.beginPath();x.moveTo(372,12);x.lineTo(372,244);x.stroke();x.setLineDash([]);x.fillStyle='#5a2a3c';x.font='700 24px "Cormorant Garamond",serif';x.fillText('BOARDING PASS',24,44);
 x.font='500 15px monospace';x.fillStyle='#8a5a6a';x.fillText('FROM',24,84);x.fillText('TO',24,136);x.fillStyle='#4a1e30';x.font='700 25px "Cormorant Garamond",serif';x.fillText('HERE',24,110);x.fillText('DESTINATION UNKNOWN',24,164);
 x.font='500 15px monospace';x.fillStyle='#8a5a6a';x.fillText('FLIGHT GS-00'+(i+1)+'   GATE ?   SEAT ?',24,214);x.fillStyle='#4a1e30';for(let k=0;k<22;k++)x.fillRect(390+k*5,50,(k%3)+1.5,110);x.font='28px serif';x.fillText('♡',430,208);
 const t=new T.CanvasTexture(c);t.encoding=T.sRGBEncoding;t.anisotropy=ANISO;return t}
function drawBoard(t){const x=bd.x;x.fillStyle='#14080f';x.fillRect(0,0,512,256);x.fillStyle='#ffc98a';x.font='700 30px monospace';x.fillText('DEPARTURES',20,44);x.font='18px monospace';
 E.forEach((e,i)=>{const open=viewed.size>=E.length;x.fillStyle=(Math.floor(t*1.2+i)%2||open)?'#ffc98a':'#8a5a3a';x.fillText('GS-00'+(i+1)+'  DESTINATION UNKNOWN',20,86+i*34);x.fillStyle=open?'#ff9fc0':'#ffc98a';x.fillText(open?'GATE OPEN ♡':'DELAYED',380,86+i*34)});
 x.fillStyle='rgba(0,0,0,.2)';for(let k=0;k<256;k+=3)x.fillRect(0,k,512,1);bd.tex.needsUpdate=true}
function build(){
 grp=new T.Group();scene.add(grp);const r=rnd(77),add=(m,x,y,z)=>{m.position.set(x,y,z);grp.add(m);return m},mk=(w,h,d,m,x,y,z)=>add(new T.Mesh(new T.BoxGeometry(w,h,d),m),x,y,z);
 const gl=(c,op,s,p)=>{const q=new T.Sprite(new T.SpriteMaterial({map:GT,color:c,opacity:op,transparent:true,depthWrite:false,blending:T.AdditiveBlending}));q.scale.set(s,s,1);p.add(q);return q};
 // ===== luxury airport terminal =====
 const mm=M(0x8a7a86,.35,.5),pw=M(0xd9d2d8,.5,.2),wl=M(0x2a1a22,.6,.1);
 const tz=document.createElement('canvas');tz.width=tz.height=256;{const x=tz.getContext('2d');x.fillStyle='#2a1a22';x.fillRect(0,0,256,256);for(let i=0;i<900;i++){x.fillStyle=`rgba(${200+r()*50|0},${160+r()*40|0},${150+r()*40|0},${.04+r()*.08})`;x.fillRect(r()*256,r()*256,2+r()*5,2+r()*5)}x.strokeStyle='rgba(227,191,148,.6)';x.lineWidth=3;x.strokeRect(0,0,256,256)}
 const tzt=new T.CanvasTexture(tz);tzt.wrapS=tzt.wrapT=T.RepeatWrapping;tzt.repeat.set(7,10.5);tzt.encoding=T.sRGBEncoding;tzt.anisotropy=ANISO;
 add(new T.Mesh(new T.PlaneGeometry(28,42),new T.MeshStandardMaterial({map:tzt,bumpMap:tzt,bumpScale:.4,roughness:.35,metalness:.1})),0,0,-9).rotation.x=-Math.PI/2;
 const fc2=document.createElement('canvas');fc2.width=fc2.height=512;{const x=fc2.getContext('2d'),g=x.createRadialGradient(256,256,0,256,256,256);g.addColorStop(0,'#2a1424');g.addColorStop(1,'#12060f');x.fillStyle=g;x.fillRect(0,0,512,512);x.strokeStyle='rgba(227,191,148,.55)';x.lineWidth=2;[250,236,150,60].forEach(q=>{x.beginPath();x.arc(256,256,q,0,6.283);x.stroke()});
  for(let i=0;i<16;i++){const q=i/16*6.283,l=i%4?150:236;x.beginPath();x.moveTo(256,256);x.lineTo(256+Math.cos(q)*l,256+Math.sin(q)*l);x.stroke()}
  x.fillStyle='#e3bf94';x.font='700 34px "Cormorant Garamond",serif';x.textAlign='center';[['N',256,46],['S',256,490],['E',478,268],['W',34,268]].forEach(q=>x.fillText(q[0],q[1],q[2]))}
 const ft=new T.CanvasTexture(fc2);ft.encoding=T.sRGBEncoding;ft.anisotropy=ANISO;
 add(new T.Mesh(new T.CircleGeometry(6,64),new T.MeshStandardMaterial({map:ft,roughness:.45})),0,.02,-6).rotation.x=-Math.PI/2;const pr=new T.Mesh(new T.TorusGeometry(6,.08,8,64),goldM2);pr.rotation.x=Math.PI/2;add(pr,0,.05,-6);
 mk(.5,12.5,42,wl,-14.25,6.25,-9);mk(.5,12.5,42,wl,14.25,6.25,-9);mk(28.5,12.5,.5,wl,0,6.25,13.25);mk(28.5,.5,42,M(0x1a0f16,.9),0,12.75,-9);
 for(let i=0;i<9;i++){const q=new T.Mesh(new T.TorusGeometry(14,.22,6,36,Math.PI),pw);q.scale.y=.55;add(q,0,4.8,10-i*4.5)}
 [-5,5].forEach(x=>mk(.25,.08,42,new T.MeshBasicMaterial({color:0xffe2c4}),x,12.45,-9));
 for(let i=0;i<7;i++)[-1,1].forEach(s2=>{add(new T.Mesh(new T.CylinderGeometry(.45,.55,8,16),pw),s2*9.5,4,9-i*5.5);mk(1.2,.3,1.2,goldM2,s2*9.5,8.1,9-i*5.5)});
 [-7,7].forEach(x=>[-14,-20].forEach(z=>{mk(3,.15,.9,mm,x,.55,z);mk(3,.6,.12,mm,x,.9,z-.4);[-1.3,1.3].forEach(q=>mk(.1,.5,.7,goldM2,x+q,.25,z))}));
 mk(28,12,.05,new T.MeshStandardMaterial({color:0xe0c8ff,transparent:true,opacity:.08,roughness:0,depthWrite:false,side:T.DoubleSide}),0,6,-30);
 for(let i=-7;i<=7;i++)mk(.14,12,.2,goldM2,i*2,6,-30);[3,6,9].forEach(y=>mk(28,.12,.2,goldM2,0,y,-30));
 const run=document.createElement('canvas');run.width=1024;run.height=128;{const x=run.getContext('2d');x.fillStyle='#0c080c';x.fillRect(0,0,1024,128);x.fillStyle='rgba(255,236,220,.8)';for(let i=0;i<16;i++)x.fillRect(i*64+8,60,36,8);x.fillStyle='rgba(255,236,220,.5)';x.fillRect(0,6,1024,4);x.fillRect(0,118,1024,4)}
 const rt=new T.CanvasTexture(run);rt.encoding=T.sRGBEncoding;
 add(new T.Mesh(new T.PlaneGeometry(220,60),new T.MeshStandardMaterial({color:0x0f0a10,roughness:.8})),0,-.03,-60).rotation.x=-Math.PI/2;
 add(new T.Mesh(new T.PlaneGeometry(220,16),new T.MeshStandardMaterial({map:rt,roughness:.7})),0,-.02,-62).rotation.x=-Math.PI/2;
 {const n=70,p=new Float32Array(n*6);for(let i=0;i<n;i++){const x=-105+i*3;p.set([x,.15,-54.5,x,.15,-69.5],i*6)}grp.add(new T.Points(new T.BufferGeometry().setAttribute('position',new T.BufferAttribute(p,3)),new T.PointsMaterial({map:GT,size:.9,color:0xffe0c0,transparent:true,opacity:.9,depthWrite:false,blending:T.AdditiveBlending})))}
 const jet=(x,z,ry)=>{const g=new T.Group();g.position.set(x,0,z);g.rotation.y=ry;g.scale.setScalar(1.4);grp.add(g);const p=(geo,m,px,py,pz,rx,ry2,rz)=>{const k=new T.Mesh(geo,m);k.position.set(px,py,pz);k.rotation.set(rx||0,ry2||0,rz||0);g.add(k)};
  p(new T.CylinderGeometry(1.5,1.5,22,16),pw,0,3,0,0,0,Math.PI/2);p(new T.SphereGeometry(1.5,16,12).scale(1.6,1,1),pw,11,3,0);p(new T.ConeGeometry(1.5,5,16),pw,-13.5,3.2,0,0,0,Math.PI/2);
  [-1,1].forEach(s2=>{p(new T.BoxGeometry(6,.25,13),pw,1,2.6,s2*6.5,0,-s2*.35);p(new T.CylinderGeometry(.7,.7,3,12),mm,2.5,1.9,s2*5,0,0,Math.PI/2);p(new T.BoxGeometry(3,.2,4.5),pw,-11.5,3.5,s2*2.2);
   const q=new T.Sprite(new T.SpriteMaterial({map:GT,color:s2<0?0xff4d6d:0x7dffb0,transparent:true,opacity:.9,depthWrite:false,blending:T.AdditiveBlending}));q.scale.set(1.2,1.2,1);q.position.set(-1.5,2.6,s2*12.5);g.add(q)});
  p(new T.BoxGeometry(3.5,4,.25),M(0xd88aa8,.5),-11,5.5,0)};
 jet(-25,-44,.08);jet(22,-50,3.0);
 // hanging gate signs (tap = mark place on globe)
 const gsgn=(i,x,z)=>{const c=document.createElement('canvas');c.width=512;c.height=160;const q=c.getContext('2d');q.fillStyle='#14080f';q.fillRect(0,0,512,160);q.strokeStyle='#e3bf94';q.lineWidth=4;q.strokeRect(4,4,504,152);q.fillStyle='#ffc98a';q.font='700 64px "Cormorant Garamond",serif';q.fillText('GATE A'+(i+1),24,84);q.fillStyle='#ffd9e6';q.font='500 24px monospace';q.fillText('DESTINATION UNKNOWN',24,126);q.fillStyle='#ff8fb8';q.font='700 60px serif';q.fillText('→',436,96);
  const t=new T.CanvasTexture(c);t.encoding=T.sRGBEncoding;const g=new T.Group();g.position.set(x,8.2,z);grp.add(g);g.add(new T.Mesh(new T.PlaneGeometry(3.6,1.125),new T.MeshBasicMaterial({map:t,color:0xe0e0e0})));
  [-1.6,1.6].forEach(q2=>{const cb=new T.Mesh(new T.CylinderGeometry(.02,.02,4.2,6),goldM2);cb.position.set(q2,2.1,0);g.add(cb)});
  const h=new T.Mesh(new T.SphereGeometry(1.8,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));h.userData.id=E[i].id;g.add(h);hits.push(h)};
 [[-6.5,-2],[6.5,-2],[-6.5,-12],[6.5,-12]].forEach((q,i)=>gsgn(i,q[0],q[1]));
 // globe
 gg=new T.Group();gg.position.set(0,3.6,-6);grp.add(gg);
 const mc=document.createElement('canvas');mc.width=1024;mc.height=512;drawMap(mc,true);const ec=document.createElement('canvas');ec.width=1024;ec.height=512;drawMap(ec,false);
 const mt=new T.CanvasTexture(mc),et=new T.CanvasTexture(ec);mt.encoding=et.encoding=T.sRGBEncoding;mt.anisotropy=ANISO;
 gg.add(new T.Mesh(new T.SphereGeometry(3,mobile?36:56,mobile?24:36),new T.MeshStandardMaterial({map:mt,emissiveMap:et,emissive:0xffffff,emissiveIntensity:.5,roughness:.75,metalness:.05})));
 gl(0xff9fc0,.22,11,gg);
 // pins + arcs
 E.forEach((e,i)=>{const pg=new T.Group();pg.position.copy(ll(e.lon,e.lat,3.02));pg.quaternion.setFromUnitVectors(UP,pg.position.clone().normalize());gg.add(pg);pg.visible=false;pg.scale.setScalar(.001);pins[i]={t:-1,g:pg};
  const bm=new T.Mesh(new T.CylinderGeometry(.008,.012,.45,6).translate(0,.22,0),pinkM);pg.add(bm);const hd=new T.Mesh(new T.SphereGeometry(.1,12,10),pinkM);hd.position.y=.46;pg.add(hd);const g2=gl(0xff8fb8,.6,.9,pg);g2.position.y=.46;pins[i].g2=g2;pins[i].r=[0,1,2].map(()=>{const rg=new T.Mesh(new T.RingGeometry(.08,.11,40),new T.MeshBasicMaterial({color:0xffb0c8,transparent:true,opacity:0,blending:T.AdditiveBlending,depthWrite:false,side:T.DoubleSide}));rg.rotation.x=-Math.PI/2;rg.position.y=.012;pg.add(rg);return rg});
  const h=new T.Mesh(new T.SphereGeometry(.55,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));h.position.y=.46;h.userData.id=e.id;pg.add(h);pins[i].h=h;
  if(i<E.length-1){const a=ll(e.lon,e.lat,3.05),b=ll(E[i+1].lon,E[i+1].lat,3.05),mid=a.clone().add(b).multiplyScalar(.5);mid.setLength(3.05+a.distanceTo(b)*.45);const cv=new T.QuadraticBezierCurve3(a,mid,b);arcs.push(cv);
   gg.add(arcM[i]=new T.Mesh(new T.TubeGeometry(cv,40,.014,6),new T.MeshBasicMaterial({color:0xffb0c8,transparent:true,opacity:.7,blending:T.AdditiveBlending,depthWrite:false})))}});
 fl=gl(0xfff0f6,.9,.55,gg);
 // armillary + stand
 [[4,0,0],[4.5,1.2,.4],[5,.5,1.1]].forEach((a,i)=>{const t=new T.Mesh(new T.TorusGeometry(a[0],.04,8,64),goldM2);t.rotation.set(a[1]+1.57*(i?0:1),a[2],0);t.userData.rot=1;gg.parent.add(t);t.position.copy(gg.position)});
 add(new T.Mesh(new T.CylinderGeometry(.9,1.2,.4,28),mm),0,.2,-6);add(new T.Mesh(new T.CylinderGeometry(.22,.35,2.6,16),goldM2),0,1.5,-6);
 // boarding passes
 E.forEach((e,i)=>{const a=(-48+i*32)*Math.PI/180,x=9*Math.sin(a),z=-5+9*Math.cos(a),g=new T.Group();g.position.set(x,0,z);grp.add(g);
  const pole=new T.Mesh(new T.CylinderGeometry(.04,.05,1.5,8),goldM2);pole.position.y=.75;g.add(pole);
  const cd=new T.Mesh(new T.PlaneGeometry(3.2,1.6),new T.MeshBasicMaterial({map:passTex(i),color:0xe0e0e0,side:T.DoubleSide}));cd.position.y=1.9;g.add(cd);
  const fm=new T.Mesh(new T.BoxGeometry(3.3,1.7,.05),goldM2);fm.position.set(0,1.9,-.04);g.add(fm);g.lookAt(0,1.9,12);g.rotateX(-.2);
  const h=new T.Mesh(new T.SphereGeometry(1.7,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));h.position.set(0,1.9,.3);h.userData.id=e.id;g.add(h);hits.push(h)});
 // departures board
 const bc=document.createElement('canvas');bc.width=512;bc.height=256;bd={x:bc.getContext('2d'),tex:new T.CanvasTexture(bc)};bd.tex.encoding=T.sRGBEncoding;drawBoard(0);
 const bg=new T.Group();bg.position.set(0,9.6,-18);bg.rotation.x=-.12;grp.add(bg);const bb=new T.Mesh(new T.BoxGeometry(8.4,4.4,.3),M(0x1a0f18,.4,.5));bg.add(bb);const bk=new T.Mesh(new T.BoxGeometry(8.6,4.6,.1),goldM2);bk.position.z=-.15;bg.add(bk);
 const bs=new T.Mesh(new T.PlaneGeometry(8,4),new T.MeshBasicMaterial({map:bd.tex}));bs.position.z=.17;bg.add(bs);const bl=Museum.lab('DEPARTURES',3);bg.add(bl);
 const bh=new T.Mesh(new T.SphereGeometry(5,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));bh.position.z=1;bh.userData.id='board';bg.add(bh);hits.push(bh);
 // lights
 [[0xffc9a0,0,9,-6,1.6,30],[0xff9fc0,0,3,4,1.1,22],[0xd9b8ff,0,6,-14,.8,26]].forEach(a=>{const l=new T.PointLight(a[0],a[4],a[5],2);l.position.set(a[1],a[2],a[3]);grp.add(l)})}
function finish(){UI.close();GS.goToSection7()}
GS.goToSection7=()=>{veil.style.transition='opacity 1.6s ease';veil.style.background='#f4ecff';veil.style.opacity=1;setTimeout(()=>{S.hide();Mirror.enter()},1700)};
return Object.assign(S,{
 reset(){viewed.clear()},
 enter(){if(!grp)build();View.reset();S.active=true;fogS.forEach(f=>f.visible=false);moonL.visible=true;hemi=scene.children.find(o=>o.isHemisphereLight);if(hemi){hv2=hemi.intensity;hemi.intensity=.35}grp.visible=true;
  scene.fog.color.set(0x0f0a14);scene.fog.near=30;scene.fog.far=140;focus=null;tgy=null;ti=0;cam.position.set(0,3.4,17);look.set(0,5.2,-8);
  veil.style.transition='background .9s ease, opacity 2.4s ease 2.4s';veil.style.background='#07050d';veil.style.opacity=0;say();gh.classList.add('on');
  gt.innerHTML='<b>'+C.title+'</b><i style="letter-spacing:.2em">'+C.sub+'</i>';gt.classList.remove('show');void gt.offsetWidth;gt.classList.add('show')},
 hide(){S.active=false;grp.visible=false;gh.classList.remove('on');gt.classList.remove('show');if(hemi)hemi.intensity=hv2;fogS.forEach(f=>f.visible=true)},
 leave(){if(!grp)return;S.active=false;grp.visible=false;gh.classList.remove('on');gt.classList.remove('show');UI.close();if(hemi)hemi.intensity=hv2;fogS.forEach(f=>f.visible=true)},
 tap(e){v2.set(e.clientX/innerWidth*2-1,-(e.clientY/innerHeight)*2+1);ray.setFromCamera(v2,cam);const q=ray.intersectObjects(hits)[0];if(!q)return;const id=q.object.userData.id;
  if(id==='board'){if(viewed.size<E.length){say(C.lock);return}focus='board';UI.puzzle(C.puzzle,finish,()=>{focus=null})}
  else{if(busy)return;const i=E.findIndex(x=>x.id===id),d=ll(E[i].lon,E[i].lat,1);tgy=Math.atan2(d.z,d.x)-Math.PI/2;focus=id;viewed.add(id);say();
  const open=()=>{busy=false;UI.exhibit(E[i],()=>{focus=null;tgy=null})};
  if(pins[i].t<0){pins[i].t=tnow;pins[i].g.visible=true;hits.push(pins[i].h);busy=true;setTimeout(open,1700)}else open()}},
 update(dt,t){sx+=(nx-sx)*.04;ti+=dt;
  if(focus==='board'){tp.set(0,8.5,-1);tl.set(0,9.4,-18)}else if(focus){tp.set(0,4.2,5);tl.set(0,3.8,-6)}else{tp.set(sx*1.5,3.4,11);tl.set(-sx*1.5,5.2,-8)}
  cam.position.lerp(tp,1-Math.exp(-dt*(ti<4?.8:2.2)));look.lerp(tl,1-Math.exp(-dt*2.5));cam.lookAt(look);View.apply(cam,dt,!!focus);
  if(tgy!==null){let d=(tgy-gg.rotation.y+Math.PI)%6.2832;if(d<0)d+=6.2832;d-=Math.PI;gg.rotation.y+=d*(1-Math.exp(-dt*2.5))}else if(!reduce)gg.rotation.y+=dt*.08;
  grp.children.forEach(o=>{if(o.userData.rot)o.rotation.z+=dt*.05});
  tnow=t;pins.forEach((p,i)=>{if(p.t<0)return;const a=t-p.t,k=Math.min(1,a/.7),s2=1+2.7*Math.pow(k-1,3)+1.7*Math.pow(k-1,2);p.g.scale.setScalar(Math.max(.001,s2));p.g2.scale.setScalar(.9+.15*Math.sin(t*3+i));p.r.forEach((rg,j)=>{const u=(a-.2*j)/1.6;if(u>0&&u<1){rg.visible=true;rg.scale.setScalar(1+u*10);rg.material.opacity=(1-u)*.9}else rg.visible=false})});
  arcM.forEach((m,i)=>m.visible=pins[i].t>=0&&pins[i+1].t>=0);const va=arcs.map((q,i)=>i).filter(i=>arcM[i].visible);fl.visible=va.length>0;if(va.length&&!reduce){const k=va[Math.floor(t*.18)%va.length];fl.position.copy(arcs[k].getPoint((t*.18)%1))}
  if(++fc%20===0)drawBoard(t)
  R.render(scene,cam)}
})})();
