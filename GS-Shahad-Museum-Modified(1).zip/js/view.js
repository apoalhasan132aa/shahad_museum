/* GS dual-stick controller
   Left: walk (garden only). Right: look. Keyboard: WASD + arrow keys.
   The camera look offset is applied after each scene's own lookAt(), so it never accumulates drift. */
const View=(()=>{
 const v={yaw:0,pitch:0,jx:0,jy:0,mx:0,my:0,free:false};
 const Rr=25,Y=new THREE.Vector3(0,1,0),K={};
 const isTyping=()=>{const a=document.activeElement;return !!(a&&(/INPUT|TEXTAREA|SELECT/.test(a.tagName)||a.isContentEditable))};
 const wrapAngle=a=>{a=(a+Math.PI)%(Math.PI*2);if(a<0)a+=Math.PI*2;return a-Math.PI};
 function makeStick({side,label,colour,aria}){
  const base=document.createElement('div'),knob=document.createElement('div'),center=document.createElement('div');
  base.setAttribute('aria-label',aria);base.setAttribute('role','group');base.title=label;
  base.style.cssText=`position:fixed;${side}:max(12px,env(safe-area-inset-${side},12px));bottom:calc(22px + env(safe-area-inset-bottom,0px));width:94px;height:94px;border-radius:50%;background:radial-gradient(circle at 50% 50%,rgba(255,255,255,.035) 0 22%,rgba(12,8,22,.72) 23% 100%);border:1px solid ${colour};backdrop-filter:blur(7px);-webkit-backdrop-filter:blur(7px);touch-action:none;user-select:none;-webkit-user-select:none;z-index:4;box-shadow:inset 0 0 0 5px rgba(255,255,255,.025),0 0 24px ${colour};display:flex;align-items:center;justify-content:center`;
  const inner=document.createElement('div');inner.style.cssText='position:absolute;inset:8px;border:1px solid rgba(255,255,255,.09);border-radius:50%;pointer-events:none';base.appendChild(inner);
  center.textContent=label.toUpperCase();center.style.cssText='position:absolute;bottom:9px;left:0;right:0;text-align:center;font:700 8px/1 Arial,sans-serif;letter-spacing:2px;color:rgba(255,245,252,.48);pointer-events:none';base.appendChild(center);
  knob.style.cssText=`position:absolute;left:50%;top:50%;width:42px;height:42px;margin:-21px 0 0 -21px;border-radius:50%;background:radial-gradient(circle at 35% 28%,#fff,${side==='left'?'#fff0d6':'#ffd0e6'} 28%,${side==='left'?'#c49a71':'#d76bb2'} 100%);border:1px solid rgba(255,255,255,.35);box-shadow:0 0 18px ${colour},inset 0 1px 4px rgba(255,255,255,.5);pointer-events:none;will-change:transform`;
  base.appendChild(knob);document.body.appendChild(base);
  let pointer=null,lastTap=0,held=false;
  const set=e=>{
   const b=base.getBoundingClientRect(),dx=e.clientX-(b.left+b.width/2),dy=e.clientY-(b.top+b.height/2),
    d=Math.min(Math.hypot(dx,dy),Rr),a=Math.atan2(dy,dx),raw=d/Rr,
    x=Math.cos(a)*raw,y=Math.sin(a)*raw;
   // Keep the thumb movement physical, but apply a small dead zone to input so
   // accidental near-centre touches don't slowly move the player/camera.
   knob.style.transform=`translate(${x*Rr}px,${y*Rr}px)`;
   const dead=.12,mag=raw<=dead?0:Math.min(1,(raw-dead)/(1-dead));
   return{x:Math.cos(a)*mag,y:Math.sin(a)*mag}
  };
  const reset=()=>{pointer=null;held=false;knob.style.transition='transform .13s ease-out';knob.style.transform='translate(0,0)';};
  base.addEventListener('pointerdown',e=>{if(pointer!==null)return;pointer=e.pointerId;held=true;try{base.setPointerCapture(pointer)}catch(_){}knob.style.transition='none';const now=performance.now();if(now-lastTap<330&&side==='right'){v.yaw=0;v.pitch=0}lastTap=now;const a=set(e);if(side==='right'){v.jx=a.x;v.jy=a.y}else{v.mx=a.x;v.my=a.y}e.preventDefault()});
  base.addEventListener('pointermove',e=>{if(e.pointerId!==pointer)return;const a=set(e);if(side==='right'){v.jx=a.x;v.jy=a.y}else{v.mx=a.x;v.my=a.y}e.preventDefault()});
  const end=e=>{if(e.pointerId!==pointer)return;if(side==='right'){v.jx=v.jy=0}else{v.mx=v.my=0}reset()};
  base.addEventListener('pointerup',end);base.addEventListener('pointercancel',end);base.addEventListener('lostpointercapture',e=>{if(e.pointerId===pointer)end(e)});base.addEventListener('contextmenu',e=>e.preventDefault());
  return{base,reset,isHeld:()=>held};
 }
 const look=makeStick({side:'right',label:'Look',colour:'rgba(255,143,207,.42)',aria:'عصا النظر — اسحب لتحريك الرؤية، انقر مرتين لإعادة التوسيط'});
 const move=makeStick({side:'left',label:'Walk',colour:'rgba(227,191,148,.42)',aria:'عصا المشي — اسحب للتحرك للأمام والخلف والجانبين'});
 move.base.style.display='none';
 addEventListener('keydown',e=>{if(isTyping())return;const k=e.key.toLowerCase();if(['w','a','s','d','arrowup','arrowdown','arrowleft','arrowright'].includes(k)){K[k]=1;if(k.startsWith('arrow'))e.preventDefault()} });
 addEventListener('keyup',e=>{K[e.key.toLowerCase()]=0});
 const clearInput=()=>{Object.keys(K).forEach(k=>K[k]=0);v.jx=v.jy=v.mx=v.my=0;look.reset();move.reset()};
 addEventListener('blur',clearInput);
 document.addEventListener('visibilitychange',()=>{if(document.hidden)clearInput()});
 v.showMove=on=>{move.base.style.display=on?'flex':'none';if(!on){v.mx=v.my=0;move.reset()}};
 v.move=()=>{const kx=(K.d?1:0)-(K.a?1:0),ky=(K.s?1:0)-(K.w?1:0);return{x:move.isHeld()?v.mx:(v.mx||kx),y:move.isHeld()?v.my:(v.my||ky)}};
 v.reset=()=>{clearInput();v.yaw=0;v.pitch=0;v.free=false};
 v.apply=(cam,dt,focused)=>{
  // Each active scene calls cam.lookAt() before apply. This creates a stable base orientation on every frame.
  const safeDt=Math.min(Math.max(dt||0,0),.05);
  if(focused){const d=1-Math.exp(-safeDt*4.2);v.yaw-=v.yaw*d;v.pitch-=v.pitch*d}
  else{
   const ax=look.isHeld()?v.jx:((K.arrowright?1:0)-(K.arrowleft?1:0));
   const ay=look.isHeld()?v.jy:((K.arrowdown?1:0)-(K.arrowup?1:0));
   const sensitivity=v.free?2.0:1.6;
   if(Math.abs(ax)>.025)v.yaw-=ax*safeDt*sensitivity;
   if(Math.abs(ay)>.025)v.pitch-=ay*safeDt*1.3;
   if(v.free)v.yaw=wrapAngle(v.yaw);else v.yaw=Math.max(-1.42,Math.min(1.42,v.yaw));
   v.pitch=Math.max(-.82,Math.min(.82,v.pitch));
  }
  // Applying offsets to the fresh lookAt quaternion avoids accumulated camera roll/drift.
  cam.rotateOnWorldAxis(Y,v.yaw);cam.rotateX(v.pitch);
 };
 return v;
})();

/* Mobile-readable diagnostics — hidden until a real runtime error occurs. */
(()=>{let b=null;const show=m=>{if(!b){b=document.createElement('div');b.style.cssText='position:fixed;left:8px;right:8px;top:8px;max-height:30vh;overflow:auto;z-index:99;background:rgba(60,8,24,.92);color:#ffd9e2;font:12px/1.5 monospace;padding:8px 10px;border-radius:8px;direction:ltr;white-space:pre-wrap';b.onclick=()=>{b.style.display='none'};document.body.appendChild(b)}b.style.display='block';const q=String(m).slice(0,240),L=(window.__gl=window.__gl||[]);if(L[L.length-1]!==q)L.push(q);b.textContent='GS errors:\n'+window.__gl.slice(-6).join('\n')};
 addEventListener('error',e=>show(e.message+(e.filename?' @'+e.filename.split('/').pop()+':'+e.lineno:'')));addEventListener('unhandledrejection',e=>show(e.reason&&e.reason.message||e.reason));window.GSerr=show})();
