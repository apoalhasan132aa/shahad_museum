/* القسم 07 — THE LOCKED ROOM (القاعة التي لا تُفتح إلا لمن يفهم الرمز) */
window.Locked=(()=>{
const S={active:false},C=CONTENT.locked,ex={},hits=[],viewed=new Set(),tp=new T.Vector3(),tl=new T.Vector3(),look=new T.Vector3(0,3,-8),zs=[6,2,-4,-11,-17,-22],runes=[],flames=[];
let grp,focus=null,si=0,ti=0,nb,pb2,fc=0,ch4=1,doorL,doorR,roseC,roseP,openL=0,opening=false,solved=false,pathGlow,innerLight;
const gt=document.getElementById('gt'),gh=document.getElementById('gh');
const say=m=>{gh.textContent=m||C.hint};
const nav=()=>{nb.style.display=si<zs.length-1?'block':'none';pb2.style.display=si>0?'block':'none'},go=d=>{if(focus)return;si=Math.max(0,Math.min(zs.length-1,si+d));nav()};
function mkb(t,css,fn){const b=document.createElement('button');b.className='go';b.textContent=t;b.style.cssText='position:fixed;bottom:calc(140px + env(safe-area-inset-bottom,0px));background:rgba(12,8,22,.6);z-index:3;display:none;'+css;b.onclick=fn;document.body.appendChild(b);return b}
function build(){
 grp=new T.Group();scene.add(grp);const r=rnd(99),add=(m,x,y,z)=>{m.position.set(x,y,z);grp.add(m);return m},mk=(w,h,d,m,x,y,z)=>add(new T.Mesh(new T.BoxGeometry(w,h,d),m),x,y,z);
 const stone=M(0x191521,.7,.25),stone2=M(0x211b2e,.65,.3),bronze=M(0x6b4a26,.45,.75,0x1a0f05),gold=M(0x8a6a30,.35,.85,0x201504);
 const deepRed=new T.MeshStandardMaterial({color:0x6b1030,roughness:.4,metalness:.3,emissive:0x30060f,emissiveIntensity:.8});
 const glow=(c,op,s,x,y,z,p)=>{const q=new T.Sprite(new T.SpriteMaterial({map:GT,color:c,opacity:op,transparent:true,depthWrite:false,blending:T.AdditiveBlending}));q.scale.set(s,s,1);q.position.set(x,y,z);(p||grp).add(q);return q};
 // أرضية حجرية لامعة + جدران مرتفعة
 add(new T.Mesh(new T.PlaneGeometry(22,34),new T.MeshStandardMaterial({color:0x0f0c16,roughness:.38,metalness:.35,bumpMap:NT,bumpScale:.07})),0,0,-10).rotation.x=-Math.PI/2;
 const wl=M(0x171221,.75,.2);mk(.5,11,34,wl,-11.2,5.5,-10);mk(.5,11,34,wl,11.2,5.5,-10);mk(22.5,11,.5,wl,0,5.5,-27.2);mk(22.5,11,.5,wl,0,5.5,8.2);mk(22.5,.5,34,M(0x080610,.9),0,11.2,-10);
 // أعمدة ضخمة على الجانبين
 [-1,1].forEach(s=>{for(let z=4;z>-26;z-=7.5){
  mk(1.3,10.5,1.3,stone,s*8.6,5.25,z);mk(1.7,.5,1.7,stone2,s*8.6,10.7,z);mk(1.7,.5,1.7,stone2,s*8.6,.25,z);
  mk(1.5,.28,1.5,bronze,s*8.6,9.6,z);mk(1.5,.28,1.5,bronze,s*8.6,.7,z);
  const lp=mk(.16,.7,.16,bronze,s*7.7,4.6,z);lp.userData.flame=1;
  const fl=glow(0xff9a3c,.5,.9,s*7.6,5.3,z);flames.push({s:fl,ph:r()*6.283});
  const pl=new T.PointLight(0xff8a30,.5,13,2);pl.position.set(s*7.4,5.3,z);grp.add(pl)}});
 // زخارف هندسية على الجدران
 const zg=new T.PlaneGeometry(.9,.9),zm=new T.MeshStandardMaterial({color:0x2a2138,roughness:.6,metalness:.4,emissive:0x0d0816,emissiveIntensity:1});
 for(let z=2;z>-26;z-=3.8)[-1,1].forEach(s=>{const p=add(new T.Mesh(zg,zm),s*10.9,6.2,z);p.rotation.y=s<0?Math.PI/2:-Math.PI/2;
  const f=add(new T.Mesh(new T.PlaneGeometry(1.1,.06),gold),s*10.88,6.2,z);f.rotation.y=p.rotation.y;
  const f2=add(new T.Mesh(new T.PlaneGeometry(.06,1.1),gold),s*10.88,6.2,z);f2.rotation.y=p.rotation.y});
 // نقوش أرضية تقود إلى الباب
 for(let i=0;i<9;i++){const z=4-i*3.4;const ln=mk(.5+i*.06,.02,.28,gold,0,.02,z);ln.material=gold;runes.push({m:ln,k:'path',i});
  [-1,1].forEach(s=>mk(.07,.02,1.1,bronze,s*(1.6+i*.14),.02,z-1.2))}
 // منصة أمام الباب
 for(let i=0;i<3;i++)mk(9-i*1.1,.22,2.4-i*.4,stone2,0,.11+i*.22,-23.4-i*.5);
 // ==== الباب الضخم THE SEALED GATE ====
 const dg=new T.Group();dg.position.set(0,0,-25.4);grp.add(dg);
 const db=(w,h,d,m,x,y,z)=>{const k=new T.Mesh(new T.BoxGeometry(w,h,d),m);k.position.set(x,y,z);dg.add(k);return k};
 // الإطار الحجري بقوس
 db(1.4,9.6,1.6,stone,-3.4,4.8,0);db(1.4,9.6,1.6,stone,3.4,4.8,0);
 const arch=new T.Mesh(new T.TorusGeometry(3.4,.7,10,40,Math.PI),stone);arch.position.set(0,9.6,0);dg.add(arch);
 db(9.6,1,2,stone2,0,10.4,0);
 [-1,1].forEach(s=>{db(.5,8.6,.5,gold,s*2.55,4.6,.85);db(.5,8.6,.5,gold,s*2.55,4.6,-.85)});
 // ورقة الباب: نصفان ينزلقان
 const doorM=new T.MeshStandardMaterial({color:0x241c33,roughness:.5,metalness:.55,emissive:0x0a0612,emissiveIntensity:1});
 doorL=db(2.62,8.2,.55,doorM,-1.31,4.6,.15);doorR=db(2.62,8.2,.55,doorM,1.31,4.6,.15);
 // نقوش محفورة على الوريقات
 [-1,1].forEach(s=>{for(let i=0;i<4;i++){const bar=db(.9,.1,.06,gold,s*1.31,1.6+i*1.9,.45);bar.rotation.z=s*.5;
  runes.push({m:bar,k:'door',i:i+(s>0?4:0)})}});
 // رمز الوردة غير المكتمل في المركز
 roseC=new T.Group();roseC.position.set(0,4.8,.5);dg.add(roseC);
 const petalM=new T.MeshStandardMaterial({color:0x571428,roughness:.5,metalness:.3,emissive:0x1c030a,emissiveIntensity:1});
 roseP=[];
 for(let i=0;i<6;i++){const a=i/6*Math.PI*2;const p=new T.Mesh(new T.SphereGeometry(.34,10,8),petalM.clone());
  p.scale.set(1,.55,.35);p.position.set(Math.cos(a)*.52,Math.sin(a)*.52,0);p.rotation.z=a;roseC.add(p);roseP.push(p)}
 const heart=new T.Mesh(new T.SphereGeometry(.3,12,10),petalM.clone());roseC.add(heart);roseP.push(heart);
 // رموز صغيرة حول الوردة تُضاء تباعًا
 for(let i=0;i<6;i++){const a=i/6*Math.PI*2+.5;const sm=new T.Mesh(new T.BoxGeometry(.14,.14,.06),deepRed.clone());
  sm.position.set(Math.cos(a)*1.15,Math.sin(a)*1.15,0);roseC.add(sm);runes.push({m:sm,k:'rose',i})}
 const ring=new T.Mesh(new T.TorusGeometry(1.15,.05,8,40),bronze);roseC.add(ring);
 // الممر خلف الباب (مخفي حتى الفتح)
 innerLight=new T.PointLight(0xffc9a0,0,20,2);innerLight.position.set(0,4,-27.5);dg.add(innerLight);
 pathGlow=glow(0xffb37a,0,7,0,3,-27);pathGlow.material.opacity=0;
 glow(0xff5f7a,.1,5,0,4.8,.9); // توهج أحمر وردي خافت دائم حول الرمز
 // لوحة العنوان
 const lb=Museum.lab('THE SEALED GATE',5.8);lb.position.set(0,10.9,.4);dg.add(lb);
 const th=new T.Mesh(new T.SphereGeometry(3.4,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));th.position.set(0,3.6,1.4);th.userData.id='gate';dg.add(th);hits.push(th);ex.gate=new T.Vector3(0,0,-25.4);
 // ==== عناصر التلميح ====
 // 1) النقش الحجري (بتلات غير مكتملة) على جدار أيسر
 const eg=new T.Group();eg.position.set(-10.6,0,-6);eg.rotation.y=Math.PI/2;grp.add(eg);
 const eb=(w,h,d,m,x,y,z)=>{const k=new T.Mesh(new T.BoxGeometry(w,h,d),m);k.position.set(x,y,z);eg.add(k);return k};
 eb(2.4,2.4,.2,stone2,0,4,0);eb(2.7,2.7,.1,bronze,0,4,-.06);
 for(let i=0;i<5;i++){const a=i/5*Math.PI*2;const p=new T.Mesh(new T.SphereGeometry(.26,8,6),M(0x352a4a,.6,.3));
  p.scale.set(1,.5,.3);p.position.set(Math.cos(a)*.62,4+Math.sin(a)*.62,.12);p.rotation.z=a;eg.add(p)}
 const eh=new T.Mesh(new T.SphereGeometry(2,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));eh.position.set(0,4,.6);eh.userData.id='engrave';eg.add(eh);hits.push(eh);ex.engrave=new T.Vector3(-10.6,0,-6);
 // 2) اللوحة البرونزية على قاعدة جانبية يمينًا
 const bg2=new T.Group();bg2.position.set(9.2,0,-13);bg2.rotation.y=-Math.PI/2+.3;grp.add(bg2);
 const bb=(w,h,d,m,x,y,z)=>{const k=new T.Mesh(new T.BoxGeometry(w,h,d),m);k.position.set(x,y,z);bg2.add(k);return k};
 bb(.9,1.5,.9,stone,0,.75,0);bb(1.2,.14,1.2,stone2,0,1.55,0);
 bb(2.2,1.4,.1,bronze,0,2.6,0);bb(2.35,1.55,.06,gold,0,2.6,-.05);
 // نقش نصي رمزي على اللوحة (خطوط)
 for(let i=0;i<5;i++)bb(1.6-i*.12,.05,.03,deepRed,0,3.05-i*.22,.06);
 const bh=new T.Mesh(new T.SphereGeometry(2,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));bh.position.set(0,2.6,.6);bh.userData.id='bronze';bg2.add(bh);hits.push(bh);ex.bronze=new T.Vector3(9.2,0,-13);
 // ==== عناصر مخفية ====
 // وردة حجرية على عمود
 const sr=new T.Group();sr.position.set(-8.6,3.4,4);grp.add(sr);
 const sp2=M(0x4a3f5e,.55,.35);
 for(let i=0;i<5;i++){const a=i/5*Math.PI*2;const p=new T.Mesh(new T.SphereGeometry(.16,8,6),sp2);p.scale.set(1,.5,.4);p.position.set(Math.cos(a)*.2,Math.sin(a)*.2,0);p.rotation.z=a;sr.add(p)}
 sr.add(new T.Mesh(new T.SphereGeometry(.12,8,6),sp2));
 const srh=new T.Mesh(new T.SphereGeometry(1,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));srh.userData.id='rose1';sr.add(srh);hits.push(srh);ex.rose1=new T.Vector3(-8.6,0,4);
 // صندوق زجاجي بوردة
 const bx=new T.Group();bx.position.set(7.6,0,-19.5);bx.rotation.y=-.5;grp.add(bx);
 const xb=(w,h,d,m,x,y,z)=>{const k=new T.Mesh(new T.BoxGeometry(w,h,d),m);k.position.set(x,y,z);bx.add(k);return k};
 xb(1.4,.9,1.4,stone,0,.45,0);xb(1.7,.12,1.7,stone2,0,.96,0);
 const glass=new T.Mesh(new T.BoxGeometry(1.2,1.2,1.2),new T.MeshPhongMaterial({color:0xcfe0ff,transparent:true,opacity:.16,shininess:100,specular:0xffffff}));glass.position.set(0,1.65,0);bx.add(glass);
 const rp2=new T.MeshStandardMaterial({color:0xa01840,roughness:.35,metalness:.2,emissive:0x40081a,emissiveIntensity:1});
 const rose3d=new T.Group();rose3d.position.set(0,1.55,0);bx.add(rose3d);
 for(let i=0;i<6;i++){const a=i/6*Math.PI*2;const p=new T.Mesh(new T.ConeGeometry(.16,.4,6),rp2);p.position.set(Math.cos(a)*.2,.28,Math.sin(a)*.2);p.rotation.set(.5,0,0);p.rotation.y=-a;rose3d.add(p)}
 rose3d.add(new T.Mesh(new T.SphereGeometry(.14,10,8),rp2));
 const st2=new T.Mesh(new T.CylinderGeometry(.03,.03,.5,6),M(0x2a4428,.7,.1));st2.position.set(0,1.1,0);bx.add(st2);
 const bxh=new T.Mesh(new T.SphereGeometry(1.4,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));bxh.position.set(0,1.6,0);bxh.userData.id='rose2';bx.add(bxh);hits.push(bxh);ex.rose2=new T.Vector3(7.6,0,-19.5);
 // نقش مخفي في ظل جدار
 const hd=new T.Group();hd.position.set(-10.7,0,-21);hd.rotation.y=Math.PI/2;grp.add(hd);
 const hb=(w,h,d,m,x,y,z)=>{const k=new T.Mesh(new T.BoxGeometry(w,h,d),m);k.position.set(x,y,z);hd.add(k);return k};
 hb(1.6,1,.12,M(0x141020,.8,.2),0,1.4,0);hb(1.8,1.2,.06,bronze,0,1.4,-.05);
 const hdm=new T.Mesh(new T.TorusGeometry(.3,.04,6,20),gold);hdm.position.set(0,1.45,.08);hd.add(hdm);
 const hdh=new T.Mesh(new T.SphereGeometry(1.6,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));hdh.position.set(0,1.4,.5);hdh.userData.id='rose3';hd.add(hdh);hits.push(hdh);ex.rose3=new T.Vector3(-10.7,0,-21);
 // غبار خافت جدًا
 const MN=mobile?50:110,mp=new Float32Array(MN*3);for(let i=0;i<MN;i++)mp.set([(Math.random()-.5)*20,Math.random()*9,7-Math.random()*32],i*3);
 grp.add(new T.Points(new T.BufferGeometry().setAttribute('position',new T.BufferAttribute(mp,3)),new T.PointsMaterial({map:GT,size:.07,color:0xbfae9a,transparent:true,opacity:.18,depthWrite:false,blending:T.AdditiveBlending})))}
function openDoor(){if(opening||solved)return;opening=true;solved=true;
 const seq=[...roseP,...runes.filter(x=>x.k==='rose').map(x=>x.m)];
 seq.forEach((m,i)=>setTimeout(()=>{m.material.emissive=new T.Color(0xff2f5a);m.material.emissiveIntensity=1.6;const gl2=m.material;if(m.geometry&&m.geometry.type==='BoxGeometry'){m.scale.setScalar(1.25)}},300+i*260));
 setTimeout(()=>{runes.filter(x=>x.k==='door').forEach((x,i)=>setTimeout(()=>{x.m.material.emissive=new T.Color(0xff2f5a);x.m.material.emissiveIntensity=.9},i*120))},2100);
 setTimeout(()=>{say('الطريق مفتوح… اذهبي')},3400)}
function finish(){UI.close();focus=null;veil.style.transition='opacity 1.8s ease';veil.style.background='#0c0d15';veil.style.opacity=1;setTimeout(()=>{S.hide();Empty.enter()},1900)}
return Object.assign(S,{
 reset(){viewed.clear();solved=false;opening=false;openL=0;
  if(doorL){doorL.position.x=-1.31;doorR.position.x=1.31;innerLight.intensity=0;pathGlow.material.opacity=0;
   roseP.forEach(p=>{p.material.emissive=new T.Color(0x1c030a);p.material.emissiveIntensity=1});
   runes.forEach(x=>{if(x.k==='rose'){x.m.material.emissive=new T.Color(0x30060f);x.m.scale.setScalar(1)}if(x.k==='door'){x.m.material.emissive=new T.Color(0x201504);x.m.material.emissiveIntensity=1}})}},
 enter(){if(!grp){build();nb=mkb('تقدّمي ‹','left:calc(50% + 8px)',()=>go(1));pb2=mkb('› رجوع','right:calc(50% + 8px)',()=>go(-1))}
  View.reset();S.active=true;fogS.forEach(f=>f.visible=false);const h=scene.children.find(o=>o.isHemisphereLight);if(h){ch4=h.intensity;h.intensity=.16}grp.visible=true;
  scene.fog.color.set(0x0b0810);scene.fog.near=15;scene.fog.far=62;si=0;focus=null;ti=0;setTimeout(()=>{if(S.active)nav()},3500);cam.position.set(0,3,7.6);look.set(0,3,-8);
  veil.style.transition='background .9s ease, opacity 2.4s ease 2.4s';veil.style.background='#050308';veil.style.opacity=0;say();gh.classList.add('on');
  gt.innerHTML='<b>'+C.title+'</b><i>'+C.sub+'</i>';gt.classList.remove('show');void gt.offsetWidth;gt.classList.add('show')},
 hide(){S.active=false;grp.visible=false;nb.style.display=pb2.style.display='none';gh.classList.remove('on');gt.classList.remove('show');UI.close();const h=scene.children.find(o=>o.isHemisphereLight);if(h)h.intensity=ch4;fogS.forEach(f=>f.visible=true)},
 leave(){if(!grp)return;S.active=false;grp.visible=false;nb.style.display=pb2.style.display='none';gh.classList.remove('on');gt.classList.remove('show');UI.close();focus=null;const h=scene.children.find(o=>o.isHemisphereLight);if(h)h.intensity=ch4;fogS.forEach(f=>f.visible=true)},
 tap(e){v2.set(e.clientX/innerWidth*2-1,-(e.clientY/innerHeight)*2+1);ray.setFromCamera(v2,cam);const q=ray.intersectObjects(hits)[0];if(!q)return;const id=q.object.userData.id;
  if(id==='gate'){if(solved){if(openL>.85)finish();else focus='gate';return}
   focus='gate';UI.puzzle({q:C.puzzle.q,answers:C.puzzle.answers,ok:C.puzzle.ok,wrong:C.puzzle.wrong,check:C.puzzle.check,ph:C.puzzle.ph,title:C.puzzleTitle},()=>{openDoor();setTimeout(()=>{focus=null},600)},()=>{focus=null});return}
  const it=C.items.find(x=>x.id===id);if(it){viewed.add(id);focus=id;UI.exhibit({title:it.title,text:it.text,img:it.img},()=>{focus=null});return}
  const hn=C.hints.find(x=>x.id===id);if(hn){focus=id;UI.exhibit({title:'تلميح',text:hn.text,img:hn.img},()=>{focus=null})}},
 update(dt,t){sx+=(nx-sx)*.04;const f=focus&&ex[focus];ti+=dt;
  if(f){if(focus==='gate'){tp.set(0,3.1,-18.6);tl.set(0,4.4,-25.4)}else{tp.set(f.x*.3,3.1,f.z+5.6);tl.set(f.x,3,f.z)}}else{tp.set(sx*1.5,3,zs[si]);tl.set(-sx*1.5,3.2,zs[si]-12)}
  cam.position.lerp(tp,1-Math.exp(-dt*(ti<4?.8:2.2)));look.lerp(tl,1-Math.exp(-dt*2.3));cam.lookAt(look);View.apply(cam,dt,!!focus);
  // تلميح الاقتراب من الباب
  if(!focus&&!opening){if(Math.abs(cam.position.z+22)<2.6)gh.textContent=C.approach;else say()}
  // فتح الباب: انزلاق + ضوء دافئ
  if(solved&&openL<1){openL=Math.min(1,openL+dt*.14);
   doorL.position.x=-1.31-openL*2.3;doorR.position.x=1.31+openL*2.3;
   innerLight.intensity=openL*1.5;pathGlow.material.opacity=openL*.5;
   if(openL>=1&&!focus)say('الطريق مفتوح… اذهبي')}
  // ألسنة اللهب
  if(!reduce){flames.forEach(fl=>{fl.ph+=dt*7;fl.s.material.opacity=.4+.14*Math.sin(fl.ph)+.06*Math.sin(fl.ph*2.7)});
   if(++fc%5===0){/* غبار ثابت */}}
  R.render(scene,cam)}
})})();