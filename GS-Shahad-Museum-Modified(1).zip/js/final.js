/* القسم 10 — THE FINAL STAR · GS — UNWRITTEN (قلب المتحف) */
window.Final=(()=>{
const S={active:false},C=CONTENT.final,ex={},hits=[],viewed=new Set(),tp=new T.Vector3(),tl=new T.Vector3(),look=new T.Vector3(0,4,-10),zs=[6,1,-4,-9],orbiters=[],beamM=[];
let grp,focus=null,si=0,ti=0,nb,pb2,fc=0,ch7=1,cine,intro=0,introT=0,starCore,starLayers=[],starRing,compBtn,done=0,doneFired=false,constel=[],dimL=[];
const gt=document.getElementById('gt'),gh=document.getElementById('gh');
const say=m=>{gh.textContent=m||C.hint};
const nav=()=>{nb.style.display=(si<zs.length-1&&!intro&&!done)?'block':'none';pb2.style.display=(si>0&&!intro&&!done)?'block':'none'},go=d=>{if(focus||intro||done)return;si=Math.max(0,Math.min(zs.length-1,si+d));nav()};
function mkb(t,css,fn){const b=document.createElement('button');b.className='go';b.textContent=t;b.style.cssText='position:fixed;bottom:calc(140px + env(safe-area-inset-bottom,0px));background:rgba(12,8,22,.6);z-index:3;display:none;'+css;b.onclick=fn;document.body.appendChild(b);return b}
const LS={get un(){try{return JSON.parse(localStorage.getItem('gs_unwritten')||'{}')}catch(e){return{}}},set un(v){try{localStorage.setItem('gs_unwritten',JSON.stringify(v))}catch(e){}}};
// ==== سينمائي ====
function buildCine(){if(cine)return;cine=document.createElement('div');cine.style.cssText='position:fixed;inset:0;z-index:7;display:none;align-items:center;justify-content:center;pointer-events:none;background:rgba(2,2,8,.3)';const t=document.createElement('div');t.id='fnCine';t.style.cssText='color:#f2effa;font:italic 400 clamp(18px,3vw,28px)/1.8 "Cormorant Garamond","Amiri",serif;text-align:center;max-width:640px;padding:0 24px;opacity:0;transition:opacity 1.6s ease;text-shadow:0 2px 34px rgba(0,0,0,.9)';cine.appendChild(t);document.body.appendChild(cine)}
function cineText(h){const t=document.getElementById('fnCine');t.style.opacity=0;setTimeout(()=>{t.innerHTML=h;t.style.opacity=1},900)}
function endIntro(){if(!intro)return;intro=0;cine.style.opacity=0;setTimeout(()=>{cine.style.display='none';cine.style.opacity=1},1200);nav();say()}
// ==== نافذة عامة ====
let ov=null;
function btnS(p){return 'background:'+(p?'rgba(255,95,168,.16);border:1px solid #ec5f9d;color:#f6dbe6':'rgba(185,155,255,.1);border:1px solid rgba(185,155,255,.5);color:#d9d2ee')+';border-radius:20px;padding:9px 20px;font:600 15px "Cormorant Garamond",serif;cursor:pointer;margin:4px'}
function buildOv(){if(ov)return;ov=document.createElement('div');ov.id='fnOv';ov.style.cssText='position:fixed;inset:0;z-index:8;display:none;align-items:center;justify-content:center;background:rgba(3,3,10,.6);backdrop-filter:blur(3px);padding:16px';
 const card=document.createElement('div');card.style.cssText='max-width:560px;width:100%;max-height:78vh;overflow-y:auto;background:linear-gradient(165deg,rgba(22,18,40,.97),rgba(10,8,22,.97));border:1px solid rgba(185,155,255,.32);border-radius:14px;padding:24px 22px 16px;direction:rtl;text-align:center;box-shadow:0 0 60px rgba(185,155,255,.12)';
 card.innerHTML=`<div id="fnT" style="color:#f2a4c6;font:700 13px "Space Grotesk",sans-serif;letter-spacing:2px;margin-bottom:10px;direction:ltr"></div><div id="fnB" style="color:#f0ecf2;font:400 clamp(15px,2.2vw,19px)/1.9 "Cormorant Garamond","Amiri",serif"></div><div id="fnR" style="margin-top:14px;display:flex;gap:8px;justify-content:center;flex-wrap:wrap"></div>`;
 ov.appendChild(card);document.body.appendChild(ov);ov.addEventListener('click',e=>{if(e.target===ov)closeOv()});
 window.addEventListener('keydown',e=>{if(e.key==='Escape'&&ov.style.display=='flex')closeOv()})}
function showOv(title,body,buttons){buildOv();document.getElementById('fnT').textContent=title;document.getElementById('fnB').innerHTML=body;const r=document.getElementById('fnR');r.innerHTML='';
 (buttons||[{t:'إغلاق',p:false,fn:closeOv}]).forEach(b=>{const btn=document.createElement('button');btn.textContent=b.t;btn.style.cssText=btnS(b.p);btn.onclick=b.fn;r.appendChild(btn)});
 ov.style.display='flex'}
function closeOv(){if(ov)ov.style.display='none';focus=null}
// ==== محتوى العناصر ====
function momentsOv(){const M=C.obj.moments;focus='moments';
 showOv(M.title,'<p style="text-align:right;font-size:1.12em;line-height:2.1;color:#eceaf6">'+M.text+'</p>',[{t:'إغلاق',p:true,fn:closeOv}])}
function wordsOv(){focus='words';const W=C.obj.words;showOv(W.title,'<p style="text-align:right;font-size:1.08em;line-height:2">'+W.text+'</p>')}
function littleOv(){focus='little';const L=C.obj.little;
 const list=L.items.map((it,i)=>'<button data-i="'+i+'" style="display:block;width:100%;margin:4px 0;padding:9px;background:rgba(185,155,255,.07);border:1px solid rgba(185,155,255,.35);border-radius:10px;color:#f6dbe6;font:600 14px "Space Grotesk",sans-serif;letter-spacing:1px;cursor:pointer">'+it[0]+'</button>').join('');
 showOv(L.title,'<div id="fnList">'+list+'</div><div id="fnMsg" style="min-height:60px;margin-top:10px;color:#cfcbe4;font-style:italic"></div>');
 document.querySelectorAll('#fnList button').forEach(b=>b.onclick=()=>{document.querySelectorAll('#fnList button').forEach(x=>x.style.background='rgba(185,155,255,.07)');b.style.background='rgba(255,95,168,.14)';document.getElementById('fnMsg').textContent=L.items[+b.dataset.i][1]})}
function unwrittenOv(){const U=C.obj.unwritten,un=LS.un;focus='unwritten';
 const fields=U.prompts.map((p,i)=>{const v=un[i]||'';
  return '<div style="margin:8px 0;text-align:right"><div style="color:#f2a4c6;font-size:11px;letter-spacing:1px;font-family:"Space Grotesk",sans-serif;direction:ltr">'+p+'</div><textarea data-i="'+i+'" rows="2" placeholder="'+U.ph+'" style="width:100%;box-sizing:border-box;background:rgba(255,255,255,.06);border:1px solid rgba(185,155,255,.4);border-radius:8px;color:#f2effa;font:400 16px/1.7 "Cormorant Garamond","Amiri",serif;padding:8px 10px;direction:rtl;resize:none">'+v+'</textarea></div>'}).join('');
 showOv(U.title,'<p style="color:#cfcbe4">'+U.text+'</p>'+fields+'<div style="color:#8f8aa8;font-size:12px">'+U.local+'</div>',[
  {t:U.save,p:true,fn:()=>{const o={};document.querySelectorAll('#fnB textarea').forEach(t2=>o[t2.dataset.i]=t2.value.trim());LS.un=o;say(U.saved);closeOv()}},
  {t:U.del,p:false,fn:()=>{LS.un={};document.querySelectorAll('#fnB textarea').forEach(t2=>t2.value='')}},
  {t:'إغلاق',p:false,fn:closeOv}])}
function starOv(){focus='star';const ST=C.star;viewed.add('star');
 showOv(ST.title,'<p style="color:#b9b3d6;font-style:italic;margin-bottom:10px">'+ST.lines+'</p><p style="text-align:right;font-size:1.08em;line-height:2">'+ST.text+'</p>',[{t:'إغلاق',p:true,fn:closeOv}])}
// ==== الختام السينمائي ====
function startComplete(){if(doneFired)return;doneFired=true;done=1;nav();buildCine();cine.style.display='flex';
 beamM.forEach((b,i)=>setTimeout(()=>{b.target=.7},400+i*300));
 constel.forEach((l,i)=>setTimeout(()=>{l.target=.65},1400+i*500));
 dimL.forEach(l=>l.userData.dim=1);
 setTimeout(()=>cineText(C.cineTitle+'<br><span style="font-size:.6em;color:#b9b3d6;letter-spacing:3px">'+C.sub+'</span>'),1200);
 setTimeout(()=>cineText(C.cineLines),6600);
 setTimeout(()=>{cine.style.opacity=0;setTimeout(()=>{cine.style.display='none';cine.style.opacity=1},1200);startEnding()},11800)}
// ==== اللحظة الأخيرة: أحبج ====
let endStarted=false,endDOM=null;
function buildEnd(){if(endDOM)return;
 const bg=document.createElement('div');bg.id='fnEnd';
 bg.style.cssText='position:fixed;inset:0;z-index:9999;background:#000000;opacity:0;transition:opacity 2.5s ease;display:flex;align-items:center;justify-content:center;pointer-events:none';
 const w=document.createElement('div');w.id='fnWord';w.textContent='أحبج';
 w.style.cssText='color:#F5F1F2;font:400 clamp(44px,13vw,90px)/1.4 "Cormorant Garamond","Amiri",serif;opacity:0;transition:opacity 2s ease;text-shadow:0 0 34px rgba(255,240,245,.22);direction:rtl;pointer-events:auto;user-select:none;-webkit-user-select:none';
 bg.appendChild(w);document.body.appendChild(bg);endDOM={bg,w};
 let hold=null;
 const start=e=>{if(hold)return;hold=setTimeout(()=>{try{location.reload()}catch(err){}},2500)};
 const cancel=()=>{if(hold){clearTimeout(hold);hold=null}};
 w.addEventListener('touchstart',start,{passive:true});w.addEventListener('mousedown',start);
 w.addEventListener('touchend',cancel);w.addEventListener('touchcancel',cancel);w.addEventListener('mouseup',cancel)}
function startEnding(){if(endStarted)return;endStarted=true;buildEnd();
 const rm=window.reduce?1:0;
 // إخفاء واجهة القاعة
 gh.classList.remove('on');gt.classList.remove('show');gh.style.display='none';
 if(nb)nb.style.display='none';if(pb2)pb2.style.display='none';if(compBtn)compBtn.style.display='none';
 const snd=document.getElementById('snd');if(snd)snd.style.transition='opacity 1s';if(snd)snd.style.opacity=0;
 // 0-2.5: لحظة النجمة (الكاميرا already مركزة) — خفض الصوت تدريجيًا
 [0.45,0.3,0.16].forEach((v,i)=>setTimeout(()=>{if(window.GSduck)GSduck(v)},600+i*700));
 // 2.5-5: خفوت إلى الأسود
 setTimeout(()=>{endDOM.bg.style.opacity=1;if(snd)snd.style.display='none'},rm?400:2500);
 // 5-7: صمت (أسود خالص)
 setTimeout(()=>{S.hide();done=0;try{View.reset()}catch(e){}},rm?1200:5200);
 // 7-9: ظهور الكلمة
 setTimeout(()=>{endDOM.w.style.opacity=1},rm?1600:7000)}
function goHome(){S.hide();if(window.GS&&GS.replay)GS.replay();else{document.getElementById('rp').click()}}
// ==== بناء المرصد ====
function build(){
 grp=new T.Group();scene.add(grp);const r=rnd(13),add=(m,x,y,z)=>{m.position.set(x,y,z);grp.add(m);return m},mk=(w,h,d,m,x,y,z)=>add(new T.Mesh(new T.BoxGeometry(w,h,d),m),x,y,z);
 const stone=M(0x1a1726,.5,.5),sil=M(0xb9bbd6,.25,.85);
 const glow=(c,op,s,x,y,z,p)=>{const q=new T.Sprite(new T.SpriteMaterial({map:GT,color:c,opacity:op,transparent:true,depthWrite:false,blending:T.AdditiveBlending}));q.scale.set(s,s,1);q.position.set(x,y,z);(p||grp).add(q);return q};
 const layers=(n,size,spread,y0,y1,z0,z1,c,op)=>{const pos=new Float32Array(n*3);for(let i=0;i<n;i++)pos.set([(Math.random()-.5)*spread,y0+Math.random()*(y1-y0),z0+Math.random()*(z1-z0)],i*3);const m=new T.PointsMaterial({map:GT,size:size,color:c,transparent:true,opacity:op,depthWrite:false,blending:T.AdditiveBlending});grp.add(new T.Points(new T.BufferGeometry().setAttribute('position',new T.BufferAttribute(pos,3)),m));return m};
 // سماء عميقة + سُدُم
 layers(mobile?380:800,.5,110,8,40,-50,6,0xcfd2ee,.7);
 layers(mobile?160:320,.9,80,6,34,-44,-4,0xd9d2f2,.8);
 for(let i=0;i<6;i++)glow([0x3a3f7a,0x5a4a8a,0x7a5a9a,0x4a5a9a][i%4],.05,14+Math.random()*10,(Math.random()-.5)*50,10+Math.random()*16,-30-Math.random()*12);
 // أرضية دائرية مرصعة
 const floor=new T.Mesh(new T.CylinderGeometry(19,19,.4,64),new T.MeshStandardMaterial({color:0x12101e,roughness:.3,metalness:.55,bumpMap:NT,bumpScale:.05}));floor.position.y=-.2;grp.add(floor);
 const fr2=new T.Mesh(new T.TorusGeometry(19,.1,8,80),sil);fr2.rotation.x=Math.PI/2;fr2.position.y=.02;grp.add(fr2);
 [14,9,4.5].forEach(rad=>{const ring=new T.Mesh(new T.TorusGeometry(rad,.04,8,72),new T.MeshBasicMaterial({color:0x8a86b8,transparent:true,opacity:.4}));ring.rotation.x=Math.PI/2;ring.position.y=.03;grp.add(ring)});
 for(let i=0;i<24;i++){const a=i/24*Math.PI*2;const dot=new T.Mesh(new T.CircleGeometry(.1,8),new T.MeshBasicMaterial({color:0xd9d2f2,transparent:true,opacity:.5}));dot.rotation.x=-Math.PI/2;dot.position.set(Math.cos(a)*16.5,.03,Math.sin(a)*16.5-8);grp.add(dot)}
 // أقواس ضوء معمارية
 [-1,1].forEach(s=>{const arc=new T.Mesh(new T.TorusGeometry(15,.22,8,60,Math.PI/2.2),stone);arc.position.set(s*6,0,-10);arc.rotation.set(0,s*.4,s<0?.15:-.15);grp.add(arc)});
 // البوابة البعيدة (حدود المستقبل)
 const gate=new T.Mesh(new T.TorusGeometry(6,.5,10,60,Math.PI),stone);gate.position.set(0,0,-34);grp.add(gate);
 glow(0x6a5aa8,.14,16,0,7,-34);
 // ==== النجمة المركزية ====
 const sc=new T.Group();sc.position.set(0,6.2,-8);grp.add(sc);
 starCore=new T.Mesh(new T.OctahedronGeometry(.9,1),new T.MeshBasicMaterial({color:0xfff6fb}));sc.add(starCore);
 [[1.5,.14,0xfff0f8,.5],[2.2,.1,0xb99bff,.35],[3,.07,0xff9fc9,.22]].forEach(a=>{const l=new T.Mesh(new T.SphereGeometry(a[0],20,16),new T.MeshBasicMaterial({color:a[2],transparent:true,opacity:a[3],blending:T.AdditiveBlending,depthWrite:false}));sc.add(l);starLayers.push(l)});
 starRing=new T.Mesh(new T.TorusGeometry(2.6,.03,8,72),new T.MeshBasicMaterial({color:0xd9c2ff,transparent:true,opacity:.6}));starRing.rotation.x=Math.PI/2.4;sc.add(starRing);
 glow(0xffd9ec,.7,9,0,0,0,sc);glow(0xb99bff,.3,12,0,0,-.8,sc);
 for(let i=0;i<12;i++){const a=i/12*Math.PI*2;const o=glow(0xe8d9ff,.6,.12,Math.cos(a)*3.4,0,Math.sin(a)*3.4,sc);orbiters.push({s:o,a:a,r:3.4,sp:.3+Math.random()*.3,y0:0});}
 const spl=new T.PointLight(0xffe9f4,1.4,40,2);spl.position.set(0,7,-8);grp.add(spl);dimL.push(spl);spl.userData.base=1.4;
 const hh=new T.Mesh(new T.SphereGeometry(4,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));hh.userData.id='star';sc.add(hh);hits.push(hh);ex.star=new T.Vector3(0,6.2,-8);
 // ==== العناصر الأربعة حول النجمة ====
 const mkObj=(id,ang,dist,y,buildFn,labelW)=>{const g=new T.Group();const x=Math.cos(ang)*dist,z=Math.sin(ang)*dist-8;g.position.set(x,y,z);grp.add(g);buildFn(g);
  const lb=Museum.lab(labelW,3);lb.scale.set(3.2,.62,1);lb.position.set(0,-1.5,0);g.add(lb);
  const h=new T.Mesh(new T.SphereGeometry(2.2,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));h.userData.id=id;g.add(h);hits.push(h);ex[id]=new T.Vector3(x,y,z);
  const bg=glow(0xb99bff,.18,3,0,0,0,g);beamM.push({m:bg,target:0});return g};
 const glassM=new T.MeshPhongMaterial({color:0xcfe0ff,transparent:true,opacity:.2,shininess:120,specular:0xffffff});
 mkObj('moments',-2.4,9,3.2,g=>{const f=new T.Mesh(new T.BoxGeometry(2,2.6,.1),glassM);g.add(f);const e=new T.Mesh(new T.BoxGeometry(2.2,2.8,.06),sil);e.position.z=-.05;g.add(e);glow(0xffffff,.3,3.4,0,0,-.4,g)},C.obj.moments.name);
 mkObj('words',-0.8,10,3.6,g=>{const bk=new T.Mesh(new T.BoxGeometry(1.7,2.3,.3),M(0x2a2440,.4,.6));bk.rotation.z=.12;g.add(bk);const pg=new T.Mesh(new T.PlaneGeometry(1.5,2.1),new T.MeshBasicMaterial({color:0xf2effa}));pg.position.set(.1,0,.17);pg.rotation.z=.12;g.add(pg);glow(0xffd9ec,.25,3,0,0,-.4,g)},C.obj.words.name);
 mkObj('little',0.8,10,3.6,g=>{const ct=new T.Group();g.add(ct);for(let i=0;i<7;i++){const a=i/7*Math.PI*2;const p=glow([0xffd9ec,0xb99bff,0xffffff][i%3],.7,.14,Math.cos(a)*1,Math.sin(a)*.7,0,ct);orbiters.push({s:p,a:a,r:1,sp:.5,y0:0,parent:ct})}
  const ln=[];for(let i=0;i<7;i++){const a=i/7*Math.PI*2;ln.push(new T.Vector3(Math.cos(a),Math.sin(a)*.7,0))}
  const lg=new T.BufferGeometry();lg.setAttribute('position',new T.BufferAttribute(new Float32Array([0,0,0,1,0.43,0,0,0,0,.62,.59,0,0,0,0,-.22,.97,0,0,0,0,-.9,.43,0,0,0,0,-.9,-.43,0,0,0,0,-.22,-.97,0,0,0,0,.62,-.59,0]),3));g.add(new T.LineSegments(lg,new T.LineBasicMaterial({color:0x8a86b8,transparent:true,opacity:.4})))},C.obj.little.name);
 mkObj('unwritten',2.4,9,3.2,g=>{const pg=new T.Mesh(new T.PlaneGeometry(1.8,2.4),new T.MeshBasicMaterial({color:0xf6f2ff,transparent:true,opacity:.92,side:T.DoubleSide}));g.add(pg);const ring=new T.Mesh(new T.TorusGeometry(1.7,.03,8,48),new T.MeshBasicMaterial({color:0xff9fc9,transparent:true,opacity:.5}));ring.rotation.x=Math.PI/3;g.add(ring);g.userData.ring=ring;glow(0xffc9de,.22,3,0,0,-.4,g)},C.obj.unwritten.name);
 // خطوط الكوكبة (تُرسم في الختام)
 const cp=[[-14,10,-26],[-4,14,-30],[6,12,-28],[14,9,-25],[2,16,-32]];
 for(let i=0;i<cp.length-1;i++){const lg=new T.BufferGeometry();lg.setAttribute('position',new T.BufferAttribute(new Float32Array([cp[i][0],cp[i][1],cp[i][2],cp[i+1][0],cp[i+1][1],cp[i+1][2]]),3));
  const m=new T.LineBasicMaterial({color:0xd9c2ff,transparent:true,opacity:0,blending:T.AdditiveBlending});grp.add(new T.Line(lg,m));constel.push({m,target:0})}
 const cl1=new T.PointLight(0x8a90c8,.6,50,2);cl1.position.set(0,12,-6);grp.add(cl1);dimL.push(cl1);cl1.userData.base=.6;
 const cl2=new T.PointLight(0x8a90c8,.5,50,2);cl2.position.set(0,10,-22);grp.add(cl2);dimL.push(cl2);cl2.userData.base=.5;
 buildCine()}
function maybeShowComplete(){if(viewed.size>=5&&!doneFired&&compBtn&&S.active)compBtn.style.display='block'}
function restoreState(){beamM.forEach(b=>{if(viewed.size>=5)b.target=.7});if(doneFired){constel.forEach(l=>l.target=.65);dimL.forEach(l=>l.userData.dim=1)}}

return Object.assign(S,{
 reset(){viewed.clear();done=0;doneFired=false;beamM.forEach(b=>b.target=0);constel.forEach(l=>l.target=0);if(compBtn)compBtn.style.display='none'},
 enter(){if(!grp){build();nb=mkb('تقدّمي ‹','left:calc(50% + 8px)',()=>go(1));pb2=mkb('› رجوع','right:calc(50% + 8px)',()=>go(-1));
   compBtn=mkb(C.completeBtn,'left:50%;transform:translateX(-50%);bottom:calc(200px + env(safe-area-inset-bottom,0px));border-color:#f6dbe6;color:#fff0f8',()=>startComplete())}
  View.reset();S.active=true;fogS.forEach(f=>f.visible=false);const h=scene.children.find(o=>o.isHemisphereLight);if(h){ch7=h.intensity;h.intensity=.1}grp.visible=true;
  scene.fog.color.set(0x040410);scene.fog.near=30;scene.fog.far=110;si=0;focus=null;ti=0;restoreState();setTimeout(maybeShowComplete,900);
  veil.style.transition='background .9s ease, opacity 2.4s ease 2.4s';veil.style.background='#010104';veil.style.opacity=0;
  gh.classList.add('on');gt.innerHTML='<b>'+C.title+'</b><i>'+C.sub+'</i>';gt.classList.remove('show');void gt.offsetWidth;gt.classList.add('show');
  if(!LS.seen&&false){} // المقدمة تعمل دائمًا عبر اللمسة الأولى فقط
  if(!S.introDone){S.introDone=true;intro=1;introT=0;cine.style.display='flex';cam.position.set(0,4.6,7.6);look.set(0,4.6,-8);
   setTimeout(()=>{if(intro)cineText(C.intro1)},700);setTimeout(()=>{if(intro)cineText(C.intro2)},4600);setTimeout(()=>{if(intro)cineText(C.intro3)},8800);setTimeout(()=>{endIntro()},12800)}
  else{intro=0;say();setTimeout(()=>{if(S.active)nav()},800)}},
 hide(){S.active=false;grp.visible=false;nb.style.display=pb2.style.display='none';if(compBtn)compBtn.style.display='none';gh.classList.remove('on');gt.classList.remove('show');closeOv();if(intro)endIntro();const h=scene.children.find(o=>o.isHemisphereLight);if(h)h.intensity=ch7;fogS.forEach(f=>f.visible=true)},
 leave(){if(!grp)return;S.active=false;grp.visible=false;nb.style.display=pb2.style.display='none';if(compBtn)compBtn.style.display='none';gh.classList.remove('on');gt.classList.remove('show');closeOv();focus=null;if(intro)endIntro();const h=scene.children.find(o=>o.isHemisphereLight);if(h)h.intensity=ch7;fogS.forEach(f=>f.visible=true)},
 tap(e){if(intro){endIntro();return}if(ov&&ov.style.display=='flex')return;
  v2.set(e.clientX/innerWidth*2-1,-(e.clientY/innerHeight)*2+1);ray.setFromCamera(v2,cam);const q=ray.intersectObjects(hits)[0];if(!q)return;const id=q.object.userData.id;
  if(id==='star'){starOv()}else{viewed.add(id);
   if(id==='moments')momentsOv();else if(id==='words')wordsOv();else if(id==='little')littleOv();else if(id==='unwritten')unwrittenOv()}
  maybeShowComplete()},
 update(dt,t){sx+=(nx-sx)*.04;const f=focus&&ex[focus];ti+=dt;
  if(intro){introT+=dt;cam.position.z=7.6-introT*.16;cam.position.y=4.6-introT*.05;cam.position.x=sx*1.2;look.set(0,4.4,-8);cam.lookAt(look);View.apply(cam,dt,true)}
  else if(done){cam.position.lerp(new T.Vector3(0,5.4,2),1-Math.exp(-dt*.9));look.lerp(new T.Vector3(0,6.2,-8),1-Math.exp(-dt*1.4));cam.lookAt(look);View.apply(cam,dt,true)}
  else{if(f){tp.set(f.x*.5,Math.max(2.6,f.y-.8),f.z+6.5);tl.set(f.x,f.y,f.z)}else{tp.set(sx*1.6,3.4,zs[si]);tl.set(-sx*1.6,4,zs[si]-12)}
   cam.position.lerp(tp,1-Math.exp(-dt*(ti<4?.8:2.1)));look.lerp(tl,1-Math.exp(-dt*2.3));cam.lookAt(look);View.apply(cam,dt,!!focus)}
  starCore.rotation.y+=dt*.3;starCore.scale.setScalar(1+.1*Math.sin(t*1.2));
  starLayers.forEach((l,i)=>{l.scale.setScalar(1+.06*Math.sin(t*.9+i));l.rotation.y+=dt*(.1+i*.05)});
  starRing.rotation.z+=dt*.22;
  orbiters.forEach(o=>{o.a+=dt*o.sp;const px=Math.cos(o.a)*o.r,pz=Math.sin(o.a)*o.r;if(o.parent){o.s.position.set(px,Math.sin(o.a*1.3)*.7,0)}else{o.s.position.set(px,Math.sin(o.a*1.1)*.8,pz)}});
  beamM.forEach(b=>{b.m.material.opacity+=((b.target*.6)-b.m.material.opacity)*.04});
  constel.forEach(l=>{l.m.opacity+=((l.target)-l.m.opacity)*.03});
  dimL.forEach(l=>{const tgt=l.userData.base*(done?.5:1);l.intensity+=(tgt-l.intensity)*.03});
  if(!focus&&!intro&&!done){if(performance.now()%4600<70)say()}
  R.render(scene,cam)}
})})();