/* القسم 04 — THE CALLS (أرشيف قديم) */
window.Calls=(()=>{
const S={active:false},C=CONTENT.calls,ex={},hits=[],viewed=new Set(),tp=new T.Vector3(),tl=new T.Vector3(),look=new T.Vector3(0,2.5,-6),zs=[6,3,-5,-13,-16];
let grp,focus=null,si=0,ti=0,nb,pb2,gate,gr,fc=0,ch=1;const scr=[],bulbs=[];
const gt=document.getElementById('gt'),gh=document.getElementById('gh'),say=m=>{gh.textContent=m||`${C.hint} · ${viewed.size}/3`};
const nav=()=>{nb.style.display=si<zs.length-1?'block':'none';pb2.style.display=si>0?'block':'none'},go=d=>{if(focus)return;si=Math.max(0,Math.min(zs.length-1,si+d));nav()};
function mkb(t,css,fn){const b=document.createElement('button');b.className='go';b.textContent=t;b.style.cssText='position:fixed;bottom:calc(140px + env(safe-area-inset-bottom,0px));background:rgba(12,8,22,.6);z-index:3;display:none;'+css;b.onclick=fn;document.body.appendChild(b);return b}
function tx(w,h,fn,rep){const c=document.createElement('canvas');c.width=w;c.height=h;fn(c.getContext('2d'),w,h);const t=new T.CanvasTexture(c);t.wrapS=t.wrapT=T.RepeatWrapping;t.repeat.set(rep[0],rep[1]);t.anisotropy=ANISO;t.encoding=T.sRGBEncoding;return t}
function draw(s,t,i){const x=s.x;x.fillStyle='#1a0d05';x.fillRect(0,0,256,160);x.strokeStyle='rgba(255,201,138,.12)';x.lineWidth=1;for(let k=0;k<8;k++){x.beginPath();x.moveTo(0,k*20+10);x.lineTo(256,k*20+10);x.stroke()}
 x.strokeStyle='#ffc98a';x.lineWidth=2;x.shadowColor='#ffc98a';x.shadowBlur=8;x.beginPath();for(let k=0;k<=256;k+=2){const y=80+Math.sin(k*.06+t*3+i)*Math.sin(k*.013+t*.7)*46*(.6+.4*Math.sin(t*1.3+i*2))+Math.sin(k*.25+t*9)*6;k?x.lineTo(k,y):x.moveTo(k,y)}x.stroke();x.shadowBlur=0;
 x.fillStyle='#ffc98a';x.font='16px monospace';x.fillText('CALL 00'+(i+1),10,20);if(Math.floor(t*1.5)%2===0){x.fillStyle='#ff4d6d';x.beginPath();x.arc(236,16,6,0,6.283);x.fill()}x.fillStyle='rgba(0,0,0,.18)';for(let k=0;k<160;k+=3)x.fillRect(0,k,256,1);s.tex.needsUpdate=true}
function build(){
 grp=new T.Group();scene.add(grp);const r=rnd(44),o=new T.Object3D(),add=(m,x,y,z)=>{m.position.set(x,y,z);grp.add(m);return m},mk=(w,h,d,m,x,y,z)=>add(new T.Mesh(new T.BoxGeometry(w,h,d),m),x,y,z);
 const gl=(c,op,s,x,y,z,p)=>{const q=new T.Sprite(new T.SpriteMaterial({map:GT,color:c,opacity:op,transparent:true,depthWrite:false,blending:T.AdditiveBlending}));q.scale.set(s,s,1);q.position.set(x,y,z);(p||grp).add(q);return q};
 const pl=(rep)=>tx(256,256,(x,w,h)=>{x.fillStyle='#2b1b13';x.fillRect(0,0,w,h);for(let i=0;i<8;i++){x.fillStyle=`hsl(22,${30+r()*15}%,${12+r()*8}%)`;x.fillRect(i*32+1,0,30,h)}for(let i=0;i<500;i++){x.strokeStyle='rgba(0,0,0,.25)';x.beginPath();const a=r()*w,b=r()*h;x.moveTo(a,b);x.lineTo(a+(r()-.5)*2,b+8+r()*20);x.stroke()}},rep);
 const t1=pl([1,1]),t2=pl([5,2]),t3=pl([9,15]),wood=new T.MeshStandardMaterial({map:t1,bumpMap:t1,bumpScale:1,roughness:.75}),wallW=new T.MeshStandardMaterial({map:t2,bumpMap:t2,bumpScale:1,roughness:.85}),floorM=new T.MeshStandardMaterial({map:t3,bumpMap:t3,bumpScale:1,roughness:.5,metalness:.05});
 floorM.map.rotation=Math.PI/2;
 add(new T.Mesh(new T.PlaneGeometry(18,30),floorM),0,0,-9).rotation.x=-Math.PI/2;
 mk(4,.03,28,M(0x4a1226,.9),0,.03,-9);[-2,2].forEach(x=>mk(.08,.04,28,goldM2,x,.05,-9));
 mk(.4,8,30,wallW,-9.2,4,-9);mk(.4,8,30,wallW,9.2,4,-9);mk(18.4,8,.4,wallW,0,4,-24.2);mk(18.4,8,.4,wallW,0,4,8.2);mk(18.4,.4,30,M(0x140d0a,.9),0,8.2,-9);
 for(let i=0;i<8;i++)mk(18,.4,.4,wood,0,7.7,5-i*4);[-1,1].forEach(s=>mk(.2,.15,30,wood,s*8.95,1.6,-9));
 // wall of phones
 const PN=30,pb=new T.InstancedMesh(new T.BoxGeometry(.6,.25,.45),M(0xffffff,.4,.3),PN),ph=new T.InstancedMesh(new T.BoxGeometry(.64,.08,.12),M(0xffffff,.4,.3),PN),pc=[0x0e0e10,0xe8dcc4,0x7a1020,0xff9fc8,0x1d3a2a];let n=0;
 [-1,1].forEach(s=>[2.4,4.1,5.8].forEach(y=>{mk(6,.12,.7,wood,s*5.9,y,-23.45);for(let i=0;i<5;i++){const col=new T.Color(pc[Math.floor(r()*5)]);o.rotation.set(0,0,0);o.scale.set(1,1,1);o.position.set(s*(3.4+i*1.1),y+.25,-23.5);o.updateMatrix();pb.setMatrixAt(n,o.matrix);pb.setColorAt(n,col);o.position.y=y+.43;o.position.z=-23.55;o.updateMatrix();ph.setMatrixAt(n,o.matrix);ph.setColorAt(n,col);n++}}));
 grp.add(pb,ph);
 // corkboards + polaroids
 const bd=new T.InstancedMesh(new T.PlaneGeometry(.55,.65),new T.MeshBasicMaterial({color:0xe9dfcc}),36),bi=new T.InstancedMesh(new T.PlaneGeometry(.42,.42),new T.MeshBasicMaterial({color:0x3a2748}),36);let q=0;
 [-1,1].forEach(s=>[-3,-11,-19].forEach(z=>{mk(.1,2.6,4.4,M(0x8a5a36,.95),s*8.95,4.8,z);for(let i=0;i<6;i++){o.position.set(s*8.87,4.8+(i%2?.5:-.45),z-1.8+i*.72);o.rotation.set(0,-s*Math.PI/2,(r()-.5)*.4);o.scale.set(1,1,1);o.updateMatrix();bd.setMatrixAt(q,o.matrix);o.position.set(s*8.86,o.position.y+.06,o.position.z);o.updateMatrix();bi.setMatrixAt(q,o.matrix);q++}}));
 grp.add(bd,bi);
 // phones + stations
 const phone=(g,x,y,z,col)=>{const m=M(col,.35,.4),a=(geo,mt,px,py,pz)=>{const k=new T.Mesh(geo,mt);k.position.set(x+px,y+py,z+pz);g.add(k);return k};
  a(new T.BoxGeometry(.7,.18,.55),m,0,.09,0);a(new T.CylinderGeometry(.17,.17,.04,18),goldM2,0,.2,.05).rotation.x=-.45;a(new T.BoxGeometry(.72,.08,.13),m,0,.33,-.12);[-.33,.33].forEach(s=>a(new T.SphereGeometry(.1,10,8),m,s,.31,-.12));[-.25,.25].forEach(s=>a(new T.CylinderGeometry(.04,.05,.14,6),m,s,.2,-.12))};
 for(let i=0;i<3;i++){const c=document.createElement('canvas');c.width=256;c.height=160;const t=new T.CanvasTexture(c);t.encoding=T.sRGBEncoding;scr.push({x:c.getContext('2d'),tex:t});draw(scr[i],0,i)}
 const st=(sx,z,i)=>{const e=C.exhibits[i],g=new T.Group();g.position.set(sx,0,z);g.rotation.y=sx<0?Math.PI/2:-Math.PI/2;grp.add(g);const b=(w,h,d,mt,x,y,zz)=>{const k=new T.Mesh(new T.BoxGeometry(w,h,d),mt);k.position.set(x,y,zz);g.add(k);return k};
  b(2.6,.12,1.4,wood,0,.9,0);[-1.2,1.2].forEach(a=>[-.55,.55].forEach(c=>b(.12,.9,.12,wood,a,.45,c)));b(.9,.7,1.2,wood,.8,.5,0);
  b(.95,.8,.9,M(0x2a2a2e,.5,.3),-.55,1.36,0);b(.6,.5,.5,M(0x1c1c20,.6),-.55,1.3,-.6);
  const sm=new T.Mesh(new T.PlaneGeometry(.78,.6),new T.MeshBasicMaterial({map:scr[i].tex}));sm.position.set(-.55,1.4,.46);g.add(sm);
  phone(g,.75,.96,.1,[0x0e0e10,0xe8dcc4,0x7a1020][i]);
  b(.3,.06,.3,goldM2,1.1,.99,-.4);b(.04,.5,.04,goldM2,1.1,1.25,-.4);b(.4,.2,.3,M(0x1d5a3a,.5,0,0x0f4a2a),1.1,1.55,-.4);gl(0xffc27a,.5,2.4,1.1,1.5,-.2,g);gl(0xffc98a,.35,2,-.55,1.4,.6,g);
  const lb=Museum.lab(e.title,3.1);lb.scale.set(4,.76,1);g.add(lb);
  const h=new T.Mesh(new T.SphereGeometry(2.2,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));h.position.set(0,1.4,.6);h.userData.id=e.id;g.add(h);hits.push(h);ex[e.id]=g.position};
 st(-5.5,-3,0);st(5.5,-11,1);st(-5.5,-19,2);
 // telephone booth
 const bg=new T.Group();bg.position.set(0,0,-21.5);grp.add(bg);const bb=(w,h,d,mt,x,y,zz)=>{const k=new T.Mesh(new T.BoxGeometry(w,h,d),mt);k.position.set(x,y,zz);bg.add(k);return k},rm=M(0xb81d4f,.4,.6);
 [-1.1,1.1].forEach(x=>[-1.1,1.1].forEach(z=>bb(.12,3.6,.12,rm,x,1.8,z)));bb(2.5,.3,2.5,rm,0,3.75,0);bb(2.3,.06,2.3,rm,0,.03,0);
 [[0,1.8,1.1,2.1,3.4,.02],[0,1.8,-1.1,2.1,3.4,.02],[-1.1,1.8,0,.02,3.4,2.1],[1.1,1.8,0,.02,3.4,2.1]].forEach(a=>bb(a[3],a[4],a[5],new T.MeshStandardMaterial({color:0xffffff,transparent:true,opacity:.1,roughness:0}),a[0],a[1],a[2]));
 phone(bg,0,1.1,-.9,0x0e0e10);bb(.9,.9,.05,M(0x2a1f35,.6),0,1.7,-1.05);
 gate=new T.Mesh(new T.PlaneGeometry(2.1,3.4),new T.MeshBasicMaterial({color:0xff8fcf,transparent:true,opacity:.04,blending:T.AdditiveBlending,depthWrite:false}));gate.position.set(0,1.8,.4);bg.add(gate);
 const cs=document.createElement('canvas');cs.width=512;cs.height=128;{const x=cs.getContext('2d');x.textAlign='center';x.shadowColor='#ec5f9d';x.shadowBlur=24;x.fillStyle='#ffd0e6';x.font='700 84px "Cormorant Garamond",serif';x.fillText('CALLS',256,88);x.shadowColor='#ff3355';x.fillStyle='#ff6a84';x.font='24px monospace';x.fillText('● REC',440,40)}
 mk(5,1.25,.02,new T.MeshBasicMaterial({map:new T.CanvasTexture(cs),transparent:true}),0,5.6,-23.95);
 const bl=Museum.lab('THE LINE',4.6);bg.add(bl);
 const bh=new T.Mesh(new T.SphereGeometry(3,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));bh.position.set(0,1.8,1);bh.userData.id='booth';bg.add(bh);hits.push(bh);ex.booth=new T.Vector3(0,0,-21.5);
 // bulbs + lights
 for(let i=0;i<8;i++){const x=(i%2?1:-1)*2.5,z=3-i*3.4;mk(.02,1.3,.02,M(0x111111,1),x,7.5,z);add(new T.Mesh(new T.SphereGeometry(.12,10,8),new T.MeshBasicMaterial({color:0xffe2b0})),x,6.8,z);bulbs.push(gl(0xffb26b,.6,3.6,x,6.8,z))}
 [[0xffb26b,0,5,-2,1.5],[0xffb26b,0,5,-14,1.5],[0xff5fa8,0,3,-20,1.2]].forEach(a=>{const l=new T.PointLight(a[0],a[4],a[4]>1.3?26:16,2);l.position.set(a[1],a[2],a[3]);grp.add(l)})
 gr=document.createElement('div');{const c=document.createElement('canvas');c.width=c.height=128;const x=c.getContext('2d');for(let i=0;i<2600;i++){x.fillStyle=`rgba(255,255,255,${r()*.22})`;x.fillRect(r()*128,r()*128,1,1)}
  gr.style.cssText=`position:fixed;inset:0;pointer-events:none;z-index:1;display:none;background:radial-gradient(ellipse at center,transparent 50%,rgba(0,0,0,.6)),linear-gradient(rgba(255,170,90,.07),rgba(255,170,90,.07)),url(${c.toDataURL()});animation:gr .5s steps(4) infinite`;document.body.appendChild(gr)}}
GS.goToSection5=()=>{veil.style.transition='opacity 1.2s ease';veil.style.background='#07050d';veil.style.opacity=1;setTimeout(()=>{S.hide();Trends.enter()},1300)};
function finish(){focus='booth';nb.style.display=pb2.style.display='none';gh.classList.remove('on');UI.recording(C.recording,()=>GS.goToSection5())}
return Object.assign(S,{
 reset(){viewed.clear()},
 enter(){if(!grp){build();nb=mkb('تقدّمي ‹','left:calc(50% + 8px)',()=>go(1));pb2=mkb('› رجوع','right:calc(50% + 8px)',()=>go(-1))}
  View.reset();S.active=true;fogS.forEach(f=>f.visible=false);const h=scene.children.find(o=>o.isHemisphereLight);if(h){ch=h.intensity;h.intensity=.25}grp.visible=true;gr.style.display='block';
  scene.fog.color.set(0x0c0705);scene.fog.near=14;scene.fog.far=60;si=0;focus=null;ti=0;setTimeout(()=>{if(S.active)nav()},3500);cam.position.set(0,2.6,7.6);look.set(0,2.5,-6);
  veil.style.transition='background .9s ease, opacity 2.4s ease 2.4s';veil.style.background='#07050d';veil.style.opacity=0;say();gh.classList.add('on');
  gt.innerHTML='<b>'+C.title+'</b><i>'+C.sub+'</i>';gt.classList.remove('show');void gt.offsetWidth;gt.classList.add('show')},
 hide(){S.active=false;grp.visible=false;gr.style.display='none';nb.style.display=pb2.style.display='none';gh.classList.remove('on');gt.classList.remove('show');const h=scene.children.find(o=>o.isHemisphereLight);if(h)h.intensity=ch;fogS.forEach(f=>f.visible=true)},
 leave(){if(!grp)return;S.active=false;grp.visible=false;gr.style.display='none';nb.style.display=pb2.style.display='none';gh.classList.remove('on');gt.classList.remove('show');UI.close();const h=scene.children.find(o=>o.isHemisphereLight);if(h)h.intensity=ch;fogS.forEach(f=>f.visible=true)},
 tap(e){v2.set(e.clientX/innerWidth*2-1,-(e.clientY/innerHeight)*2+1);ray.setFromCamera(v2,cam);const q=ray.intersectObjects(hits)[0];if(!q)return;const id=q.object.userData.id;
  if(id==='booth'){if(viewed.size<3){say(C.lock);return}focus='booth';UI.puzzle(C.puzzle,finish,()=>{focus=null})}
  else{focus=id;viewed.add(id);say();UI.exhibit(C.exhibits.find(x=>x.id===id),()=>{focus=null})}},
 update(dt,t){sx+=(nx-sx)*.04;const f=focus&&ex[focus];ti+=dt;
  if(f){if(focus==='booth'){tp.set(0,2.6,-14.5);tl.set(0,2.2,-21.5)}else{tp.set(f.x*.55,2.4,f.z+4.5);tl.set(f.x,1.8,f.z)}}else{tp.set(sx*1.2,2.7,zs[si]);tl.set(-sx*1.2,2.4,zs[si]-12)}
  cam.position.lerp(tp,1-Math.exp(-dt*(ti<4?.8:2.2)));look.lerp(tl,1-Math.exp(-dt*2.5));cam.lookAt(look);View.apply(cam,dt,!!focus);
  gate.material.opacity=viewed.size>2?.14+.06*Math.sin(t*2):.04;
  if(!reduce){if(++fc%3===0)scr.forEach((s,i)=>draw(s,t,i));bulbs.forEach((b,i)=>b.material.opacity=.3+.08*Math.sin(t*23+i*5)*Math.sin(t*7+i))}
  R.render(scene,cam)}
})})();
