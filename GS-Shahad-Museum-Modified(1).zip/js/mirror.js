/* القسم 06 — THE MIRROR ROOM v3 (كما يراها قلبي — المواصفات الكاملة) */
window.Mirror=(()=>{
const S={active:false},C=CONTENT.mirror,ex={},hits=[],viewed=new Set(),tp=new T.Vector3(),tl=new T.Vector3(),look=new T.Vector3(0,3,-8),zs=[6,2,-4,-10.5,-16.5,-21],glows=[],dust=[];
let grp,focus=null,si=0,ti=0,nb,pb2,fc=0,ch3=1,overlay=null,ovOpen=false,ovMirror=null,ovStage=0,roomL=[],nearId=null,nudge=0,lockUntil=0;
const gt=document.getElementById('gt'),gh=document.getElementById('gh');
const say=m=>{gh.textContent=m||`${C.hint}: ${viewed.size} / 4`};
const nav=()=>{nb.style.display=si<zs.length-1?'block':'none';pb2.style.display=si>0?'block':'none'},go=d=>{if(focus)return;si=Math.max(0,Math.min(zs.length-1,si+d));nav()};
function mkb(t,css,fn){const b=document.createElement('button');b.className='go';b.textContent=t;b.style.cssText='position:fixed;bottom:calc(140px + env(safe-area-inset-bottom,0px));background:rgba(12,8,22,.6);z-index:3;display:none;'+css;b.onclick=fn;document.body.appendChild(b);return b}
function buildOverlay(){if(overlay)return;
 overlay=document.createElement('div');overlay.id='mrOv';
 overlay.style.cssText='position:fixed;inset:0;z-index:8;display:none;align-items:center;justify-content:center;background:rgba(4,2,9,.66);backdrop-filter:blur(3px);padding:18px';
 const card=document.createElement('div');
 card.style.cssText='max-width:560px;width:100%;max-height:76vh;overflow-y:auto;background:linear-gradient(165deg,rgba(22,16,34,.97),rgba(10,7,18,.97));border:1px solid rgba(185,155,255,.35);border-radius:14px;padding:26px 24px 20px;box-shadow:0 0 60px rgba(185,155,255,.12),inset 0 0 40px rgba(255,95,168,.04);direction:rtl;text-align:center';
 const h=document.createElement('div');h.id='mrT';h.style.cssText='color:#ec5f9d;font:700 15px "Space Grotesk",sans-serif;letter-spacing:2px;margin-bottom:14px;direction:ltr';
 const b=document.createElement('div');b.id='mrB';b.style.cssText='color:#ece9f6;font:italic 400 clamp(17px,2.4vw,21px)/1.9 "Cormorant Garamond","Amiri",serif;min-height:120px';
 const row=document.createElement('div');row.style.cssText='margin-top:18px;display:flex;gap:10px;justify-content:center;flex-wrap:wrap';
 const bn=document.createElement('button');bn.id='mrN';bn.style.cssText='background:rgba(255,95,168,.14);border:1px solid #ec5f9d;color:#f6dbe6;border-radius:20px;padding:9px 22px;font:600 15px "Cormorant Garamond",ser-serif;cursor:pointer';
 const bc=document.createElement('button');bc.id='mrC';bc.textContent=C.closeBtn;bc.style.cssText='background:rgba(185,155,255,.1);border:1px solid rgba(185,155,255,.5);color:#d9d2ee;border-radius:20px;padding:9px 22px;font:600 15px "Cormorant Garamond",serif;cursor:pointer';
 bn.onclick=()=>advance();bc.onclick=()=>closeOv(true);
 row.appendChild(bn);row.appendChild(bc);card.appendChild(h);card.appendChild(b);card.appendChild(row);overlay.appendChild(card);document.body.appendChild(overlay);
 window.addEventListener('keydown',e=>{if(e.key==='Escape'&&ovOpen&&ovMirror&&ovMirror.kind!=='final')closeOv(true)})}
function fadeEl(el,html,dim){el.style.transition='opacity .9s ease';el.style.opacity=0;setTimeout(()=>{el.innerHTML=html;el.style.opacity=dim?.45:1},dim?150:420)}
function stageHTML(m,st){const B=document.getElementById('mrB'),N=document.getElementById('mrN');
 if(m.kind==='quote'){if(st===0){B.innerHTML='<p style="margin:0 0 10px">'+m.quote+'</p>';B.style.opacity=1;N.textContent=C.nextBtn;N.style.display='inline-block'}
  else{fadeEl(B,'<p style="margin:0 0 10px;opacity:.75">'+m.quote+'</p><p style="margin:0;color:#d9d3e4">'+m.desc+'</p>');N.style.display='none'}}
 else if(m.kind==='list'){let h='';for(let i=0;i<=st;i++)h+='<p style="margin:2px 0;opacity:'+(i===st?1:.55)+'">'+(i<st?'✓ ':'◦ ')+m.items[i]+'</p>';
  B.innerHTML=h;B.style.opacity=1;N.textContent=st<m.items.length-1?C.nextBtn+' ('+(st+1)+'/'+m.items.length+')':C.closeBtn}
 else if(m.kind==='traits'){let h='';for(let i=0;i<=st;i++)h+='<p style="margin:3px 0;opacity:'+(i===st?1:.5)+'"><b style="color:#f2a4c6">'+m.items[i][0]+'</b> — <span style="font-size:.92em;color:#cfcbe4">'+m.items[i][1]+'</span></p>';
  B.innerHTML=h;B.style.opacity=1;N.textContent=st<m.items.length-1?C.nextBtn+' ('+(st+1)+'/'+m.items.length+')':C.closeBtn}
 else if(m.kind==='stages'){fadeEl(B,'<p style="margin:0">'+m.items[st]+'</p>');N.textContent=st<m.items.length-1?C.nextBtn:C.closeBtn;
  nudge=(st-1)*.9}
 else if(m.kind==='final'){if(st===0){B.innerHTML='<p style="margin:0">'+m.quote+'</p>';B.style.opacity=1}
  else if(st===1){fadeEl(B,'<p style="margin:0;text-align:right">'+m.letter+'</p>')}
  else{fadeEl(B,'<p style="margin:6px 0;color:#f6dbe6;letter-spacing:2px;font-style:normal;font-family:\'Space Grotesk\',sans-serif;font-size:15px">'+m.sign[0]+'</p><p style="margin:0;color:#b39df0;font-style:normal;font-family:\'Space Grotesk\',sans-serif;font-size:13px;letter-spacing:1px">'+m.sign[1]+'</p>');
   N.textContent=C.doneBtn;N.style.borderColor='#b39df0';N.style.color='#e2d9ff';return}}
 if(m.kind!=='final'&&m.kind!=='quote')N.textContent=st<m.items.length-1?N.textContent:C.closeBtn}
function openOv(m){buildOverlay();ovMirror=m;ovStage=0;ovOpen=true;nudge=0;
 document.getElementById('mrT').textContent=m.title;document.getElementById('mrB').innerHTML='';document.getElementById('mrB').style.opacity=1;
 document.getElementById('mrN').style.cssText='background:rgba(255,95,168,.14);border:1px solid #ec5f9d;color:#f6dbe6;border-radius:20px;padding:9px 22px;font:600 15px "Cormorant Garamond",serif;cursor:pointer;display:inline-block';
 overlay.style.display='flex';
 if(!viewed.has(m.id)&&!m.final){viewed.add(m.id);say()}}
function advance(){const m=ovMirror;if(!m)return;
 if(m.kind==='quote'){if(ovStage===0){ovStage=1;stageHTML(m,1)}else closeOv(true)}
 else if(m.kind==='final'){if(ovStage<2){ovStage++;stageHTML(m,ovStage);if(ovStage===2)say(C.hint+': 4 / 4')}else{closeOv(false);finish()}}
 else{if(ovStage<m.items.length-1){ovStage++;stageHTML(m,ovStage)}else closeOv(true)}}
function closeOv(free){ovOpen=false;if(overlay)overlay.style.display='none';if(free)focus=null;ovMirror=null}
// بناء المشهد
function build(){
 grp=new T.Group();scene.add(grp);const r=rnd(77),add=(m,x,y,z)=>{m.position.set(x,y,z);grp.add(m);return m},mk=(w,h,d,m,x,y,z)=>add(new T.Mesh(new T.BoxGeometry(w,h,d),m),x,y,z);
 const dark=M(0x0e0b18,.5,.4),sil=M(0xb9bbd6,.16,.95),chrome=M(0x191922,.2,1);
 const pk=new T.MeshBasicMaterial({color:0xff5fa8}),pu=new T.MeshBasicMaterial({color:0xb99bff}),pearl=new T.MeshBasicMaterial({color:0xfff2f8});
 const glow=(c,op,s,x,y,z,p)=>{const q=new T.Sprite(new T.SpriteMaterial({map:GT,color:c,opacity:op,transparent:true,depthWrite:false,blending:T.AdditiveBlending}));q.scale.set(s,s,1);q.position.set(x,y,z);(p||grp).add(q);return q};
 // قاعة مرتفعة: أرضية لامعة + جدران فحمية بأقواس فضية
 add(new T.Mesh(new T.PlaneGeometry(20,34),new T.MeshStandardMaterial({color:0x07060f,roughness:.1,metalness:.9,bumpMap:NT,bumpScale:.015})),0,0,-11).rotation.x=-Math.PI/2;
 const wl=M(0x131020,.55,.35);mk(.4,11,34,wl,-10.2,5.5,-11);mk(.4,11,34,wl,10.2,5.5,-11);mk(20.4,11,.4,wl,0,5.5,-27.2);mk(20.4,11,.4,wl,0,5.5,8.2);mk(20.4,.4,34,M(0x050409,.95),0,11.2,-11);
 [-1,1].forEach(s=>{for(let z=5;z>-27;z-=5.4){const a=new T.Mesh(new T.TorusGeometry(1.7,.08,8,30,Math.PI),sil);a.position.set(s*9.95,3.6,z);a.rotation.y=s<0?Math.PI/2:-Math.PI/2;grp.add(a);
  mk(.24,3.6,.24,sil,s*9.95,1.8,z-1.7);mk(.24,3.6,.24,sil,s*9.95,1.8,z+1.7);mk(.05,8.8,.05,z%2?pu:pk,s*9.8,4.4,z);mk(.8,.05,.05,sil,s*9.9,7.4,z)}});
 mk(2.4,.03,33,M(0x1c1030,.6,.3,0x0e081c),0,.02,-11);[-1.4,1.4].forEach(x=>mk(.05,.05,33,pu,x,.03,-11));
 // المرايا الخمس — لكل مرآة شخصية بصرية
 const mir=new T.MeshStandardMaterial({color:0x201c30,roughness:.05,metalness:1});
 const POS={m1:[-4.6,-3],m2:[4.6,-9.5],m3:[-4.6,-16],m4:[4.6,-22],m5:[0,-25.6]};
 C.mirrors.forEach((m,ix)=>{const[sx,mz]=POS[m.id],g=new T.Group();g.position.set(sx,0,mz);g.rotation.y=sx<0?Math.PI/2-.12:sx>0?-Math.PI/2+.12:0;grp.add(g);
  const b=(w,h,d,mm,x,y,z)=>{const k=new T.Mesh(new T.BoxGeometry(w,h,d),mm);k.position.set(x,y,z);g.add(k);return k};
  const isFinal=m.final,FM=isFinal?sil:(m.kind==='stages'?chrome:sil);
  const W=isFinal?3.6:2.6,H=isFinal?5.6:4.3;
  b(.24,H,.22,FM,-W/2,2.7+H/2-2.15,0);b(.24,H,.22,FM,W/2,2.7+H/2-2.15,0);
  const arch=new T.Mesh(new T.TorusGeometry(W/2,.14,10,44,Math.PI),FM);arch.position.set(0,2.7+H/2-2.15+H/2,0);g.add(arch);
  if(isFinal){const f1=new T.Mesh(new T.SphereGeometry(.22,12,10),sil);f1.position.set(0,2.7+H+ .3,0);g.add(f1);
   const cr=new T.Mesh(new T.ConeGeometry(.16,.44,8),chrome);cr.position.set(0,2.7+H+.02,0);g.add(cr);
   [-1,1].forEach(s2=>{const o=new T.Mesh(new T.TorusGeometry(.15,.04,8,18),sil);o.position.set(s2*W/2,2.7+H/2-2.15+H/2-.1,0);g.add(o)})}
  const gd=new T.Mesh(new T.PlaneGeometry(W-.36,H-.2),mir);gd.position.set(0,2.7+H/2-2.15,.03);g.add(gd);
  const glw=glow(isFinal?0xfff0f8:(m.kind==='list'?0xff5fa8:m.kind==='traits'?0xffd9ec:m.kind==='stages'?0xb99bff:0xf6ecff),.34,isFinal?7:4.6,0,2.7+H/2-2.15,-.5,g);
  glows.push({id:m.id,sp:glw,base:.15,max:isFinal?.42:.3});
  if(m.kind==='list'){const dp=[];for(let k=0;k<10;k++){const s2=glow(0xff5fa8,.45,.16,(Math.random()-.5)*W,2.2+Math.random()*2.4,.3,g);dp.push({s:s2,ph:Math.random()*6.283,rad:.12+Math.random()*.2,sp:.5+Math.random()*.7})}dust.push(...dp)}
  if(m.kind==='stages'){for(let k=0;k<8;k++){const s2=glow(0xb99bff,.22,.12,(Math.random()-.5)*1.6,1.2+Math.random()*3,.4,g);dust.push({s:s2,toCenter:true,x0:s2.position.x,y0:s2.position.y,ph:Math.random()*6.283})}}
  if(isFinal){b(4.4,.16,1.2,chrome,0,.08,.5);b(3.8,.14,1,sil,0,.24,.4);const halo=glow(0xff9fd2,.1,9,0,3.4,-1.2,g);glows.push({id:'m5h',sp:halo,base:.1,max:.24});
   [-1,1].forEach(s2=>{b(.14,2.4,.14,sil,s2*2.6,1.2,.7);const cs=new T.Mesh(new T.ConeGeometry(.12,.42,8),s2<0?pk:pu);cs.position.set(s2*2.6,2.65,.7);g.add(cs)})}
  const lb=Museum.lab(m.title,isFinal?5.4:2.6);lb.scale.set(isFinal?4.6:3.4,isFinal?.8:.72,1);lb.position.set(0,.08,isFinal?.9:.55);g.add(lb);
  const h=new T.Mesh(new T.SphereGeometry(isFinal?3.4:2.6,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));h.position.set(0,3,.8);h.userData.id=m.id;g.add(h);hits.push(h);ex[m.id]=new T.Vector3(sx,0,mz)});
 // سقف: ميدالية فضية + ثريا حلقية
 const med=new T.Mesh(new T.TorusGeometry(3,.1,8,64),sil);med.position.set(0,10.9,-10);med.rotation.x=Math.PI/2;grp.add(med);
 const med2=new T.Mesh(new T.TorusGeometry(1.4,.07,8,48),sil);med2.position.set(0,10.9,-10);med2.rotation.x=Math.PI/2;grp.add(med2);
 const cry=new T.Mesh(new T.OctahedronGeometry(.5,0),pearl);cry.position.set(0,10.2,-10);grp.add(cry);roomL.push({o:cry,spin:1});
 // ضباب أرضي خفيف + غبار
 for(let i=0;i<7;i++){const m2=glow(0x8a6bbf,.035,6+Math.random()*4,(Math.random()-.5)*13,.3+Math.random()*.4,5-Math.random()*28);m2.userData={sp:.06+Math.random()*.16,x0:m2.position.x,ph:Math.random()*6.283};dust.push({s:m2,mist:true})}
 const MN=mobile?90:190,mp=new Float32Array(MN*3);for(let i=0;i<MN;i++)mp.set([(Math.random()-.5)*17,Math.random()*9.5,7-Math.random()*32],i*3);
 grp.add(new T.Points(new T.BufferGeometry().setAttribute('position',new T.BufferAttribute(mp,3)),new T.PointsMaterial({map:GT,size:.09,color:0xd9dbee,transparent:true,opacity:.26,depthWrite:false,blending:T.AdditiveBlending})));
 // إضاءة سينمائية
 [[0xfff0f8,-3,-4.6,.5],[0xff9fc9,-9.5,4.6,.45],[0xffd9ec,-16,-4.6,.45],[0xb99bff,-22,4.6,.48],[0xffd9ec,-25,0,.6]].forEach(a=>{const l=new T.PointLight(a[0],a[3],20,2);l.position.set(a[2],6.6,a[1]);grp.add(l);roomL.push({o:l,base:a[3]})});
 const dl=new T.PointLight(0xb99bff,.22,26,2);dl.position.set(0,8,-14);grp.add(dl);roomL.push({o:dl,base:.22})}
function finish(){closeOv(false);focus=null;veil.style.transition='opacity 1.8s ease';veil.style.background='#0b0714';veil.style.opacity=1;setTimeout(()=>{S.hide();Locked.enter()},1900)}
GS.goToSection8=finish;
return Object.assign(S,{
 reset(){viewed.clear()},
 enter(){if(!grp){build();nb=mkb('تقدّمي ‹','left:calc(50% + 8px)',()=>go(1));pb2=mkb('› رجوع','right:calc(50% + 8px)',()=>go(-1));buildOverlay()}
  View.reset();S.active=true;fogS.forEach(f=>f.visible=false);const h=scene.children.find(o=>o.isHemisphereLight);if(h){ch3=h.intensity;h.intensity=.15}grp.visible=true;
  scene.fog.color.set(0x0a0714);scene.fog.near=14;scene.fog.far=60;si=0;focus=null;ti=0;setTimeout(()=>{if(S.active)nav()},3500);cam.position.set(0,3,7.6);look.set(0,3,-8);
  veil.style.transition='background .9s ease, opacity 2.4s ease 2.4s';veil.style.background='#040309';veil.style.opacity=0;say();gh.classList.add('on');
  gt.innerHTML='<b>'+C.title+'</b><i>'+C.sub+'</i>';gt.classList.remove('show');void gt.offsetWidth;gt.classList.add('show')},
 hide(){S.active=false;grp.visible=false;nb.style.display=pb2.style.display='none';gh.classList.remove('on');gt.classList.remove('show');closeOv(false);const h=scene.children.find(o=>o.isHemisphereLight);if(h)h.intensity=ch3;fogS.forEach(f=>f.visible=true)},
 leave(){if(!grp)return;S.active=false;grp.visible=false;nb.style.display=pb2.style.display='none';gh.classList.remove('on');gt.classList.remove('show');closeOv(false);UI.close();const h=scene.children.find(o=>o.isHemisphereLight);if(h)h.intensity=ch3;fogS.forEach(f=>f.visible=true)},
 tap(e){if(ovOpen)return;v2.set(e.clientX/innerWidth*2-1,-(e.clientY/innerHeight)*2+1);ray.setFromCamera(v2,cam);const q=ray.intersectObjects(hits)[0];if(!q)return;const id=q.object.userData.id,m=C.mirrors.find(x=>x.id===id);
  if(m.final){if(viewed.size<4){lockUntil=performance.now()+2600;gh.textContent=C.lock;return}
   focus=id;openOv(m);stageHTML(m,0);say(C.hint+': 4 / 4')}
  else{focus=id;openOv(m);stageHTML(m,0)}},
 update(dt,t){sx+=(nx-sx)*.04;const f=focus&&ex[focus];ti+=dt;
  if(f){if(focus==='m5'){tp.set(0,3,-18.4);tl.set(0,3.4,-25.6)}else{tp.set(f.x*.28+nudge,3.2,f.z+5.6);tl.set(f.x+nudge*.5,3.3,f.z)}}else{tp.set(sx*1.5,3,zs[si]);tl.set(-sx*1.5,3.2,zs[si]-12);if(focus==='m4'){tp.x=0;tl.x=0}}
  const spd=focus==='m5'?1.1:(ti<4?.8:2.2);
  cam.position.lerp(tp,1-Math.exp(-dt*spd));look.lerp(tl,1-Math.exp(-dt*2.2));cam.lookAt(look);View.apply(cam,dt,!!focus);
  // توهج الاقتراب + مؤشر
  let nz=-99;if(!focus){C.mirrors.forEach(m=>{const d=Math.abs(cam.position.z-(m.final?-25.6:ex[m.id].z));if(d<3.2&&d>0&&Math.abs(cam.position.x-ex[m.id].x)<6){if(-d>nz)nz=-d,nearId=m.id}})}
  glows.forEach(g2=>{const tgt=(nearId===g2.id||focus===g2.id||focus==='m5'&&g2.id==='m5')?g2.max:g2.base;g2.sp.material.opacity+=(tgt-g2.sp.material.opacity)*.05});
  if(!focus){if(performance.now()<lockUntil){}else if(nearId){const m=C.mirrors.find(x=>x.id===nearId);gh.textContent=m.final?(viewed.size<4?C.lock:C.prompt+' — '+m.title):C.prompt+' — '+m.title}else say()}
  // خفوت بقية القاعة عند المرآة الأخيرة
  const dim=focus==='m5'?0.62:1;roomL.forEach(L2=>{if(L2.o.isPointLight)L2.o.intensity+=(L2.base*dim-L2.o.intensity)*.04;else if(L2.spin){L2.o.rotation.y+=dt*.4;L2.o.position.y=10.2+Math.sin(t*.8)*.12}});
  if(!reduce){dust.forEach(d=>{if(d.mist){d.s.userData.ph+=dt*d.s.userData.sp;d.s.position.x=d.s.userData.x0+Math.sin(d.s.userData.ph)*1.4}
   else if(d.toCenter){d.ph+=dt;d.s.position.x=d.x0*(1-.5*((d.ph*.2)%1));d.s.position.y=d.y0+Math.sin(d.ph)*.2;d.s.material.opacity=.25+.2*Math.sin(d.ph*1.3)}
   else{d.ph+=dt*d.sp;d.s.position.x=Math.sin(d.ph)*d.rad;d.s.position.y+=Math.cos(d.ph*1.2)*dt*.25}});
   if(++fc%4===0){/* جسیمات ثابتة، لا حاجة لإعادة رسم */}}
  R.render(scene,cam)}
})})();