/* القسم 02 — THE GARDEN OF HER */
window.Museum=(()=>{
const S={active:false},C=CONTENT.garden,kx=()=>innerWidth/innerHeight<1?.85:1;
const ex={},hits=[],viewed=new Set(),tp=new T.Vector3(),tl=new T.Vector3(),look=new T.Vector3(0,2,-2);
let grp,fire,fb,gateGlow,focus=null,hid=[],leaving=0,wt,wt2,catG,ti=0,wk=false,wasF=false,wy=1.75,bob=0;const wp={x:0,z:20};const FN=mobile?40:90;
const gh=document.getElementById('gh'),gt=document.getElementById('gt');
const say=m=>{gh.textContent=m||`${C.hint} · ${viewed.size}/3`};
const vis=v=>[B.g,Bm.g,ground,doorGlow,hit,dust,fnt].forEach(o=>o.visible=v);
const GU={value:0},PN=mobile?35:80;let pet,pb,bf=[];
function ctex(w,h,fn,rep,srgb=true){const c=document.createElement('canvas');c.width=w;c.height=h;fn(c.getContext('2d'),w,h);const t=new T.CanvasTexture(c);t.wrapS=t.wrapT=T.RepeatWrapping;if(rep)t.repeat.set(rep[0],rep[1]);t.anisotropy=ANISO;if(srgb)t.encoding=T.sRGBEncoding;return t}
function merge(L){const P=[],N=[],K=[],I=[];let o=0;L.forEach(e=>{const g=e.g.clone().applyMatrix4(e.m),p=g.attributes.position,n=g.attributes.normal;
 for(let i=0;i<p.count;i++){P.push(p.getX(i),p.getY(i),p.getZ(i));N.push(n.getX(i),n.getY(i),n.getZ(i));K.push(e.c.r,e.c.g,e.c.b)}
 if(g.index)for(let i=0;i<g.index.count;i++)I.push(g.index.getX(i)+o);else for(let i=0;i<p.count;i++)I.push(i+o);o+=p.count});
 const G=new T.BufferGeometry();G.setAttribute('position',new T.Float32BufferAttribute(P,3));G.setAttribute('normal',new T.Float32BufferAttribute(N,3));G.setAttribute('color',new T.Float32BufferAttribute(K,3));G.setIndex(I);return G}
function roseGeo(){const L=[],col=new T.Color();
 for(let i=0;i<6;i++){const rad=.1+i*.075,g=new T.SphereGeometry(rad,12,6,0,6.2832,0,1.5708);g.rotateX(Math.PI);const p=g.attributes.position;
  for(let k=0;k<p.count;k++){const x=p.getX(k),y=p.getY(k),z=p.getZ(k);if(y>-rad*.3){const a=Math.atan2(z,x),f=1+i*.03;p.setXYZ(k,x*f,y+Math.sin(a*5+i*1.7)*.2*rad,z*f)}}
  g.scale(1,1.15-i*.08,1);g.rotateY(i*.9);g.translate(0,.2-i*.03,0);const l=.55+i*.09;col.setRGB(l,l*.86,l*.9);L.push({g,m:new T.Matrix4(),c:col.clone()})}
 return merge(L)}
function blob(rad){const g=new T.SphereGeometry(rad,14,10),p=g.attributes.position;
 for(let k=0;k<p.count;k++){const x=p.getX(k),y=p.getY(k),z=p.getZ(k),d=1+.16*Math.sin(x*3.1+1)*Math.sin(y*2.7)*Math.sin(z*3.3+2)+.05*Math.sin(x*9+y*7);p.setXYZ(k,x*d,y*d,z*d)}
 g.computeVertexNormals();return g}
function gs(c,o,s,y){const q=new T.Sprite(new T.SpriteMaterial({map:GT,color:c,opacity:o,transparent:true,depthWrite:false,blending:T.AdditiveBlending}));q.scale.set(s,s,1);q.position.y=y;return q}
function lab(t,y){const c=document.createElement('canvas');c.width=512;c.height=96;const x=c.getContext('2d');x.textAlign='center';x.shadowColor='#ff8fcf';x.shadowBlur=18;x.fillStyle='#fff4fb';x.font='500 46px "Cormorant Garamond",serif';if('letterSpacing' in x)x.letterSpacing='8px';x.fillText(t,256,62);
 const s=new T.Sprite(new T.SpriteMaterial({map:new T.CanvasTexture(c),transparent:true,depthWrite:false,fog:false}));s.scale.set(5,.94,1);s.position.y=y;return s}
const rep=(n,e)=>{console.error('[GS] garden section failed:',n,e);if(window.GSerr)GSerr('garden/'+n+': '+(e&&e.message||e))};
function heal(root){let n=0;root.traverse(o=>{const g=o.geometry;
 if((o.isMesh||o.isPoints)&&(!g||!g.attributes||!g.attributes.position)){o.visible=false;n++;rep('no position attr: '+o.type+(o.isInstancedMesh?' (instanced)':''),'hidden');return}
 if(g&&g.attributes){for(const k in g.attributes){const a=g.attributes[k];if(a==null||!a.array||!(a.count>=0)){delete g.attributes[k];n++;rep('bad attr "'+k+'" on '+g.type+' / '+o.type+(o.isInstancedMesh?' (instanced)':''),'removed')}}if(g.index===undefined)g.index=null}
 if(o.isMesh&&(Array.isArray(o.material)?o.material.some(x=>!x):!o.material)){o.visible=false;n++;rep('no material: '+o.type,'hidden')}
 if(o.isInstancedMesh&&!o.instanceMatrix){o.visible=false;n++;rep('no instanceMatrix','hidden')}});return n}
function frames(e){try{return String(e.stack||'').split('\n').slice(1,9).map(s=>(s.match(/at ([^ (]+)/)||[])[1]||'?').join(' < ')}catch(x){return '?'}}
function bisect(e0){if(S.bis)return;S.bis=1;const L=[];grp.traverse(o=>{if((o.isMesh||o.isPoints)&&o.visible)L.push(o)});L.forEach(o=>o.visible=false);let base=false;try{R.render(scene,cam)}catch(e){base=true}
 if(base){L.forEach(o=>o.visible=true);rep('render fails even with the whole garden hidden - cause is outside the garden objects','');return}
 const bad=[];for(const o of L){o.visible=true;try{R.render(scene,cam)}catch(e){o.visible=false;bad.push(o)}}
 if(bad.length>Math.max(6,L.length*.2)){L.forEach(o=>o.visible=true);rep('too many failing objects ('+bad.length+') - restored all','');return}
 bad.slice(0,6).forEach(o=>{const g=o.geometry,k=g&&g.attributes?Object.keys(g.attributes).join('+'):'-';rep('RENDER FAILS in combination (hidden): '+o.type+' geo='+(g&&g.type)+' attrs='+k+' mat='+(o.material&&(o.material.type||'array'))+(o.isInstancedMesh?' inst='+o.count+' color='+(o.instanceColor?'y':'n'):'')+' #'+L.indexOf(o)+'/'+L.length,'')});
 if(!bad.length)rep('error needs the full scene (not object-specific). stack: '+frames(e0),'')}
function safeRender(){try{R.render(scene,cam)}catch(e){if(!S.bis)rep('render threw @ '+frames(e),e);try{bisect(e)}catch(e2){rep('bisect failed',e2)}try{R.render(scene,cam)}catch(e3){}}}
/* Three r128: إذا شارك InstancedMesh بلا instanceColor مادةً سبق أن رُسمت مع instanceColor فشل الرسم (attributes.get(null)).
   الحل: كل InstancedMesh يأخذ نسخة مادة خاصة بنمطه (مع/بدون ألوان للنسخ) ولا يشارك المادة الأصلية. */
function fixInst(root){const cache=new Map();root.traverse(o=>{if(!o.isInstancedMesh)return;const mt=o.material;if(!mt||Array.isArray(mt))return;const key=mt.id+(o.instanceColor?'c':'n');let c=cache.get(key);
 if(!c){c=mt.clone();c.userData={};if(mt.onBeforeCompile)c.onBeforeCompile=mt.onBeforeCompile;cache.set(key,c)}o.material=c})}
const PLAYER_RADIUS=.42;
function blocked(x,z){
 // Keep the player's centre inside the walkable area, not just their eye point.
 if(x<-13.58||x>13.58||z>25.58||z<-28.58)return true;
 // The central bridge is walkable; its side rails are solid.
 if(z<-13.7&&z>-22.3&&Math.abs(x)>2.48)return true;
 const k=kx(),O=[[0,6,4.2],[-9*k,-1,2],[9*k,-1,2],[4.2*k,-9.5,2],[6.6,8,1.3],[-6.6,8,1.3],[6.6,-4,1.3],[-6.6,-4,1.3],[3,-30,.8],[-3,-30,.8],[-15,-6,1.5],[16,-9,1.6],[-21,5,1.4],[-23,-14,1.8],[12,-25,1.9]];
 for(const c of O)if(Math.hypot(x-c[0],z-c[1])<c[2]+PLAYER_RADIUS)return true;
 for(const z0 of [10,5,0,-5,-10])for(const side of [-5,5])if(Math.hypot(x-side,z-z0)<.8+PLAYER_RADIUS)return true;
 return false;
}
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const smoothstep=(a,b,x)=>{const t=clamp((x-a)/(b-a),0,1);return t*t*(3-2*t)};
function walkStep(dt,mv,on){
 const yaw=View.yaw,sp=(reduce?3:4.2)*dt;
 // Normalize diagonals so moving diagonally is not faster than moving straight.
 let ix=clamp(mv.x||0,-1,1),iy=clamp(mv.y||0,-1,1),len=Math.hypot(ix,iy);if(len>1){ix/=len;iy/=len}
 const fx=-Math.sin(yaw),fz=-Math.cos(yaw),rx=Math.cos(yaw),rz=-Math.sin(yaw);
 const dx=(fx*(-iy)+rx*ix)*sp,dz=(fz*(-iy)+rz*ix)*sp,px=wp.x+dx,pz=wp.z+dz;
 // Axis-separated collision lets the player slide along walls instead of sticking on corners.
 if(!blocked(px,pz)){wp.x=px;wp.z=pz}else if(!blocked(px,wp.z))wp.x=px;else if(!blocked(wp.x,pz))wp.z=pz;
 const depth=-wp.z;
 const bridgeIn=smoothstep(13.7,16.7,depth),bridgeOut=1-smoothstep(22,25,depth);
 const hz=Math.abs(wp.x)<2.55?1.1*Math.min(bridgeIn,bridgeOut):0;
 wy+=(1.75+hz-wy)*Math.min(1,dt*7.5);bob+=on?dt*8.5:0;
 tp.set(wp.x,wy+((reduce||!on)?0:Math.sin(bob)*.028),wp.z);tl.set(wp.x,wy,wp.z-10);
}
const OR={};
function sunset(on){const h=scene.children.find(o=>o.isHemisphereLight);
 if(on){if(!OR.k){OR.k=1;OR.h=h&&[h.color.getHex(),h.groundColor.getHex(),h.intensity];OR.m=[moonL.color.getHex(),moonL.intensity,moonL.position.clone()]}
  skyU.lo.value.set(1,.62,.44);skyU.mid.value.set(.66,.38,.46);skyU.hi.value.set(.26,.26,.44);stars.visible=false;skyM.forEach(s=>s.visible=false);skyC.forEach(c=>{c.material.color.set(0xf0b4a0);c.material.opacity=.5});fogS.forEach(f=>f.material.color.set(0xf0c0b0));
  scene.fog.color.set(0x8a6a78);scene.fog.near=45;scene.fog.far=180;
  if(h){h.color.set(0xffd9c0);h.groundColor.set(0x46543a);h.intensity=.82}R.toneMappingExposure=1.0;
  moonL.visible=true;moonL.color.set(0xffc89a);moonL.intensity=1.3;moonL.position.set(-14,16,-38)}
 else if(OR.k){skyU.lo.value.set(.34,.11,.24);skyU.mid.value.set(.10,.03,.12);skyU.hi.value.set(.02,.01,.04);stars.visible=true;skyM.forEach(s=>s.visible=true);skyC.forEach(c=>{c.material.color.set(0x2a2140);c.material.opacity=.45});fogS.forEach(f=>f.material.color.set(0x7a68ac));
  if(h&&OR.h){h.color.set(OR.h[0]);h.groundColor.set(OR.h[1]);h.intensity=OR.h[2]}moonL.color.set(OR.m[0]);moonL.intensity=OR.m[1];moonL.position.copy(OR.m[2]);R.toneMappingExposure=.92}}
function build(){
 grp=new T.Group();scene.add(grp);gateGlow={material:{opacity:0}};const r=rnd(21),add=(m,x,y,z)=>{m.position.set(x,y,z);grp.add(m);return m},o=new T.Object3D();
 const rr=(x,a,b,w,h,k)=>{x.beginPath();x.roundRect?x.roundRect(a,b,w,h,k):x.rect(a,b,w,h);x.fill()};
 const far=(x,z)=>[[-9*kx(),-1],[4.2*kx(),-9.5],[9*kx(),-1],[0,6],[6.6,8],[-6.6,8],[6.6,-4],[-6.6,-4]].every(a=>Math.hypot(x-a[0],z-a[1])>3.8);
 // textures + materials
 const gtex=ctex(512,512,(x,w,h)=>{x.fillStyle='#26391f';x.fillRect(0,0,w,h);for(let i=0;i<9000;i++){x.fillStyle=`rgba(${38+r()*30|0},${66+r()*42|0},${38+r()*22|0},.4)`;x.fillRect(r()*w,r()*h,2+r()*4,2+r()*4)}},[26,26]);
 const ptx=ctex(512,512,(x,w,h)=>{x.fillStyle='#08070c';x.fillRect(0,0,w,h);for(let j=0;j<4;j++)for(let i=0;i<3;i++){x.fillStyle=`hsl(265,9%,${24+r()*12}%)`;rr(x,i*170+(j%2)*28+5,j*128+5,156,118,16)}for(let i=0;i<2500;i++){x.fillStyle='rgba(255,255,255,.05)';x.fillRect(r()*w,r()*h,2,2)}},[1,10]);
 const mt=ctex(256,256,(x,w,h)=>{x.fillStyle='#eadfce';x.fillRect(0,0,w,h);for(let i=0;i<26;i++){x.strokeStyle=`rgba(130,105,90,${.08+r()*.18})`;x.lineWidth=.6+r()*1.8;x.beginPath();x.moveTo(r()*w,0);x.bezierCurveTo(r()*w,h*.3,r()*w,h*.6,r()*w,h);x.stroke()}});
 const furT=ctex(256,256,(x,w,h)=>{x.fillStyle='#777';x.fillRect(0,0,w,h);for(let i=0;i<5000;i++){const a=r()*w,b=r()*h;x.strokeStyle=`rgba(${r()>.5?255:0},${r()>.5?255:0},255,.18)`;x.strokeStyle=r()>.5?'rgba(255,255,255,.2)':'rgba(0,0,0,.25)';x.beginPath();x.moveTo(a,b);x.lineTo(a+(r()-.5)*4,b+6+r()*8);x.stroke()}},[2,2],false);
 const stT=ctex(64,64,x=>{const g=x.createRadialGradient(32,32,0,32,32,32);g.addColorStop(0,'rgba(0,0,0,.8)');g.addColorStop(1,'rgba(0,0,0,0)');x.fillStyle=g;x.fillRect(0,0,64,64)});
 const marble=new T.MeshStandardMaterial({map:mt,bumpMap:mt,bumpScale:.5,color:0xf6ecdc,roughness:.22,metalness:.05}),fm=M(0x3a6a42,.9),bm=M(0x2a1f1a,1),leafM=M(0x4a8250,.6),pk=M(0xff9fc8,.5,0,0x8a2a58);
 const cm=new T.MeshStandardMaterial({color:0xf3a9cb,roughness:.8,emissive:0xb04c85,emissiveIntensity:.18}),lg=new T.SphereGeometry(1,8,6).scale(.2,.02,.09).translate(.2,0,0);
 const shadow=(x,z,s)=>{const m=new T.Mesh(new T.PlaneGeometry(s,s),new T.MeshBasicMaterial({map:stT,transparent:true,depthWrite:false}));m.rotation.x=-Math.PI/2;add(m,x,.035,z)};
 // ===== Roman garden: marble, water, bridge, heart fountain =====
 const RG=roseGeo(),cols=[0xf4b6c8,0xfff3e6,0xd98ba4,0xc9728f,0xf8cfd8];
 const mtI=ctex(256,256,(x,w,h)=>{x.fillStyle='#eadfce';x.fillRect(0,0,w,h);for(let i=0;i<28;i++){x.strokeStyle=`rgba(130,105,90,${.04+r()*.07})`;x.lineWidth=.5+r()*1.6;x.beginPath();x.moveTo(r()*w,0);x.bezierCurveTo(r()*w,h*.3,r()*w,h*.6,r()*w,h);x.stroke()}for(let i=0;i<1500;i++){x.fillStyle=`rgba(255,255,255,${r()*.06})`;x.fillRect(r()*w,r()*h,2,2)}});
 const mtS=mtI.clone();mtS.repeat.set(.3,.3);mtS.needsUpdate=true;
 const ivory=new T.MeshStandardMaterial({map:mtI,bumpMap:mtI,bumpScale:.4,roughness:.42,metalness:.02}),ivoryS=new T.MeshStandardMaterial({map:mtS,bumpMap:mtS,bumpScale:.4,roughness:.42,metalness:.02});
 const flT=ctex(256,16,(x,w,h)=>{x.fillStyle='#999';x.fillRect(0,0,w,h);for(let i=0;i<24;i++){x.fillStyle='#333';x.fillRect(i*w/24+2,0,w/24*.35,h)}},[1,1],false);
 const shaftM=new T.MeshStandardMaterial({map:mtI,bumpMap:flT,bumpScale:2.5,roughness:.45});
 wt=ctex(128,128,(x,w,h)=>{x.fillStyle='#808080';x.fillRect(0,0,w,h);for(let i=0;i<220;i++){x.strokeStyle=r()>.5?'rgba(255,255,255,.18)':'rgba(0,0,0,.18)';x.lineWidth=1+r()*2;x.beginPath();const a=r()*w,b=r()*h;x.moveTo(a,b);x.quadraticCurveTo(a+10,b+4,a+24+r()*14,b);x.stroke()}},[10,1],false);
 wt2=wt.clone();wt2.repeat.set(.22,.22);wt2.needsUpdate=true;
 const wM=(m)=>new T.MeshStandardMaterial({color:0x4f8a84,roughness:.05,metalness:.05,transparent:true,opacity:.86,bumpMap:m,bumpScale:.35,depthWrite:false});
 const ID=new T.Matrix4(),WH=new T.Color(1,1,1),part=(a,g)=>a.push({g,m:ID,c:WH});
 function mergeU(L){const P=[],N=[],U=[],I=[];let off=0;L.forEach(e=>{const g=e.g.clone().applyMatrix4(e.m),p=g.attributes.position,n=g.attributes.normal,u=g.attributes.uv;for(let i=0;i<p.count;i++){P.push(p.getX(i),p.getY(i),p.getZ(i));N.push(n.getX(i),n.getY(i),n.getZ(i));U.push(u?u.getX(i):0,u?u.getY(i):0)}if(g.index)for(let i=0;i<g.index.count;i++)I.push(g.index.getX(i)+off);else for(let i=0;i<p.count;i++)I.push(i+off);off+=p.count});const G=new T.BufferGeometry();G.setAttribute('position',new T.Float32BufferAttribute(P,3));G.setAttribute('normal',new T.Float32BufferAttribute(N,3));G.setAttribute('uv',new T.Float32BufferAttribute(U,2));G.setIndex(I);return G}
 // lawn + marble promenade (individual slabs with colour variation) + curbs
 add(new T.Mesh(new T.CircleGeometry(70,48),new T.MeshStandardMaterial({map:gtex,roughness:.95,bumpMap:NT,bumpScale:.12})),0,0,-8).rotation.x=-Math.PI/2;
 try{const rows=[];for(let j=0;j<15;j++){const z=13.4-j*3.2;if(z<-12.5&&z>-23.5)continue;rows.push(z)}const sl=new T.InstancedMesh(new T.BoxGeometry(3.12,.06,3.12),ivory,rows.length*2);let n=0;
  rows.forEach(z=>[0,1].forEach(i=>{o.position.set(-1.6+i*3.2,.05,z);o.rotation.set(0,Math.floor(r()*4)*1.5708,0);o.scale.set(1,1,1);o.updateMatrix();sl.setMatrixAt(n,o.matrix);const v=.88+r()*.12;sl.setColorAt(n,new T.Color(v,v*.97,v*.93));n++}));grp.add(sl)}catch(e){rep('slabs',e)}
 [-1,1].forEach(s=>{add(new T.Mesh(new T.BoxGeometry(.4,.2,26),ivory),s*3.4,.1,.5);add(new T.Mesh(new T.BoxGeometry(.4,.2,16),ivory),s*3.4,.1,-31)});
 // stream with stone coping
 add(new T.Mesh(new T.PlaneGeometry(90,8),M(0x2c3a40,.9)),0,.03,-18).rotation.x=-Math.PI/2;
 add(new T.Mesh(new T.PlaneGeometry(90,8),wM(wt)),0,.16,-18).rotation.x=-Math.PI/2;
 [-14,-22].forEach(z=>add(new T.Mesh(new T.BoxGeometry(90,.4,.55),ivory),0,.2,z));
 // Roman arch bridge
 try{const bs=new T.Shape();bs.moveTo(-4.4,0);bs.lineTo(4.4,0);bs.lineTo(4.4,1.1);bs.lineTo(-4.4,1.1);bs.lineTo(-4.4,0);const hp=new T.Path();hp.absellipse(0,.03,3.6,.95,0,Math.PI,false);hp.lineTo(3.6,.03);bs.holes.push(hp);
  const bg=new T.ExtrudeGeometry(bs,{depth:6.4,bevelEnabled:false,curveSegments:24});bg.translate(0,0,-3.2);bg.rotateY(Math.PI/2);add(new T.Mesh(bg,ivory),0,0,-18);
  for(let k=0;k<4;k++)[-1,1].forEach(s=>add(new T.Mesh(new T.BoxGeometry(6.4,(k+1)*.275,.6),ivory),0,(k+1)*.1375,-18+s*(4.7+.3+(3-k)*.6)));
  [-1,1].forEach(s=>{add(new T.Mesh(new T.BoxGeometry(.45,.14,9),ivory),s*3.05,1.1+.85,-18);add(new T.Mesh(new T.BoxGeometry(.4,.1,9),ivory),s*3.05,1.22,-18);[-1,1].forEach(e=>{add(new T.Mesh(new T.BoxGeometry(.55,1,.55),ivory),s*3.05,1.6,-18+e*4.4);const u=new T.Mesh(urnG,ivory);u.scale.setScalar(.9);add(u,s*3.05,2.1,-18+e*4.4)})});
  const bl=new T.InstancedMesh(new T.CylinderGeometry(.07,.09,.7,8),ivory,24);let n=0;[-1,1].forEach(s=>{for(let i=0;i<12;i++){o.position.set(s*3.05,1.1+.6,-18-3.9+i*.71);o.rotation.set(0,0,0);o.updateMatrix();bl.setMatrixAt(n++,o.matrix)}});grp.add(bl)}catch(e){rep('bridge',e)}
 // heart fountain
 try{const hs=s=>{const h=new T.Shape();h.moveTo(0,-1.1*s);h.bezierCurveTo(-.2*s,-.8*s,-1.7*s,-.3*s,-1.7*s,.5*s);h.bezierCurveTo(-1.7*s,1.2*s,-.9*s,1.6*s,0,.95*s);h.bezierCurveTo(.9*s,1.6*s,1.7*s,1.2*s,1.7*s,.5*s);h.bezierCurveTo(1.7*s,-.3*s,.2*s,-.8*s,0,-1.1*s);return h};
  const cs=QL?28:16,outer=hs(3.4);outer.holes.push(hs(2.9));
  const rim=new T.ExtrudeGeometry(outer,{depth:.9,bevelEnabled:true,bevelThickness:.08,bevelSize:.08,bevelSegments:2,curveSegments:cs});rim.rotateX(-Math.PI/2);add(new T.Mesh(rim,ivoryS),0,0,6);
  const fl=new T.ShapeGeometry(hs(2.9),cs);fl.rotateX(-Math.PI/2);add(new T.Mesh(fl,M(0xb8a99a,.6)),0,.3,6);
  const wf=new T.ShapeGeometry(hs(2.86),cs);wf.rotateX(-Math.PI/2);add(new T.Mesh(wf,wM(wt2)),0,.62,6);
  add(new T.Mesh(new T.CylinderGeometry(.28,.42,1.4,20),ivory),0,1.05,5.8);const bw=new T.Mesh(new T.SphereGeometry(.8,24,10,0,6.2832,1.5708,1.5708),ivory);bw.material=ivory.clone();bw.material.side=T.DoubleSide;add(bw,0,1.95,5.8);
  const fr=new T.Mesh(roseGeo(),new T.MeshStandardMaterial({vertexColors:true,color:0xf4b6c8,roughness:.5,side:T.DoubleSide}));fr.scale.setScalar(.75);add(fr,0,2.25,5.8);
  const pt=new T.InstancedMesh(new T.SphereGeometry(1,8,6).scale(.1,.012,.07),pk,36);for(let i=0;i<36;i++){let x,z;do{x=(r()-.5)*4.4;z=(r()-.5)*4.2}while((x/2.3)**2+(z/2.1)**2>1);o.position.set(x,.64,6+z);o.rotation.set(0,r()*6,0);o.scale.set(1,1,1);o.updateMatrix();pt.setMatrixAt(i,o.matrix)}grp.add(pt)}catch(e){rep('heart fountain',e)}
 // grass (swaying)
 try{ const GN=[1400,3000,7000][QL],gm=new T.MeshStandardMaterial({roughness:1,side:T.DoubleSide});
 gm.onBeforeCompile=s=>{s.uniforms.uT=GU;s.vertexShader='uniform float uT;\n'+s.vertexShader.replace('#include <begin_vertex>','vec3 transformed=vec3(position);transformed.x+=sin(uT*1.6+instanceMatrix[3].x*.6+instanceMatrix[3].z*.4)*.07*position.y;transformed.z+=cos(uT*1.3+instanceMatrix[3].x*.4)*.05*position.y;')};
 const gi=new T.InstancedMesh(new T.ConeGeometry(.035,.55,3,1,true).translate(0,.275,0),gm,GN);let cx=0,cz=0;
 for(let i=0;i<GN;i++){if(i%12===0){do{cx=(r()-.5)*54;cz=(r()-.5)*54-4}while(Math.abs(cx)<3.5||Math.hypot(cx,cz+2)>28||!far(cx,cz)||(cz<-13&&cz>-23))}
  o.position.set(cx+(r()-.5)*1.1,0,cz+(r()-.5)*1.1);o.rotation.set((r()-.5)*.3,r()*6,(r()-.5)*.3);o.scale.set(1,.6+r()*1.1,1);o.updateMatrix();gi.setMatrixAt(i,o.matrix);gi.setColorAt(i,new T.Color().setHSL(.27+r()*.08,.5,.22+r()*.12))}
 grp.add(gi)}catch(e){rep('grass',e)}
 // rose bushes
 try{ const BN=[10,18,34][QL],PB=6,N=BN*PB;
 const rh=new T.InstancedMesh(RG,new T.MeshStandardMaterial({vertexColors:true,roughness:.5,side:T.DoubleSide,emissive:0x2a0c1c}),N),rs=new T.InstancedMesh(new T.CylinderGeometry(.012,.02,1,5).translate(0,.5,0),M(0x1f3d28,1),N),rl=new T.InstancedMesh(lg,leafM,N*2),bu=new T.InstancedMesh(blob(1),fm,BN);
 const q=new T.Quaternion(),up=new T.Vector3(0,1,0),d=new T.Vector3();let ri=0,li=0;
 for(let b=0;b<BN;b++){let bx,bz;do{bx=(r()-.5)*28;bz=-12+r()*26}while(Math.abs(bx)<3.9||Math.abs(bx)>13||!far(bx,bz));
  o.position.set(bx,.3,bz);o.rotation.set(0,r()*6,0);o.scale.set(1+r()*.5,.55,1+r()*.5);o.updateMatrix();bu.setMatrixAt(b,o.matrix);
  for(let p=0;p<PB;p++){const a=r()*6.28,rd=r()*.9,hx=bx+Math.cos(a)*rd,hz=bz+Math.sin(a)*rd,hy=.8+r()*.7;d.set(hx-bx,hy-.2,hz-bz);const len=d.length();d.normalize();q.setFromUnitVectors(up,d);
   o.position.set(bx,.2,bz);o.quaternion.copy(q);o.scale.set(1,len,1);o.updateMatrix();rs.setMatrixAt(ri,o.matrix);
   o.position.set(hx,hy+.12,hz);o.rotation.set((r()-.5)*.5,r()*6,(r()-.5)*.5);const s=.45+r()*.25;o.scale.setScalar(s);o.updateMatrix();rh.setMatrixAt(ri,o.matrix);rh.setColorAt(ri,new T.Color(cols[ri%5]));ri++;
   for(let k=0;k<2;k++){const t=(.35+k*.25)*len;o.position.set(bx+d.x*t,.2+d.y*t,bz+d.z*t);o.rotation.set(0,r()*6,.3);o.scale.setScalar(.7+r()*.5);o.updateMatrix();rl.setMatrixAt(li++,o.matrix)}}}
 grp.add(rh,rs,rl,bu)}catch(e){rep('roses',e)}
 // trees
 try{ function tree(x,z,s,ch){const g=new T.Group();g.position.set(x,0,z);g.scale.setScalar(s);const tk=new T.Mesh(new T.CylinderGeometry(.14,.3,3,8),bm);tk.position.y=1.5;g.add(tk);
  [-1,1].forEach(k=>{const b=new T.Mesh(new T.CylinderGeometry(.05,.1,1.6,6),bm);b.position.set(k*.55,3.1,0);b.rotation.z=-k*.7;g.add(b)});
  [[0,4.4,0,1.5],[-1.1,3.9,.3,1.1],[1.1,4,-.2,1.2],[.2,5.2,.3,1],[-.4,4.2,-1,1.05],[.5,3.9,.9,1]].forEach(a=>{const f=new T.Mesh(blob(a[3]),ch?cm:fm);f.position.set(a[0],a[1],a[2]);g.add(f)});grp.add(g);shadow(x,z,6*s)}
 [[-15,-6,2,1],[16,-9,2.2,1],[-21,5,1.9,1],[-23,-14,2.4],[24,-3,2.3],[-9,-24,2.5],[12,-25,2.6]].forEach(a=>tree(a[0],a[1],a[2],a[3]));
 const tl2=new T.InstancedMesh(new T.ConeGeometry(1,1,7),M(0x2a4632,1),44);
 for(let i=0;i<44;i++){const a=i/44*6.283,rd=40+r()*5,h=6+r()*6;o.position.set(Math.cos(a)*rd,h/2,Math.sin(a)*rd-2);o.rotation.set(0,0,0);o.scale.set(h*.2,h,h*.2);o.updateMatrix();tl2.setMatrixAt(i,o.matrix)}grp.add(tl2);
 // lanterns
 [10,3,-4,-11].forEach(z=>[-1,1].forEach(s=>{const x=s*2.4;add(new T.Mesh(new T.CylinderGeometry(.04,.06,2.2,8),bm),x,1.1,z);add(new T.Mesh(new T.BoxGeometry(.28,.38,.28),new T.MeshBasicMaterial({color:0xffe2f1})),x,2.4,z);const g=gs(0xff9fd2,.6,3,2.4);g.position.x=x;g.position.z=z;grp.add(g)}));}catch(e){rep('trees',e)}
 // pedestals
 function ped(id,x,z,title,fill){const g=new T.Group();g.position.set(x*kx(),0,z);
  [[1.5,1.6,.22,.11],[1.1,1.25,.62,.53],[1.4,1.25,.16,.92]].forEach(a=>{const m=new T.Mesh(new T.CylinderGeometry(a[0],a[1],a[2],32),marble);m.position.y=a[3];g.add(m)});
  const rg=new T.Mesh(new T.TorusGeometry(1.32,.03,8,48),pinkM);rg.rotation.x=Math.PI/2;rg.position.y=1.01;g.add(rg);
  const dm=new T.Mesh(new T.SphereGeometry(1.1,28,16,0,6.283,0,1.5708),new T.MeshStandardMaterial({color:0xffffff,transparent:true,opacity:.1,roughness:0,metalness:.3,depthWrite:false}));dm.position.y=1;dm.scale.y=1.5;g.add(dm);
  fill(g);g.add(gs(0xff8fcf,.28,6,2),lab(title,4.1));
  const h=new T.Mesh(new T.SphereGeometry(2.6,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));h.position.y=2.2;h.userData.id=id;g.add(h);hits.push(h);
  ex[id]=g.position;grp.add(g);shadow(g.position.x,z,5)}
 try{ped('rose',-9,-1,'THE ROSE',g=>{const m=new T.Mesh(RG,new T.MeshStandardMaterial({vertexColors:true,color:0xff5fa8,roughness:.45,side:T.DoubleSide,emissive:0x5a1038,emissiveIntensity:.3}));m.scale.setScalar(1.7);m.position.y=2.25;g.add(m);
  const st=new T.Mesh(new T.CylinderGeometry(.03,.045,1.3,8),M(0x1f3d28,1));st.position.y=1.65;g.add(st);
  [[1.5,.6,1],[1.85,-2.4,-1],[1.2,2.2,1]].forEach(a=>{const l=new T.Mesh(lg,leafM);l.scale.setScalar(2.2);l.position.y=a[0];l.rotation.set(0,a[1],.5*a[2]);g.add(l)});
  for(let i=0;i<6;i++){const p=new T.Mesh(new T.SphereGeometry(1,8,6).scale(.13,.012,.08),pk);p.position.set(Math.cos(i*1.1)*.7,1.02,Math.sin(i*1.1)*.7);p.rotation.y=i*2;g.add(p)}});}catch(e){rep('exhibit rose',e)}
 try{ped('cat',4.2,-9.5,'THE CAT',g=>{const fur=new T.MeshStandardMaterial({color:0x4a4256,roughness:.9,bumpMap:furT,bumpScale:1.4,emissive:0x140a1c}),wh=new T.MeshBasicMaterial({color:0xf0e8f4}),
  eye=new T.MeshStandardMaterial({color:0xd7ee70,emissive:0x8aa030,emissiveIntensity:.7}),bk=new T.MeshBasicMaterial({color:0x050308}),c=new T.Group();c.position.y=1;c.scale.setScalar(.78);g.add(c);catG=c;
  const S=(geo,m,x,y,z,sx=1,sy=1,sz=1)=>{const k=new T.Mesh(geo,m);k.position.set(x,y,z);k.scale.set(sx,sy,sz);c.add(k);return k};
  S(new T.LatheGeometry([[0,0],[.5,.04],[.62,.3],[.52,.8],[.4,1.2],[.32,1.5],[0,1.58]].map(a=>new T.Vector2(a[0],a[1])),24),fur,0,.05,0,1,1,.85);
  S(new T.SphereGeometry(.36,24,18),fur,0,2.3,.08,1.05,.9,.95);S(new T.SphereGeometry(.17,16,12),fur,0,2.2,.36,1.1,.8,.9);S(new T.SphereGeometry(.05,8,6),pk,0,2.27,.5);
  [-1,1].forEach(s=>{S(new T.SphereGeometry(.4,16,12),fur,s*.36,.42,-.05,.8,.95,1.15);S(new T.CylinderGeometry(.1,.13,.9,10),fur,s*.18,.5,.42);S(new T.SphereGeometry(.15,12,8),fur,s*.18,.07,.55,1,.6,1.35);
   S(new T.ConeGeometry(.14,.32,4),fur,s*.22,2.62,.02).rotation.z=-s*.25;S(new T.ConeGeometry(.08,.2,4),pk,s*.22,2.6,.1).rotation.z=-s*.25;
   S(new T.SphereGeometry(.075,12,10),eye,s*.14,2.36,.34);S(new T.SphereGeometry(.075,8,8),bk,s*.14,2.36,.4,.25,1,.4);
   [-1,0,1].forEach(k=>S(new T.CylinderGeometry(.004,.004,.5,3),wh,s*.42,2.24+k*.04,.4).rotation.z=Math.PI/2+k*s*.12)});
  S(new T.TubeGeometry(new T.CatmullRomCurve3([[.35,.1,-.25],[.75,.08,-.1],[.85,.08,.35],[.55,.1,.7],[.3,.2,.75]].map(a=>new T.Vector3(...a))),24,.07,8),fur,0,0,0)});}catch(e){rep('exhibit cat',e)}
 try{ped('quiet',9,-1,'THE QUIET',g=>{const w=new T.Mesh(new T.CircleGeometry(.98,40),new T.MeshStandardMaterial({color:0x1f4660,roughness:.03,metalness:.95,transparent:true,opacity:.92,emissive:0x0a2030}));w.rotation.x=-Math.PI/2;w.position.y=1.04;g.add(w);
  for(let i=0;i<14;i++){const a=i/14*6.283,s=new T.Mesh(blob(.14+r()*.07),M(0x3a3640,.9));s.scale.y=.6;s.position.set(Math.cos(a),1.07,Math.sin(a));g.add(s)}
  [[.3,.2],[-.35,-.25],[.1,-.5]].forEach(a=>{const l=new T.Mesh(new T.CircleGeometry(.16,12),M(0x2f6a46,.6));l.rotation.x=-Math.PI/2;l.position.set(a[0],1.055,a[1]);g.add(l);if(a[0]>0){const f=new T.Mesh(new T.SphereGeometry(.06,8,6),pk);f.position.set(a[0],1.09,a[1]);g.add(f)}});
  for(let i=0;i<9;i++){const a=r()*6.283,h=.7+r()*.5,x=Math.cos(a)*.78,z=Math.sin(a)*.78,c=new T.Mesh(new T.CylinderGeometry(.008,.012,h,4),M(0x3c6a3a,1));c.position.set(x,1.05+h/2,z);c.rotation.z=(r()-.5)*.2;g.add(c);if(i%3===0){const t=new T.Mesh(new T.CylinderGeometry(.03,.03,.16,6),bm);t.position.set(x,1.05+h,z);g.add(t)}}
  const t=new T.Mesh(new T.CylinderGeometry(.02,.04,.7,6),bm);t.position.set(-.5,1.4,.2);g.add(t);const f=new T.Mesh(blob(.28),cm);f.position.set(-.5,1.85,.2);g.add(f)});
}catch(e){rep('exhibit quiet',e)}
 // ===== Corinthian colonnade, pergola, statues =====
 try{const bl=[],cl=[];part(bl,new T.BoxGeometry(1.3,.25,1.3).translate(0,.125,0));part(bl,new T.CylinderGeometry(.62,.66,.18,24).translate(0,.34,0));part(bl,new T.TorusGeometry(.56,.06,8,24).rotateX(Math.PI/2).translate(0,.5,0));
  part(cl,new T.LatheGeometry([[.42,0],[.48,.12],[.58,.35],[.66,.62],[.7,.72]].map(a=>new T.Vector2(a[0],a[1])),24));
  for(let i=0;i<12;i++){const a=i/12*6.283;part(cl,new T.SphereGeometry(.16,8,6).scale(.7,1.6,.45).rotateY(-a).translate(Math.cos(a)*.52,.3,Math.sin(a)*.52))}
  [0,1,2,3].forEach(i=>{const a=i*1.5708+.785;part(cl,new T.TorusGeometry(.13,.04,6,12).translate(Math.cos(a)*.7,.72,Math.sin(a)*.7))});part(cl,new T.BoxGeometry(1.45,.2,1.45).translate(0,.82,0));
  const CZ=[10,5,0,-5,-10],NC=CZ.length*2,shaft=new T.InstancedMesh(new T.CylinderGeometry(.42,.48,6.4,QL?24:16),shaftM,NC),bI=new T.InstancedMesh(mergeU(bl),ivory,NC),cI=new T.InstancedMesh(mergeU(cl),ivory,NC);
  CZ.forEach((z,i)=>[-1,1].forEach((s,k)=>{const n=i*2+k;o.rotation.set(0,0,0);o.scale.set(1,1,1);o.position.set(s*5,3.7,z);o.updateMatrix();shaft.setMatrixAt(n,o.matrix);o.position.set(s*5,0,z);o.updateMatrix();bI.setMatrixAt(n,o.matrix);o.position.set(s*5,6.9,z);o.updateMatrix();cI.setMatrixAt(n,o.matrix);shadow(s*5,z,2.6)}));
  grp.add(shaft,bI,cI);
  [-1,1].forEach(s=>{add(new T.Mesh(new T.BoxGeometry(1.5,.7,22),ivory),s*5,8.17,0);add(new T.Mesh(new T.BoxGeometry(1.35,.5,22),ivory),s*5,8.77,0);add(new T.Mesh(new T.BoxGeometry(1.95,.28,22.4),ivory),s*5,9.16,0);add(new T.Mesh(new T.BoxGeometry(1.7,.1,22.2),goldM2),s*5,8.5,0)});
  CZ.forEach(z=>add(new T.Mesh(new T.BoxGeometry(10.8,.3,.5),ivory),0,8.05,z));
  const dn=new T.InstancedMesh(new T.BoxGeometry(.18,.18,.2),ivory,120);for(let i=0;i<60;i++)[-1,1].forEach((s,k)=>{o.position.set(s*4.22,8.93,-11.8+i*.4);o.rotation.set(0,0,0);o.updateMatrix();dn.setMatrixAt(i*2+k,o.matrix)});grp.add(dn);
  // climbing leaves + pergola roses
  const LV=[70,160,280][QL],lv=new T.InstancedMesh(lg,leafM,LV);for(let i=0;i<LV;i++){if(i%2){const z=CZ[(r()*5)|0];o.position.set((r()-.5)*10,7.6+r()*.4,z+(r()-.5)*.4)}else{const s=r()>.5?1:-1,a=r()*6.283,y=.8+r()*6;o.position.set(s*5+Math.cos(a)*.5,y,CZ[(r()*5)|0]+Math.sin(a)*.5)}o.rotation.set(r()*3,r()*6,r()*3);o.scale.setScalar(.9+r()*.9);o.updateMatrix();lv.setMatrixAt(i,o.matrix);lv.setColorAt(i,new T.Color().setHSL(.27+r()*.08,.45,.2+r()*.14))}grp.add(lv);
  const RP=[8,22,40][QL],ar=new T.InstancedMesh(RG,new T.MeshStandardMaterial({vertexColors:true,roughness:.5,side:T.DoubleSide}),RP);for(let i=0;i<RP;i++){o.position.set((r()-.5)*10,7.7+r()*.3,CZ[(r()*5)|0]+(r()-.5)*.4);o.rotation.set(r(),r()*6,r());o.scale.setScalar(.28+r()*.14);o.updateMatrix();ar.setMatrixAt(i,o.matrix);ar.setColorAt(i,new T.Color(cols[i%5]))}grp.add(ar)}catch(e){rep('columns',e)}
 // marble statues (draped figures with carved folds)
 try{const L=[];part(L,(()=>{const g=new T.LatheGeometry([[0,0],[.62,0],[.66,.25],[.55,.9],[.42,1.35],[.34,1.7],[.36,1.95],[.3,2.2],[.2,2.35],[0,2.4]].map(a=>new T.Vector2(a[0],a[1])),32),p=g.attributes.position;
   for(let i=0;i<p.count;i++){const x=p.getX(i),y=p.getY(i),z=p.getZ(i),a=Math.atan2(z,x),k=1+.07*Math.sin(a*7+y*1.8)*Math.min(1,(2.2-y)/1.2);p.setXYZ(i,x*k,y,z*k)}g.computeVertexNormals();return g})());
  part(L,new T.SphereGeometry(.2,16,12).scale(.9,1.1,1).translate(0,2.62,0));part(L,new T.SphereGeometry(.1,10,8).translate(0,2.74,-.17));part(L,new T.SphereGeometry(.34,16,10).scale(1,.35,.7).translate(0,2.38,0));
  [-1,1].forEach(s=>part(L,new T.TubeGeometry(new T.CatmullRomCurve3([new T.Vector3(s*.3,2.35,0),new T.Vector3(s*.42,1.9,.18),new T.Vector3(s*.12,1.9,.42)]),12,.06,8)));part(L,new T.SphereGeometry(.09,10,8).translate(0,1.95,.46));
  const sg=mergeU(L);[[6.6,8,-.5],[-6.6,8,.5],[6.6,-4,-.5],[-6.6,-4,.5]].forEach(a=>{const g=new T.Group();g.position.set(a[0],0,a[1]);g.rotation.y=(a[0]>0?-Math.PI/2:Math.PI/2)+a[2];grp.add(g);
   [[1.4,.3,1.4,.15],[1.05,1.1,1.05,.85],[1.3,.22,1.3,1.5]].forEach(b=>{const m=new T.Mesh(new T.BoxGeometry(b[0],b[1],b[2]),ivory);m.position.y=b[3];g.add(m)});const st=new T.Mesh(sg,ivory);st.position.y=1.61;st.scale.setScalar(1.1);g.add(st);shadow(a[0],a[1],3.6)})}catch(e){rep('statues',e)}
 // benches, sun glare, flowers, petals, butterflies
 [-1,1].forEach(s=>{add(new T.Mesh(new T.BoxGeometry(2.4,.12,.7),ivory),s*4.2,.5,1.5);[-1,1].forEach(e=>add(new T.Mesh(new T.BoxGeometry(.15,.5,.6),ivory),s*4.2+e*1,.25,1.5))});
 try{const g=gs(0xffc890,.55,70,0);g.position.set(-18,10,-85);g.material.fog=false;grp.add(g);
  const DN2=[120,240,380][QL],ds=new T.InstancedMesh(new T.CircleGeometry(.1,8).rotateX(-Math.PI/2),new T.MeshStandardMaterial({roughness:.6,side:T.DoubleSide}),DN2),dc=[0xffffff,0xfff0e6,0xf4c6d4,0xe8d0ff];
  for(let i=0;i<DN2;i++){let x,z;do{x=(r()-.5)*40;z=-30+r()*44}while(Math.abs(x)<3.7||!far(x,z)||(z<-13&&z>-23));o.position.set(x,.22+r()*.18,z);o.rotation.set((r()-.5)*.4,0,(r()-.5)*.4);o.scale.setScalar(.8+r()*.6);o.updateMatrix();ds.setMatrixAt(i,o.matrix);ds.setColorAt(i,new T.Color(dc[i%4]))}grp.add(ds);
  const PT=new T.InstancedMesh(new T.SphereGeometry(1,8,6).scale(.09,.01,.06),pk,70);for(let i=0;i<70;i++){o.position.set((r()-.5)*5.6,.1,-12+r()*24);o.rotation.set(0,r()*6,0);o.scale.set(1,1,1);o.updateMatrix();PT.setMatrixAt(i,o.matrix)}grp.add(PT);
  for(let i=0;i<[3,5,8][QL];i++){const b=new T.Group(),mt=new T.MeshBasicMaterial({color:[0xf2a6c4,0xe8d0ff,0xffe0c0][i%3],side:T.DoubleSide}),W=[-1,1].map(s=>{const w=new T.Mesh(new T.PlaneGeometry(.2,.15).translate(s*.1,0,0),mt);b.add(w);return w});b.userData={W,p:[r()*6,.5+r()*.5,-3+r()*6,1.2+r()*1.2,4+r()*8,4+r()*8]};grp.add(b);bf.push(b)}}catch(e){rep('details',e)}
 // gate
 try{ const ga=new T.Group();ga.position.set(0,0,-30);grp.add(ga);
 [-3,3].forEach(x=>{const c=new T.Mesh(new T.CylinderGeometry(.5,.55,6.5,20),shaftM);c.position.set(x,3.25,0);ga.add(c)});
 const ar=new T.Mesh(new T.TorusGeometry(3,.18,8,40,Math.PI),goldM2);ar.position.y=6.5;ga.add(ar);
 gateGlow=new T.Mesh(new T.PlaneGeometry(6,8),new T.MeshBasicMaterial({color:0xffc9a0,transparent:true,opacity:.03,blending:T.AdditiveBlending,depthWrite:false}));gateGlow.position.y=4;ga.add(gateGlow);ga.add(lab('THE GATE',10.4));
 const gh2=new T.Mesh(new T.SphereGeometry(4.5,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));gh2.position.y=4;gh2.userData.id='gate';ga.add(gh2);hits.push(gh2);ex.gate=new T.Vector3(0,0,-30)}catch(e){rep('gate',e)}
 // lights, fireflies, petals
 try{ const fillL=new T.DirectionalLight(0xffe6d0,.65);fillL.position.set(8,14,34);grp.add(fillL);const pl=new T.PointLight(0xffd0a0,.9,34,2);pl.position.set(0,6,4);grp.add(pl);const cl2=new T.PointLight(0xffb48a,.9,36,2);cl2.position.set(0,5,-26);grp.add(cl2);
 const fp=new Float32Array(FN*3);for(let i=0;i<FN;i++)fp.set([(r()-.5)*40,.6+r()*4,-14+r()*34],i*3);fb=fp.slice();
 fire=new T.Points(new T.BufferGeometry().setAttribute('position',new T.BufferAttribute(fp,3)),new T.PointsMaterial({map:GT,size:.28,color:0xfff2a8,transparent:true,opacity:.9,depthWrite:false,blending:T.AdditiveBlending}));grp.add(fire);
 const pp=new Float32Array(PN*3),tr=[[-15,-6],[16,-9],[-21,5]];for(let i=0;i<PN;i++){const a=tr[i%3];pp.set([a[0]+(r()-.5)*9,r()*11,a[1]+(r()-.5)*9],i*3)}
 pet=new T.Points(new T.BufferGeometry().setAttribute('position',new T.BufferAttribute(pp,3)),new T.PointsMaterial({map:GT,size:.22,color:0xffb3d6,transparent:true,opacity:.85,depthWrite:false}));grp.add(pet)}catch(e){rep('lights',e)}
}
function finish(){leaving=.001;gh.classList.remove('on')}
return Object.assign(S,{lab,heal:()=>grp?heal(grp):0,reset(){viewed.clear()},
 hide(){sunset(false);View.showMove(false);View.free=false;wk=false;S.active=false;if(grp)grp.visible=false;gh.classList.remove('on');gt.classList.remove('show')},
 enter(){if(!grp){build();fixInst(grp)}heal(grp);View.reset();S.active=true;if(!mobile&&!grp.userData.sh){grp.userData.sh=1;grp.traverse(o=>{if(o.isMesh&&!o.isInstancedMesh&&!o.material.transparent){o.castShadow=o.receiveShadow=true}})}hid=scene.children.filter(o=>o.isPointLight);hid.forEach(l=>l.visible=false);vis(false);grp.visible=true;
  sunset(true);cam.position.set(0,3,28);look.set(0,3.4,-8);focus=null;ti=0;
  veil.style.transition='opacity 2.4s ease';veil.style.opacity=0;wk=false;View.showMove(true);say('يسار: مشي · يمين: نظر');setTimeout(()=>{if(S.active)say()},6000);gh.classList.add('on');
  gt.innerHTML='<b>'+C.title+'</b><i>'+C.sub+'</i>';gt.classList.remove('show');void gt.offsetWidth;gt.classList.add('show')},
 leave(){sunset(false);View.showMove(false);View.free=false;wk=false;S.active=false;if(grp)grp.visible=false;hid.forEach(l=>l.visible=true);vis(true);scene.fog.color.set(0x180816);scene.fog.near=45;scene.fog.far=150;gh.classList.remove('on');gt.classList.remove('show');UI.close()},
 tap(e){if(leaving)return;v2.set(e.clientX/innerWidth*2-1,-(e.clientY/innerHeight)*2+1);ray.setFromCamera(v2,cam);const q=ray.intersectObjects(hits)[0];if(!q)return;const id=q.object.userData.id;
  if(id==='gate'){if(viewed.size<3){say(C.lock);return}focus='gate';UI.puzzle(C.puzzle,finish,()=>{focus=null})}
  else{focus=id;viewed.add(id);say();UI.exhibit(C.exhibits.find(x=>x.id===id),()=>{focus=null})}},
 update(dt,t){sx+=(nx-sx)*.04;const f=focus&&ex[focus];const mv=View.move(),mvOn=Math.abs(mv.x)+Math.abs(mv.y)>.05;
  if(!wk&&mvOn&&!focus&&!leaving){wk=true;wp.x=clamp(cam.position.x,-13.4,13.4);wp.z=clamp(cam.position.z,-28.4,25.4);wy=cam.position.y;View.free=true}
  if(leaving){tp.set(0,3.6,-26);tl.set(0,3.8,-38)}else if(f){if(focus==='gate'){tp.set(0,3.6,-19);tl.set(0,3.8,-30)}else{tp.set(f.x*.5,2.6,f.z+8.5);tl.set(f.x,2.2,f.z)}}else{tp.set(sx*2.5,3.2,24);tl.set(-sx*1.2,3.8,-14)}
  ti+=dt;
  if(wk&&!focus&&!leaving){if(wasF){const cx=clamp(cam.position.x,-13.4,13.4),cz=clamp(cam.position.z,-28.4,25.4);if(!blocked(cx,cz)){wp.x=cx;wp.z=cz}wasF=false}walkStep(dt,mv,mvOn);cam.position.copy(tp);look.copy(tl);cam.lookAt(look);View.apply(cam,dt,false)}
  else{if(wk&&focus)wasF=true;cam.position.lerp(tp,1-Math.exp(-dt*(ti<5?.7:2)));look.lerp(tl,1-Math.exp(-dt*2.5));cam.lookAt(look);View.apply(cam,dt,!!focus||!!leaving)}
  gateGlow.material.opacity=viewed.size>2?.14+.05*Math.sin(t*2):.03;
  if(!reduce&&fire){const a=fire.geometry.attributes.position;for(let i=0;i<FN;i++){a.array[i*3]=fb[i*3]+Math.sin(t*.4+i)*.8;a.array[i*3+1]=fb[i*3+1]+Math.sin(t*.8+i*1.7)*.4}a.needsUpdate=true}
  bf.forEach(b=>{const p=b.userData.p,a=t*p[1]*.4+p[0];b.position.set(Math.cos(a)*p[4]+p[2]*2,1+p[3]+Math.sin(t*1.7+p[0])*.3,Math.sin(a)*p[5]-2);b.rotation.y=-a;const f=Math.sin(t*16+p[0])*.9;b.userData.W[0].rotation.z=-f;b.userData.W[1].rotation.z=f});
  if(leaving){leaving+=dt;gateGlow.material.opacity=.14+.45*Math.min(1,leaving/2);veil.style.transition='none';veil.style.background='#fff0fa';veil.style.opacity=Math.max(0,Math.min(1,(leaving-1.4)/1.8));if(leaving>3.3){leaving=0;Museum.hide();Details.enter()}}
  if(wt)wt.offset.x+=dt*.015;if(wt2)wt2.offset.y+=dt*.01;if(catG&&!reduce)catG.scale.y=.78*(1+.012*Math.sin(t*1.8));
  GU.value=t;fogS.forEach(f=>{f.position.x+=f.userData.v*dt;if(f.position.x>45)f.position.x=-45});
  if(!reduce&&pet){const a=pet.geometry.attributes.position;for(let i=0;i<PN;i++){let y=a.array[i*3+1]-dt*(.35+(i%4)*.08);if(y<0)y=11;a.array[i*3+1]=y;a.array[i*3]+=Math.sin(t+i)*dt*.3}a.needsUpdate=true}
  safeRender()}
})})();
