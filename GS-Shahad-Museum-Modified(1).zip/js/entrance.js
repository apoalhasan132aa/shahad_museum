const T=THREE, cv=document.getElementById('c');
const mobile=matchMedia('(max-width:820px)').matches||/Android|iPhone|iPad/i.test(navigator.userAgent);
const QL=(()=>{const q=new URLSearchParams(location.search).get('q');if(q!==null&&/^[012]$/.test(q))return +q;return mobile?(((navigator.deviceMemory||4)>=6&&(navigator.hardwareConcurrency||4)>=6)?1:0):2})();
const reduce=matchMedia('(prefers-reduced-motion:reduce)').matches;
const R=new T.WebGLRenderer({canvas:cv,antialias:!mobile,powerPreference:'high-performance'});
{const fb=document.createElement('div');fb.style.cssText='position:fixed;inset:0;z-index:99999;display:none;align-items:center;justify-content:center;background:#050308;color:#efeaf0;font:400 18px/2 "Cormorant Garamond",serif;text-align:center;padding:24px;direction:rtl';fb.innerHTML='<div>توقف الرسم ثلاثي الأبعاد مؤقتًا.<br><span style="font-size:13px;color:#8f8aa8">حدّثي الصفحة للمتابعة</span></div>';document.body.appendChild(fb);
cv.addEventListener('webglcontextlost',ev=>{ev.preventDefault();fb.style.display='flex'},false);
cv.addEventListener('webglcontextrestored',()=>{location.reload()},false);}
R.setPixelRatio(Math.min(devicePixelRatio||1,[1,1.5,2.1][QL]));
// Texture sharpness follows the device's real GPU anisotropy limit; quality 0 stays conservative.
const ANISO=Math.min(R.capabilities.getMaxAnisotropy(),QL===0?4:8);
R.outputEncoding=T.sRGBEncoding;R.shadowMap.enabled=!mobile;R.shadowMap.type=T.PCFSoftShadowMap;R.toneMapping=T.ACESFilmicToneMapping;R.toneMappingExposure=.92;
const scene=new T.Scene();
scene.fog=new T.Fog(0x101723,45,150);
const cam=new T.PerspectiveCamera(44,1,.1,800);

/* ---------- helpers ---------- */
function glowTex(){const c=document.createElement('canvas');c.width=c.height=128;const x=c.getContext('2d');
  const g=x.createRadialGradient(64,64,0,64,64,64);g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(.35,'rgba(255,255,255,.35)');g.addColorStop(1,'rgba(255,255,255,0)');
  x.fillStyle=g;x.fillRect(0,0,128,128);return new T.CanvasTexture(c)}
const GT=glowTex();
function rnd(s){return()=>{s=(s*16807)%2147483647;return(s-1)/2147483646}}
/* نتوءات حجرية إجرائية مشتركة: تعطي كل سطح مطفي relief واقعي */
const NT=(()=>{const c=document.createElement('canvas');c.width=c.height=256;const x=c.getContext('2d');
 x.fillStyle='#808080';x.fillRect(0,0,256,256);
 for(let i=0;i<26000;i++){const v=90+Math.random()*80|0;x.fillStyle=`rgba(${v},${v},${v},.5)`;x.fillRect(Math.random()*256|0,Math.random()*256|0,1+Math.random()*2|0,1)}
 for(let i=0;i<260;i++){const v=70+Math.random()*120|0;x.fillStyle=`rgba(${v},${v},${v},.25)`;x.beginPath();x.arc(Math.random()*256,Math.random()*256,2+Math.random()*14,0,6.283);x.fill()}
 const t=new T.CanvasTexture(c);t.wrapS=t.wrapT=T.RepeatWrapping;return t})();
const M=(c,r=.8,m=0,e)=>{const mt=new T.MeshStandardMaterial({color:c,roughness:r,metalness:m,emissive:e||0x000000});
 if(r>=.5&&m<.6){mt.bumpMap=NT;mt.bumpScale=.06}
 return mt};

/* ---------- sky ---------- */
const skyU={lo:{value:new T.Vector3(.34,.11,.24)},mid:{value:new T.Vector3(.10,.03,.12)},hi:{value:new T.Vector3(.02,.01,.04)}};const sky=new T.Mesh(new T.SphereGeometry(450,32,16),new T.ShaderMaterial({uniforms:skyU,side:T.BackSide,depthWrite:false,fog:false,
 vertexShader:'varying vec3 p;void main(){p=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
 fragmentShader:'uniform vec3 lo,mid,hi;varying vec3 p;void main(){float h=clamp(normalize(p).y,0.,1.);vec3 c=mix(lo,mid,smoothstep(0.,.22,h));c=mix(c,hi,smoothstep(.2,.8,h));gl_FragColor=vec4(c,1.);}'}));
scene.add(sky);
{const n=mobile?650:1400,pos=new Float32Array(n*3),col=new Float32Array(n*3),r=rnd(7);
 for(let i=0;i<n;i++){const u=r()*6.283,v=.03+r()*.97,s=Math.sqrt(1-v*v);pos.set([Math.cos(u)*s*400,v*400,Math.sin(u)*s*400],i*3);
  const k=.55+r()*.45,t=r();col.set([k,k*(.85+t*.1),k],i*3)}
 var stars=new T.Points(new T.BufferGeometry().setAttribute('position',new T.BufferAttribute(pos,3)).setAttribute('color',new T.BufferAttribute(col,3)),
  new T.PointsMaterial({size:mobile?1.7:1.4,sizeAttenuation:false,vertexColors:true,transparent:true,opacity:.9,fog:false,depthWrite:false}));
 scene.add(stars)}
const skyM=[],skyC=[];function spr(c,op,x,y,z,s){const m=new T.Sprite(new T.SpriteMaterial({map:GT,color:c,opacity:op,transparent:true,depthWrite:false,fog:false,blending:T.AdditiveBlending}));m.position.set(x,y,z);m.scale.set(s,s,1);scene.add(m);return m}
skyM.push(spr(0xfff0f6,1,-70,95,-220,46));skyM.push(spr(0xffffff,1,-70,95,-220,14));          // moon
skyM.push(spr(0xc07aff,.16,60,70,-250,260));skyM.push(spr(0xff8fb8,.1,-120,40,-250,220));       // faint nebula

/* ---------- lights ---------- */
scene.add(new T.HemisphereLight(0x223448,0x0c0e14,.55));
const moonL=new T.DirectionalLight(0xbfd0e8,.9);moonL.position.set(-30,40,40);scene.add(moonL);

const doorL=new T.PointLight(0xFFE3BD,1.5,26,2);doorL.position.set(0,3.6,8);scene.add(doorL);
const inL=new T.PointLight(0xFFE3BD,0,16,2);inL.position.set(0,3.6,1);scene.add(inL);
[-1,1].forEach(s=>{const l=new T.PointLight(0xFFD9A8,.85,20,2);l.position.set(s*12.5,2.2,7.4);scene.add(l)});

/* ---------- materials ---------- */
const stone=M(0xC9BBA6,.72,.04), pale=M(0xE3D7C3,.58,.06), pathM=M(0x343238,.62,.08), glass=M(0x1a1610,.15,.5,0xFFE3BD);glass.emissiveIntensity=.28;
const pinkM=new T.MeshBasicMaterial({color:0xff8fcf});
const doorM=M(0x382B26,.42,.55,0x1a0f08);doorM.emissiveIntensity=.1;
const insetM=M(0x241d2e,.3,.5,0xff6fb8);insetM.emissiveIntensity=.1;
const goldM=M(0x786B5B,.35,.8);
const corM=new T.MeshBasicMaterial({color:0x0c1220,side:T.BackSide});
const ringM=new T.MeshBasicMaterial({color:0xffb6e1,transparent:true,opacity:0});
const farM=new T.MeshBasicMaterial({color:0xfff0fa,transparent:true,opacity:0});
const inv=new T.MeshBasicMaterial({visible:false});

/* ---------- sign ---------- */
const sc=document.createElement('canvas');sc.width=2048;sc.height=380;
function drawSign(){const x=sc.getContext('2d');x.clearRect(0,0,2048,380);
 x.fillStyle='rgba(9,6,16,.92)';x.beginPath();x.roundRect?x.roundRect(10,10,2028,360,26):x.rect(10,10,2028,360);x.fill();
 const g=x.createLinearGradient(0,0,2048,0);g.addColorStop(0,'#ff8fcf');g.addColorStop(1,'#a68bff');x.strokeStyle=g;x.lineWidth=6;x.stroke();
 x.textAlign='center';x.shadowColor='#ff8fcf';x.shadowBlur=30;x.fillStyle='#fff4fb';x.direction='rtl';
 x.font='700 170px Amiri, serif';x.fillText(CONTENT.ar,1024,178);
 x.direction='ltr';x.shadowBlur=14;x.font='500 62px "Cormorant Garamond", serif';if('letterSpacing' in x)x.letterSpacing='18px';x.fillText(CONTENT.en,1024,268);
 x.shadowBlur=0;x.fillStyle='#cdb6ff';x.font='300 30px "Cormorant Garamond", serif';if('letterSpacing' in x)x.letterSpacing='10px';x.fillText(CONTENT.tag,1024,334)}
drawSign();const signTex=new T.CanvasTexture(sc);signTex.anisotropy=ANISO;
Promise.all([document.fonts.load('700 100px Amiri','متحف'),document.fonts.load('500 60px "Cormorant Garamond"')]).then(()=>{drawSign();signTex.needsUpdate=true}).catch(()=>{});
const signM=new T.MeshBasicMaterial({map:signTex,transparent:true,toneMapped:false});

/* ---------- building ---------- */
const roofM=M(0x2e2c33,.55,.4),leafG=M(0x1d3b2c,1),goldM2=M(0x8a7c68,.35,.8),domeM=new T.MeshStandardMaterial({color:0x3a3630,roughness:.4,metalness:.7,emissive:0x120e0a,emissiveIntensity:.5});
const urnG=new T.LatheGeometry([[0,0],[.25,0],[.3,.08],[.2,.3],[.28,.5],[.33,.75],[.25,.85],[.28,.92],[0,.92]].map(a=>new T.Vector2(a[0],a[1])),14);
let colM;
const aoM=(()=>{const c=document.createElement('canvas');c.width=c.height=64;const x=c.getContext('2d'),g=x.createRadialGradient(32,32,0,32,32,32);g.addColorStop(0,'rgba(0,0,0,.8)');g.addColorStop(1,'rgba(0,0,0,0)');x.fillStyle=g;x.fillRect(0,0,64,64);return new T.MeshBasicMaterial({map:new T.CanvasTexture(c),transparent:true,depthWrite:false,opacity:.75,polygonOffset:true,polygonOffsetFactor:-2})})();
const waterM=new T.MeshStandardMaterial({color:0x1d4a68,roughness:.03,metalness:.9,emissive:0x0a2030}),bowlM=pale.clone(),fanM=new T.MeshBasicMaterial({color:0xffb6e1,transparent:true,opacity:.3}),carpM=new T.MeshBasicMaterial({color:0x4a1236}),
 statG=new T.LatheGeometry([[0,0],[.5,0],[.42,.5],[.3,1],[.34,1.3],[.2,1.45],[.1,1.52],[0,1.52]].map(a=>new T.Vector2(a[0],a[1])),16);bowlM.side=T.DoubleSide;
const FJ=mobile?60:120,fph=new Float32Array(FJ*2);for(let i=0;i<fph.length;i++)fph[i]=Math.random();
const fnt=new T.Points(new T.BufferGeometry().setAttribute('position',new T.BufferAttribute(new Float32Array(FJ*3),3)),new T.PointsMaterial({map:GT,size:.12,color:0xbfe3ff,transparent:true,opacity:.85,depthWrite:false,blending:T.AdditiveBlending}));fnt.frustumCulled=false;scene.add(fnt);
function fountain(t){const A=fnt.geometry.attributes.position,a=A.array;for(let i=0;i<FJ;i++){const u=(t*.7+fph[i*2])%1,an=fph[i*2+1]*6.283,rr=u*1.9;a[i*3]=Math.cos(an)*rr;a[i*3+1]=3.3+2.4*u-3.6*u*u;a[i*3+2]=19+Math.sin(an)*rr}A.needsUpdate=true}fountain(0);
for(let i=0;i<8;i++){const c=new T.Sprite(new T.SpriteMaterial({map:GT,color:i%3?0x16203a:0x1e2a45,opacity:.45,transparent:true,depthWrite:false,fog:false}));c.position.set(-160+i*45,55+(i%3)*18,-200-(i%2)*30);c.scale.set(110,22,1);scene.add(c);skyC.push(c)}
{const tx=(w,h,fn,rep,s)=>{const c=document.createElement('canvas');c.width=w;c.height=h;fn(c.getContext('2d'),w,h);const t=new T.CanvasTexture(c);t.wrapS=t.wrapT=T.RepeatWrapping;if(rep)t.repeat.set(rep[0],rep[1]);t.anisotropy=ANISO;if(s)t.encoding=T.sRGBEncoding;return t};
 let k=3;const rn=()=>(k=(k*16807)%2147483647)/2147483647;
 const wall=tx(512,512,(x,w,h)=>{x.fillStyle='#a89a82';x.fillRect(0,0,w,h);for(let j=0;j<8;j++){let a=-(j%2)*50;while(a<w){const bw=90+rn()*70;x.fillStyle=`hsl(37,17%,${64+rn()*9}%)`;x.fillRect(a+3,j*64+3,bw-6,58);a+=bw}}
  for(let i=0;i<6000;i++){x.fillStyle=rn()>.5?'rgba(255,255,255,.04)':'rgba(0,0,0,.09)';x.fillRect(rn()*w,rn()*h,2,2+rn()*3)}},null,true);
 stone.map=wall;stone.bumpMap=wall;stone.bumpScale=1.4;stone.color.set(0xC9BBA6);
 const fl=tx(256,16,(x,w,h)=>{x.fillStyle='#888';x.fillRect(0,0,w,h);for(let i=0;i<32;i++){x.fillStyle='#222';x.fillRect(i*8+1,0,3,h)}},null,false);
 colM=new T.MeshStandardMaterial({color:0xE3D7C3,roughness:.52,metalness:.05,bumpMap:fl,bumpScale:1.6})}
function mergeStatic(g){const by=new Map();
 g.children.slice().forEach(o=>{if(!o.isMesh||Array.isArray(o.material))return;if(!by.has(o.material))by.set(o.material,[]);by.get(o.material).push(o)});
 by.forEach((arr,mat)=>{if(arr.length<2)return;const P=[],N=[],U=[],I=[];let off=0;
  arr.forEach(o=>{o.updateMatrix();const ge=o.geometry.clone().applyMatrix4(o.matrix),p=ge.attributes.position,n=ge.attributes.normal,u=ge.attributes.uv;
   for(let i=0;i<p.count;i++){P.push(p.getX(i),p.getY(i),p.getZ(i));N.push(n.getX(i),n.getY(i),n.getZ(i));U.push(u?u.getX(i):0,u?u.getY(i):0)}
   if(ge.index)for(let i=0;i<ge.index.count;i++)I.push(ge.index.getX(i)+off);else for(let i=0;i<p.count;i++)I.push(i+off);off+=p.count;g.remove(o);o.geometry.dispose()});
  const G=new T.BufferGeometry();G.setAttribute('position',new T.Float32BufferAttribute(P,3));G.setAttribute('normal',new T.Float32BufferAttribute(N,3));G.setAttribute('uv',new T.Float32BufferAttribute(U,2));G.setIndex(I);g.add(new T.Mesh(G,mat))})}
function make(mir){
 const g=new T.Group(),o={doors:[]};
 const bx=(w,h,d,m,x,y,z)=>{const G=new T.BoxGeometry(w,h,d),uv=G.attributes.uv;for(let i=0;i<uv.count;i++)uv.setXY(i,uv.getX(i)*Math.max(w,d)/4,uv.getY(i)*h/4);const k=new T.Mesh(G,m);k.position.set(x,y,z);g.add(k);return k};
 // body + front wall with opening
 bx(13,9.5,7,[stone,stone,stone,stone,inv,stone],0,4.75,-1.5);
 bx(4.8,9.5,1,stone,-4.1,4.75,2.5);bx(4.8,9.5,1,stone,4.1,4.75,2.5);bx(3.4,3.3,1,stone,0,7.85,2.5);
 bx(15,1,6,pathM,0,.5,3.2);                                   // podium
 bx(3.4,5.2,6,corM,0,3.6,-1);bx(3.4,5.2,.05,farM,0,3.6,-3.95);
 for(let i=1;i<=4;i++){const z=2-i*1.1,t=.07;[[0,2.6+.0,3.4,t],[0,-2.6,3.4,t]].forEach(a=>{});
  bx(3.4,.07,.07,ringM,0,6.17,z);bx(3.4,.07,.07,ringM,0,1.03,z);bx(.07,5.2,.07,ringM,-1.67,3.6,z);bx(.07,5.2,.07,ringM,1.67,3.6,z)}
 // wings
 [-1,1].forEach(s=>{
  bx(6,6.5,6,stone,s*9.5,3.25,0);bx(6.5,.4,.9,pale,s*9.5,6.7,3.2);bx(6.4,.5,.6,pale,s*9.5,.25,3.3);
  [8,9.5,11].forEach(a=>{const x=s*a;bx(1.3,3.1,.1,pale,x,3.7,3.0);const w=new T.Mesh(new T.PlaneGeometry(1,2.8),glass);w.position.set(x,3.7,3.06);g.add(w);bx(1.5,.15,.35,pale,x,2.1,3.15)})});
 bx(13.6,.5,1,pale,0,9.75,2.8);
 // portico
 for(let i=0;i<6;i++){const x=-5.5+i*2.2;
  const c=new T.Mesh(new T.CylinderGeometry(.36,.42,5.8,28),colM);c.position.set(x,3.9,5.4);g.add(c);
  // Bases and layered Corinthian-inspired capitals give the portico more scale.
  bx(1.08,.22,1.08,pale,x,1.03,5.4);
  const baseRing=new T.Mesh(new T.CylinderGeometry(.49,.49,.12,28),goldM2);baseRing.position.set(x,1.18,5.4);g.add(baseRing);
  const neck=new T.Mesh(new T.CylinderGeometry(.48,.4,.16,28),pale);neck.position.set(x,6.82,5.4);g.add(neck);
  const cap=new T.Mesh(new T.CylinderGeometry(.62,.43,.28,28),pale);cap.position.set(x,7.03,5.4);g.add(cap);
  bx(1.18,.12,1.18,pale,x,7.22,5.4);
  const capTrim=new T.Mesh(new T.TorusGeometry(.47,.035,6,24),goldM2);capTrim.rotation.x=Math.PI/2;capTrim.position.set(x,6.9,5.4);g.add(capTrim);
  // Fine vertical fluting catches the moonlight without adding heavy geometry.
  for(let f=0;f<8;f++){const a=f*Math.PI/4;const rib=new T.Mesh(new T.CylinderGeometry(.018,.018,5.25,5),pale);rib.position.set(x+Math.sin(a)*.365,3.88,5.4+Math.cos(a)*.365);g.add(rib)} }
 bx(13.4,1.8,1.9,stone,0,7.7,5.4);bx(13.8,.2,2.1,pale,0,8.7,5.4);
 const sh=new T.Shape();sh.moveTo(-7,0);sh.lineTo(7,0);sh.lineTo(0,2.2);sh.lineTo(-7,0);
 const ped=new T.Mesh(new T.ExtrudeGeometry(sh,{depth:1.9,bevelEnabled:false}),stone);ped.position.set(0,8.8,4.45);g.add(ped);
 const ty=new T.Mesh(new T.ShapeGeometry(sh),M(0x0f0b18,.6,.2));ty.scale.set(.8,.7,1);ty.position.set(0,8.95,6.36);g.add(ty);
 [-1,1].forEach(s=>{const e=bx(7.4,.07,.07,pinkM,s*3.5,9.9,6.4);e.rotation.z=-s*.305});
 const sign=new T.Mesh(new T.PlaneGeometry(8.2,1.52),signM);sign.position.set(0,7.7,6.37);g.add(sign);
 // door frame + doors
 bx(.3,5.4,.5,pale,-1.85,3.7,3);bx(.3,5.4,.5,pale,1.85,3.7,3);bx(4,.4,.5,pale,0,6.4,3);
 [-1,1].forEach(s=>{const p=new T.Group();p.position.set(s*1.7,1,2.9);g.add(p);
  const d=new T.Mesh(new T.BoxGeometry(1.7,5.2,.18),doorM);d.position.set(-s*.85,2.6,0);p.add(d);
  [1.5,3.9].forEach(y=>{const i=new T.Mesh(new T.BoxGeometry(1.2,2,.06),insetM);i.position.set(-s*.85,y,.1);p.add(i)});
  const h=new T.Mesh(new T.SphereGeometry(.1,12,8),goldM);h.position.set(-s*1.5,2.6,.2);p.add(h);o.doors.push({p,s,d})});
 // Grand, broad ceremonial staircase. Each tread has a restrained rose-gold edge.
 for(let i=0;i<6;i++){const h=(i+1)*.22,z=10.15-i*.82,w=10.6-i*.12;
  bx(w,h,.86,pale,0,h/2,z);
  bx(w-.18,.035,.055,goldM2,0,h+.008,z+.405);
  bx(w-.38,.018,.04,pinkM,0,h+.026,z+.405);
 }
 // Low balustrades frame the stairs and lead the eye toward the doors.
 [-1,1].forEach(side=>{
  bx(.2,.34,5.3,pale,side*5.65,.42,8.1);
  const rail=new T.Mesh(new T.CylinderGeometry(.07,.07,5.1,12),goldM2);rail.rotation.x=Math.PI/2;rail.position.set(side*5.65,.78,8.0);g.add(rail);
  for(let j=0;j<7;j++){const z=5.9+j*.68;const b=new T.Mesh(new T.CylinderGeometry(.045,.065,.58,8),pale);b.position.set(side*5.65,.55,z);g.add(b)}
 });
 bx(8.8,.04,31,pathM,0,.02,25);
 [-1,1].forEach(s=>{bx(.08,.035,31,goldM2,s*4.5,.045,25);bx(.035,.035,31,pinkM,s*4.32,.047,25)});
 // lamps
 [14,22,30].forEach(z=>[-1,1].forEach(s=>{
  const pl=new T.Mesh(new T.CylinderGeometry(.06,.09,3,8),stone);pl.position.set(s*5.6,1.5,z);g.add(pl);
  const b=new T.Mesh(new T.SphereGeometry(.2,12,8),new T.MeshBasicMaterial({color:0xffd7f0}));b.position.set(s*5.6,3.1,z);g.add(b);
  if(!mir){const q=new T.Sprite(new T.SpriteMaterial({map:GT,color:0xff8fcf,opacity:.7,transparent:true,depthWrite:false,blending:T.AdditiveBlending}));q.position.copy(b.position);q.scale.set(2.6,2.6,1);g.add(q)}}));
 // trees, bushes, stones
 const r=rnd(11),tm=M(0x0f1d1d,1),tr=M(0x1a1416,1);
 for(let i=0;i<20;i++){const s=i%2?1:-1,x=s*(15+r()*26),z=-14+r()*50,k=.8+r()*.9;
  const t=new T.Group();t.position.set(x,0,z);t.scale.setScalar(k);
  const tk=new T.Mesh(new T.CylinderGeometry(.18,.25,2,6),tr);tk.position.y=1;t.add(tk);
  [[2.2,3,2.4],[1.7,5,2.4],[1.1,6.8,2]].forEach(a=>{const c=new T.Mesh(new T.ConeGeometry(a[0],a[2],8),tm);c.position.y=a[1];t.add(c)});g.add(t)}
 [-1,1].forEach(s=>[[14.2,7],[13,11]].forEach(a=>{const b=new T.Mesh(new T.SphereGeometry(1.1,12,8),tm);b.position.set(s*a[0],.55,a[1]);b.scale.y=.7;g.add(b)}));
 for(let i=0;i<8;i++){const s=i%2?1:-1,k=new T.Mesh(new T.DodecahedronGeometry(.4+r()*.5),stone);k.position.set(s*(7+r()*8),.2,10+r()*18);g.add(k)}
 // ---- extra architectural detail ----
 bx(15.4,.3,6.4,pale,0,.15,3.2);bx(13.2,.3,7.2,roofM,0,9.65,-1.5);bx(3.6,.08,.55,goldM2,0,6.62,3);
 for(let i=0;i<41;i++)bx(.17,.17,.16,pale,-6.6+i*.33,8.62,6.38);
 const urn=(x,y,z,s)=>{const u=new T.Mesh(urnG,pale);u.position.set(x,y,z);u.scale.setScalar(s);g.add(u)};
 [-1,1].forEach(s=>{
  bx(6.2,.3,6.2,roofM,s*9.5,6.65,0);bx(.45,6.3,.3,pale,s*6.85,3.15,3.12);bx(.45,6.3,.3,pale,s*12.2,3.15,3.12);
  [8,9.5,11].forEach(a=>{const x=s*a,ar=new T.Mesh(new T.TorusGeometry(.55,.07,6,16,Math.PI),pale);ar.position.set(x,5.1,3.1);g.add(ar);bx(.22,.3,.18,pale,x,5.7,3.1);bx(1,.05,.04,pale,x,3.7,3.1);bx(.05,2.8,.04,pale,x,3.7,3.1)});
  bx(3.2,5.6,.12,pale,s*4.1,4.2,3.04);const n=new T.Mesh(new T.PlaneGeometry(2.8,5.2),glass);n.position.set(s*4.1,4.2,3.11);g.add(n);
  for(let i=0;i<5;i++)bx(.5,(i+1)*.2+.4,.7,pale,s*4.45,((i+1)*.2+.4)/2,9-i*.7);
  urn(s*4.9,0,10.4,1.6);const bs=new T.Mesh(new T.SphereGeometry(.65,12,8),leafG);bs.scale.y=.8;bs.position.set(s*4.9,1.75,10.4);g.add(bs);
  urn(s*6.9,8.9,6.3,1.2);
  const lb=new T.Mesh(new T.BoxGeometry(.22,.4,.22),new T.MeshBasicMaterial({color:0xffe2f1}));lb.position.set(s*2.35,4.3,3.25);g.add(lb);
  if(!mir){const q=new T.Sprite(new T.SpriteMaterial({map:GT,color:0xff9fd2,opacity:.8,transparent:true,depthWrite:false,blending:T.AdditiveBlending}));q.position.copy(lb.position);q.scale.set(2.4,2.4,1);g.add(q)}});
 urn(0,11,6.3,1.3);
 const dr=new T.Mesh(new T.CylinderGeometry(3.4,3.5,1.4,32),stone);dr.position.set(0,10.45,-1.5);g.add(dr);
 const rim=new T.Mesh(new T.TorusGeometry(3.45,.08,8,48),pinkM);rim.rotation.x=Math.PI/2;rim.position.set(0,11.15,-1.5);g.add(rim);
 const dm=new T.Mesh(new T.SphereGeometry(3.3,32,16,0,6.2832,0,1.5708),domeM);dm.position.set(0,11.15,-1.5);g.add(dm);
 for(let i=0;i<8;i++){const rb=new T.Mesh(new T.TorusGeometry(3.32,.04,4,24,Math.PI),goldM2);rb.rotation.y=i*Math.PI/8;rb.position.set(0,11.15,-1.5);g.add(rb)}
 for(let i=0;i<12;i++){const a=i/12*6.283,w=new T.Mesh(new T.PlaneGeometry(.5,.8),glass);w.position.set(Math.sin(a)*3.52,10.5,-1.5+Math.cos(a)*3.52);w.rotation.y=a;g.add(w)}
 const sp=new T.Mesh(new T.ConeGeometry(.12,1.6,8),goldM2);sp.position.set(0,15.25,-1.5);g.add(sp);
 { // ---- final detail pass ----
  const f=new T.Group();f.position.set(0,0,19);g.add(f);const m=(geo,mat,y)=>{const k=new T.Mesh(geo,mat);k.position.y=y;f.add(k);return k};
  m(new T.CylinderGeometry(2.5,2.6,.5,40),pale,.25);m(new T.CylinderGeometry(2.3,2.3,.05,40),waterM,.46);m(new T.CylinderGeometry(.35,.5,1.5,16),pale,1);
  m(new T.SphereGeometry(1.2,28,10,0,6.2832,1.5708,1.5708),bowlM,2.2);m(new T.CylinderGeometry(1.0,1.0,.04,28),waterM,2.1);m(new T.CylinderGeometry(.12,.15,.9,10),pale,2.65);
  m(new T.SphereGeometry(.6,20,8,0,6.2832,1.5708,1.5708),bowlM,3.2);m(new T.SphereGeometry(.1,10,8),goldM2,3.25);
  [-1,1].forEach(s=>{
   bx(.9,1,.9,pale,s*6.9,1.5,5.4);const st=new T.Mesh(statG,pale);st.position.set(s*6.9,2,5.4);st.rotation.y=-s*.4;g.add(st);const hd=new T.Mesh(new T.SphereGeometry(.17,12,10),pale);hd.position.set(s*6.9,3.62,5.4);g.add(hd);
   for(let i=0;i<11;i++){const b=new T.Mesh(new T.CylinderGeometry(.06,.08,.5,8),pale);b.position.set(s*(6.9+i*.52),7.1,3.35);g.add(b)}
   bx(5.4,.1,.22,pale,s*9.5,7.4,3.35);bx(5.4,.1,.22,pale,s*9.5,6.85,3.35);
   for(let i=0;i<4;i++){bx(.2,1.3,.1,pale,s*(4.55+i*.55),7.7,6.4);if(i<3){const q=new T.Mesh(new T.CylinderGeometry(.16,.16,.06,12),goldM2);q.rotation.x=Math.PI/2;q.position.set(s*(4.82+i*.55),7.7,6.4);g.add(q)}}
   bx(.2,5.2,.25,doorM,s*1.6,3.6,.9);});
  for(let i=1;i<=4;i++)[-1,1].forEach(s=>bx(.2,5.2,.25,doorM,s*1.6,3.6,2-i*1.1));
  const cp=new T.Mesh(new T.PlaneGeometry(1.5,6),carpM);cp.rotation.x=-Math.PI/2;cp.position.set(0,1.06,-1);g.add(cp);
  o.doors.forEach(({p,s})=>{for(let j=0;j<6;j++)for(let k=0;k<2;k++){const t=new T.Mesh(new T.SphereGeometry(.045,8,6),goldM);t.position.set(-s*(.35+k*.95),.7+j*.75,.11);p.add(t)}
   const rg=new T.Mesh(new T.TorusGeometry(.1,.02,6,16),goldM);rg.position.set(-s*1.45,2.6,.23);p.add(rg)});
  const fan=new T.Mesh(new T.CircleGeometry(1.7,28,0,Math.PI),fanM);fan.position.set(0,6.2,3.03);g.add(fan);
  for(let i=1;i<7;i++){const a=i/7*Math.PI,k=bx(.035,1.7,.02,doorM,Math.cos(a)*.85,6.2+Math.sin(a)*.85,3.05);k.rotation.z=a-Math.PI/2}}
 {const ab=(x,y,z,s)=>{const m=new T.Mesh(new T.PlaneGeometry(s,s),aoM);m.rotation.x=-Math.PI/2;m.position.set(x,y,z);g.add(m)};
  for(let i=0;i<6;i++)ab(-5.5+i*2.2,1.02,5.4,2.4);[-1,1].forEach(s=>{ab(s*6.9,1.02,5.4,2.2);ab(s*4.9,.05,10.4,2.8);ab(s*4.45,.05,7.6,2);[14,22,30].forEach(z=>ab(s*5.6,.05,z,1.8))});ab(0,.05,19,8.5)}
 // Rose planters near the approach: a small romantic accent, not a second garden.
 const planterM=M(0x27202e,.48,.28),leafM=M(0x294c39,.9,.02),roseM=new T.MeshStandardMaterial({color:0xe879b6,roughness:.48,metalness:.02,emissive:0x351027,emissiveIntensity:.22}),roseLight=new T.MeshBasicMaterial({color:0xffb8df});
 [-1,1].forEach(side=>{
  const px=side*7.1,pz=13.2;
  const box=new T.Mesh(new T.BoxGeometry(2.7,.72,2.25),planterM);box.position.set(px,.38,pz);g.add(box);
  const lip=new T.Mesh(new T.BoxGeometry(2.86,.12,2.4),goldM2);lip.position.set(px,.78,pz);g.add(lip);
  for(let j=0;j<7;j++){
   const x=px-1+j*.32,z=pz+(j%2?.32:-.32),height=.45+(j%3)*.13;
   const stem=new T.Mesh(new T.CylinderGeometry(.025,.035,height,6),leafM);stem.position.set(x,1.02+height/2,z);g.add(stem);
   const leaf=new T.Mesh(new T.SphereGeometry(.14,8,6),leafM);leaf.scale.set(1.6,.55,.7);leaf.position.set(x+.13,1.1+height*.4,z);leaf.rotation.z=.4;g.add(leaf);
   const bloom=new T.Group();bloom.position.set(x,1.05+height,z);
   const core=new T.Mesh(new T.SphereGeometry(.105,10,8),roseM);bloom.add(core);
   for(let pet=0;pet<5;pet++){const a=pet*Math.PI*2/5;const q=new T.Mesh(new T.SphereGeometry(.105,8,6),roseM);q.scale.set(1,.7,.75);q.position.set(Math.cos(a)*.105,.025,Math.sin(a)*.105);bloom.add(q)}
   const center=new T.Mesh(new T.SphereGeometry(.035,8,6),roseLight);center.position.y=.06;bloom.add(center);g.add(bloom);
  }
  const lantern=new T.Mesh(new T.BoxGeometry(.3,1.2,.3),stone);lantern.position.set(side*5.9,.6,11.3);g.add(lantern);
  const lamp=new T.Mesh(new T.SphereGeometry(.18,12,8),new T.MeshBasicMaterial({color:0xffd8ee}));lamp.position.set(side*5.9,1.3,11.3);g.add(lamp);
  if(!mir){const halo=new T.Sprite(new T.SpriteMaterial({map:GT,color:0xff8fcf,opacity:.38,transparent:true,depthWrite:false,blending:T.AdditiveBlending}));halo.position.copy(lamp.position);halo.scale.set(2.2,2.2,1);g.add(halo)}
 });
 // Decorative medallion and restrained illuminated lines in the pediment.
 const med=new T.Mesh(new T.CircleGeometry(.52,32),new T.MeshStandardMaterial({color:0x21172b,metalness:.55,roughness:.3,emissive:0x4c1e48,emissiveIntensity:.28}));med.position.set(0,9.85,6.38);g.add(med);
 const medRing=new T.Mesh(new T.TorusGeometry(.57,.035,8,36),goldM2);medRing.position.set(0,9.85,6.4);g.add(medRing);
 const crest=new T.Mesh(new T.OctahedronGeometry(.22,1),roseLight);crest.position.set(0,9.85,6.43);g.add(crest);
 mergeStatic(g);
 if(mir){g.scale.y=-1}
 o.g=g;return o}
const B=make(false),Bm=make(true);scene.add(B.g,Bm.g);
const ground=new T.Mesh(new T.PlaneGeometry(600,600),new T.MeshStandardMaterial({color:0x191a1e,roughness:.32,metalness:.12,transparent:true,opacity:.66}));
ground.rotation.x=-Math.PI/2;scene.add(ground);
{const c=document.createElement('canvas');c.width=c.height=512;const x=c.getContext('2d');x.fillStyle='#050408';x.fillRect(0,0,512,512);let k=9;const rn=()=>(k=(k*16807)%2147483647)/2147483647;
 for(let j=0;j<16;j++)for(let i=0;i<16;i++){x.fillStyle=`hsl(265,8%,${11+rn()*9}%)`;x.beginPath();x.ellipse(i*32+16+(j%2)*8,j*32+16,13+rn()*3,12+rn()*3,rn(),0,6.283);x.fill()}
 const t=new T.CanvasTexture(c);t.wrapS=t.wrapT=T.RepeatWrapping;t.repeat.set(60,60);t.anisotropy=ANISO;t.encoding=T.sRGBEncoding;const gm=ground.material;gm.map=t;gm.bumpMap=t;gm.bumpScale=1.5;gm.color.set(0xffffff);gm.roughness=.4}
const doorGlow=spr(0xFFE3BD,0,0,3.6,3.4,10);doorGlow.material.fog=true;
// hit pad for the door
const hit=new T.Mesh(new T.PlaneGeometry(7,7.5),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));hit.position.set(0,3.8,6.6);scene.add(hit);

/* ---------- atmosphere ---------- */
const fogS=[];{const r=rnd(5);for(let i=0;i<(mobile?10:18);i++){const s=new T.Sprite(new T.SpriteMaterial({map:GT,color:0x7a68ac,opacity:.11,transparent:true,depthWrite:false,fog:false}));
 const k=16+r()*14;s.scale.set(k,k*.38,1);s.position.set(-40+r()*80,1.3+r()*2,-8+r()*42);s.userData.v=.15+r()*.3;scene.add(s);fogS.push(s)}}
const DN=mobile?90:200,dp=new Float32Array(DN*3),dr=rnd(3);
for(let i=0;i<DN;i++)dp.set([-30+dr()*60,dr()*14,-6+dr()*40],i*3);
const dust=new T.Points(new T.BufferGeometry().setAttribute('position',new T.BufferAttribute(dp,3)),new T.PointsMaterial({map:GT,size:.35,color:0xffc2e8,transparent:true,opacity:.55,depthWrite:false,blending:T.AdditiveBlending}));
scene.add(dust);

/* ---------- camera + resize ---------- */
const P0=new T.Vector3(8,3.4,29),L0=new T.Vector3(0,4.7,0),P1=new T.Vector3(0,3,-1),L1=new T.Vector3(0,3,-9);
function resize(){const w=innerWidth,h=innerHeight,a=w/h;R.setSize(w,h,false);cam.aspect=a;
 // Keep the full facade legible on tall phones instead of making the building tiny with an extreme FOV.
 cam.fov=a>=1.2?44:(a<.58?70:(a<.82?64:56));
 P0.z=a<.58?40:(a<.82?36:(a<1?33:29));L0.y=a<.58?5.7:(a<1?5.2:4.7);cam.updateProjectionMatrix()}
addEventListener('resize',resize);resize();

/* ---------- input ---------- */
let nx=0,ny=0,sx=0,sy=0;
const ray=new T.Raycaster(),v2=new T.Vector2();
function pick(e){v2.set(e.clientX/innerWidth*2-1,-(e.clientY/innerHeight)*2+1);ray.setFromCamera(v2,cam);
 return ray.intersectObjects([hit,...B.doors.map(d=>d.d)]).length>0}
cv.addEventListener('pointermove',e=>{nx=e.clientX/innerWidth*2-1;ny=e.clientY/innerHeight*2-1;if(!mobile&&!seq)cv.style.cursor=pick(e)?'pointer':'default'});
cv.addEventListener('click',e=>{if(window.Final&&Final.active)Final.tap(e);else if(window.Sky&&Sky.active)Sky.tap(e);else if(window.Empty&&Empty.active)Empty.tap(e);else if(window.Locked&&Locked.active)Locked.tap(e);else if(window.Mirror&&Mirror.active)Mirror.tap(e);else if(window.Places&&Places.active)Places.tap(e);else if(window.Trends&&Trends.active)Trends.tap(e);else if(window.Calls&&Calls.active)Calls.tap(e);else if(window.Details&&Details.active)Details.tap(e);else if(window.Museum&&Museum.active)Museum.tap(e);else if(pick(e))enter()});
const enterBtn=document.getElementById('enter');enterBtn.addEventListener('click',enter);

/* ---------- entrance sequence ---------- */
const veil=document.getElementById('veil'),nextEl=document.getElementById('next');
document.getElementById('nt').textContent=CONTENT.next;document.getElementById('ns').textContent=CONTENT.nextSub;
const rp=document.getElementById('rp');rp.textContent=CONTENT.replay;
window.GS={goToSection2(){try{Museum.enter()}catch(err){console.error('[GS] تعذر تحميل الحديقة:',err);veil.style.transition='opacity .6s';veil.style.opacity=0;document.getElementById('nt').textContent='تعذر تحميل الحديقة';document.getElementById('ns').textContent='جرّبي إعادة المشهد';if(window.GSerr)GSerr(err&&err.stack||err);document.getElementById('next').classList.add('on')}}};
let seq=null,intro=0,shown=false;
const cl=(x)=>Math.min(1,Math.max(0,x)),sm=(x)=>x*x*(3-2*x),pr=(t,a,b)=>cl((t-a)/(b-a));
function enter(){if(seq)return;seq={t:0};enterBtn.classList.add('gone');cv.style.cursor='default';
 veil.style.transition='none';veil.style.background='#fff0fa';veil.style.opacity=0}
rp.addEventListener('click',()=>{if(window.Final)Final.leave();if(window.Sky)Sky.leave();if(window.Empty)Empty.leave();if(window.Locked)Locked.leave();if(window.Mirror)Mirror.leave();Places.leave();Trends.leave();Calls.leave();Details.leave();Museum.leave();if(window.Final)Final.reset();if(window.Sky)Sky.reset();if(window.Empty)Empty.reset();if(window.Locked)Locked.reset();if(window.Mirror)Mirror.reset();Places.reset();Trends.reset();Calls.reset();Details.reset();Museum.reset();nextEl.classList.remove('on');seq=null;shown=false;intro=1.5;
 B.doors.concat(Bm.doors).forEach(d=>d.p.rotation.y=0);corM.color.set(0x0c1220);ringM.opacity=0;farM.opacity=0;inL.intensity=0;doorGlow.material.opacity=0;
 veil.style.background='#07050d';veil.style.opacity=0;enterBtn.classList.remove('gone')});
function seqUpdate(dt){const s=seq;s.t+=dt*(reduce?1.7:1);const t=s.t;
 const gl=sm(pr(t,0,1.2)),inn=sm(pr(t,1.2,2.4)),op=sm(pr(t,2,4.4)),dol=sm(sm(pr(t,3.2,7.2))),vl=pr(t,6.4,7.6);
 doorM.emissiveIntensity=insetM.emissiveIntensity=.1+gl*.8;doorL.intensity=1.3+gl*2+inn*1.5;
 corM.color.setRGB(.05+inn*.62,.07+inn*.5,.12+inn*.34);ringM.opacity=inn*.7;farM.opacity=inn*.7;inL.intensity=inn*1.3;
 doorGlow.material.opacity=inn*.45*(1-dol*.7);
 [B,Bm].forEach(b=>b.doors.forEach(d=>d.p.rotation.y=d.s*op*1.5));
 veil.style.opacity=vl;
 s.dol=dol;if(t>8&&!shown){shown=true;GS.goToSection2()}}

/* ---------- loop ---------- */
let last=performance.now(),time=0;
function tick(now){requestAnimationFrame(tick);const dt=Math.min((now-last)/1000,.05);last=now;time+=dt;
 if(window.Final&&Final.active){try{Final.update(dt,time)}catch(err){if(window.GSerr)GSerr('Final.update: '+(err&&err.message));try{if(window.Museum&&Museum.heal)Museum.heal();R.render(scene,cam)}catch(e3){}}return}
 if(window.Sky&&Sky.active){try{Sky.update(dt,time)}catch(err){if(window.GSerr)GSerr('Sky.update: '+(err&&err.message));try{if(window.Museum&&Museum.heal)Museum.heal();R.render(scene,cam)}catch(e3){}}return}
 if(window.Empty&&Empty.active){try{Empty.update(dt,time)}catch(err){if(window.GSerr)GSerr('Empty.update: '+(err&&err.message));try{if(window.Museum&&Museum.heal)Museum.heal();R.render(scene,cam)}catch(e3){}}return}
 if(window.Locked&&Locked.active){try{Locked.update(dt,time)}catch(err){if(window.GSerr)GSerr('Locked.update: '+(err&&err.message));try{if(window.Museum&&Museum.heal)Museum.heal();R.render(scene,cam)}catch(e3){}}return}
 if(window.Mirror&&Mirror.active){try{Mirror.update(dt,time)}catch(err){if(window.GSerr)GSerr('Mirror.update: '+(err&&err.message));try{if(window.Museum&&Museum.heal)Museum.heal();R.render(scene,cam)}catch(e3){}}return}
 if(window.Places&&Places.active){try{Places.update(dt,time)}catch(err){if(window.GSerr)GSerr('Places.update: '+(err&&err.message));try{if(window.Museum&&Museum.heal)Museum.heal();R.render(scene,cam)}catch(e3){}}return}
 if(window.Trends&&Trends.active){try{Trends.update(dt,time)}catch(err){if(window.GSerr)GSerr('Trends.update: '+(err&&err.message));try{if(window.Museum&&Museum.heal)Museum.heal();R.render(scene,cam)}catch(e3){}}return}
 if(window.Calls&&Calls.active){try{Calls.update(dt,time)}catch(err){if(window.GSerr)GSerr('Calls.update: '+(err&&err.message));try{if(window.Museum&&Museum.heal)Museum.heal();R.render(scene,cam)}catch(e3){}}return}
 if(window.Details&&Details.active){try{Details.update(dt,time)}catch(err){if(window.GSerr)GSerr('Details.update: '+(err&&err.message));try{if(window.Museum&&Museum.heal)Museum.heal();R.render(scene,cam)}catch(e3){}}return}
 if(window.Museum&&Museum.active){try{Museum.update(dt,time)}catch(err){if(window.GSerr)GSerr('Museum.update: '+(err&&err.message));try{if(window.Museum&&Museum.heal)Museum.heal();R.render(scene,cam)}catch(e3){}}return}
 if(intro<1)intro=Math.min(1,intro+dt/4.2);
 sx+=(nx-sx)*.04;sy+=(ny-sy)*.04;
 let dol=0;if(seq){seqUpdate(dt);dol=seq.dol||0}
 else{const p=.1+.09*Math.sin(time*2.2);doorM.emissiveIntensity=insetM.emissiveIntensity=p;doorL.intensity=1.3+(p-.1)*3;
  glass.emissiveIntensity=.1+.03*Math.sin(time*.7)}
 const par=reduce?0:(1-dol), drift=reduce?0:Math.sin(time*.16)*.4, e=1-Math.pow(1-intro,3);
 const px=P0.x+(sx*2.2+drift)*par,py=P0.y-sy*.7*par,pz=P0.z+(1-e)*7*(reduce?0:1);
 cam.position.set(px+(P1.x-px)*dol,py+(P1.y-py)*dol,pz+(P1.z-pz)*dol);
 cam.lookAt(L0.x+(L1.x-L0.x)*dol+sx*.6*par,L0.y+(L1.y-L0.y)*dol-sy*.4*par,L0.z+(L1.z-L0.z)*dol);View.apply(cam,dt,!!seq);
 if(!reduce){stars.rotation.y=time*.003;stars.material.opacity=.82+.1*Math.sin(time*.9);
  fogS.forEach(s=>{s.position.x+=s.userData.v*dt;if(s.position.x>45)s.position.x=-45});
  const a=dust.geometry.attributes.position;for(let i=0;i<DN;i++){let y=a.array[i*3+1]+dt*(.12+(i%3)*.06);if(y>14)y=0;a.array[i*3+1]=y;a.array[i*3]+=Math.sin(time*.3+i)*dt*.05}a.needsUpdate=true}
 if(!reduce)fountain(time);
 try{R.render(scene,cam)}catch(err){if(window.GSerr)GSerr('render: '+(err&&err.message))}}
requestAnimationFrame(t=>{last=t;try{tick(t)}catch(err){console.error(err)}veil.style.opacity=0});
