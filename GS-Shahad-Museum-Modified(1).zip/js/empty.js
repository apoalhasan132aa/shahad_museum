/* القسم 08 — THE EMPTY HALL (قاعة الذكريات التي لم تُكتب بعد) */
window.Empty=(()=>{
const S={active:false},C=CONTENT.empty,ex={},hits=[],viewed=new Set(),tp=new T.Vector3(),tl=new T.Vector3(),look=new T.Vector3(0,3,-14),zs=[6,0,-8,-15,-22,-28],wishPos=new T.Vector3(0,3.7,-33);
let grp,focus=null,si=0,ti=0,nb,pb2,fc=0,ch5=1,intro=0,introT=0,cine,lightP,lightGlow,wishCard=null,wishTex=null,exitGlow,dust=[],exitHit=null,exBtn=null,msgBtn=null;galleryFrames=[],galleryMsg=null;
const gt=document.getElementById('gt'),gh=document.getElementById('gh');
const say=m=>{gh.textContent=m||C.hint};
const nav=()=>{nb.style.display=(si<zs.length-1&&!intro)?'block':'none';pb2.style.display=(si>0&&!intro)?'block':'none'},go=d=>{if(focus||intro)return;si=Math.max(0,Math.min(zs.length-1,si+d));nav()};
function mkb(t,css,fn){const b=document.createElement('button');b.className='go';b.textContent=t;b.style.cssText='position:fixed;bottom:calc(140px + env(safe-area-inset-bottom,0px));background:rgba(12,8,22,.6);z-index:3;display:none;'+css;b.onclick=fn;document.body.appendChild(b);return b}
const LS={get wish(){try{return localStorage.getItem('gs_wish')}catch(e){return null}},set wish(v){try{localStorage.setItem('gs_wish',v)}catch(e){}},get seen(){try{return localStorage.getItem('gs_eh_seen')==='1'}catch(e){return false}},set seen(v){try{localStorage.setItem('gs_eh_seen',v?'1':'0')}catch(e){}}};
function buildCine(){if(cine)return;cine=document.createElement('div');cine.style.cssText='position:fixed;inset:0;z-index:7;display:none;align-items:center;justify-content:center;pointer-events:none;background:rgba(4,3,8,.25)';const t=document.createElement('div');t.id='ehCine';t.style.cssText='color:#f0ecf2;font:italic 400 clamp(18px,3vw,26px)/1.8 "Cormorant Garamond","Amiri",serif;text-align:center;max-width:620px;padding:0 24px;opacity:0;transition:opacity 1.6s ease;text-shadow:0 2px 30px rgba(0,0,0,.8)';cine.appendChild(t);document.body.appendChild(cine)}
function cineText(txt){const t=document.getElementById('ehCine');t.style.opacity=0;setTimeout(()=>{t.textContent=txt;t.style.opacity=1},900)}
function endIntro(){if(!intro)return;intro=0;cine.style.opacity=0;setTimeout(()=>{cine.style.display='none';cine.style.opacity=1},1200);LS.seen=true;nav();say()}
// ==== واجهة الأمنية والرسائل ====
function buildOv(){if(window.__ehOv)return;const o=document.createElement('div');o.id='ehOv';window.__ehOv=o;
 o.style.cssText='position:fixed;inset:0;z-index:8;display:none;align-items:center;justify-content:center;background:rgba(4,3,9,.62);backdrop-filter:blur(3px);padding:16px';
 const card=document.createElement('div');card.style.cssText='max-width:540px;width:100%;max-height:78vh;overflow-y:auto;background:linear-gradient(170deg,rgba(26,22,38,.97),rgba(12,10,20,.97));border:1px solid rgba(185,155,255,.3);border-radius:14px;padding:24px 22px 18px;direction:rtl;text-align:center;box-shadow:0 0 50px rgba(185,155,255,.1)';
 card.innerHTML=`<div id="ehT" style="color:#f2a4c6;font:700 14px 'Space Grotesk',sans-serif;letter-spacing:2px;margin-bottom:10px;direction:ltr"></div><div id="ehB" style="color:#efeaf0;font:400 clamp(16px,2.2vw,19px)/1.9 'Cormorant Garamond','Amiri',serif"></div><div id="ehR" style="margin-top:16px;display:flex;gap:10px;justify-content:center;flex-wrap:wrap"></div>`;
 o.appendChild(card);document.body.appendChild(o);
 o.addEventListener('click',e=>{if(e.target===o)closeOv()});
 window.addEventListener('keydown',e=>{if(e.key==='Escape'&&o.style.display=='flex'&&o.dataset.k!=='locked')closeOv()})}
function showOv(title,bodyHTML,buttons,locked){buildOv();const o=window.__ehOv;o.dataset.k=locked?'locked':'';document.getElementById('ehT').textContent=title;document.getElementById('ehB').innerHTML=bodyHTML;const r=document.getElementById('ehR');r.innerHTML='';
 buttons.forEach(b=>{const btn=document.createElement('button');btn.textContent=b.t;btn.style.cssText='background:'+(b.p?'rgba(255,95,168,.16);border:1px solid #ec5f9d;color:#f6dbe6':'rgba(185,155,255,.1);border:1px solid rgba(185,155,255,.5);color:#d9d2ee')+';border-radius:20px;padding:9px 20px;font:600 15px "Cormorant Garamond",serif;cursor:pointer';btn.onclick=b.fn;r.appendChild(btn)});
 o.style.display='flex'}
function closeOv(){const o=window.__ehOv;if(o)o.style.display='none';if(focus!=='light'||true)focus=null}
function btnStyle(p){return 'background:'+(p?'rgba(255,95,168,.16);border:1px solid #ec5f9d;color:#f6dbe6':'rgba(185,155,255,.1);border:1px solid rgba(185,155,255,.5);color:#d9d2ee')+';border-radius:20px;padding:9px 20px;font:600 15px "Cormorant Garamond",serif;cursor:pointer'}
// نافذة نقطة الضوء
function lightOv(){const L=C.light;focus='light';
 showOv(L.title,'<p style="margin:0 0 6px">'+L.text+'</p>',[
  {t:C.letter.open,p:false,fn:()=>{letterOv()}},
  {t:L.wish,p:true,fn:()=>{wishOv()}},
  {t:C.wishUI.close,p:false,fn:()=>closeOv()}])}
// الرسالة الرئيسية
function letterOv(){const L=C.letter;
 showOv(L.title,'<p style="text-align:right;margin:0 0 12px">'+L.text+'</p><p style="color:#b39df0;letter-spacing:1px;font-style:normal;font-family:\'Space Grotesk\',sans-serif;font-size:12px;margin:0">'+L.sign+'</p>',[{t:C.wishUI.close,p:false,fn:()=>closeOv()}],true)}
// واجهة الأمنية
function wishOv(){const W=C.wishUI,w=LS.wish;
 if(w){showOv(W.exists,'<p style="margin:0;font-size:1.15em">«'+w.replace(/</g,'&lt;')+'»</p>',[
  {t:W.del,p:false,fn:()=>{LS.wish=null;removeCard();wishOv()}},
  {t:W.close,p:true,fn:()=>closeOv()}]);return}
 showOv(W.title,'<p style="margin:0 0 10px">'+W.q+'</p><textarea id="ehTa" maxlength="'+W.max+'" rows="3" placeholder="'+W.ph+'" style="width:100%;box-sizing:border-box;background:rgba(255,255,255,.06);border:1px solid rgba(185,155,255,.4);border-radius:10px;color:#f2effa;font:400 17px/1.7 "Cormorant Garamond","Amiri",serif;padding:10px 12px;direction:rtl;resize:none"></textarea><div id="ehWarn" style="color:#f2a4c6;font-size:13px;min-height:18px;margin-top:4px"></div>',[
  {t:W.seal,p:true,fn:()=>{const v=(document.getElementById('ehTa').value||'').trim();
   if(!v){document.getElementById('ehWarn').textContent=W.empty;return}
   LS.wish=v;makeCard(v);viewed.add('wish');
   showOv(W.saved,'<p style="margin:0;color:#cfcbe4">'+W.savedSub+'</p>',[{t:W.close,p:true,fn:()=>closeOv()}])}},
  {t:W.notNow,p:false,fn:()=>closeOv()}])}
// بطاقة الأمنية فوق المنصة
function makeCard(v){if(!grp)return;
 if(!wishCard){const c=document.createElement('canvas');c.width=256;c.height=160;wishTex={c,x:c.getContext('2d'),tex:new T.CanvasTexture(c)};wishTex.tex.encoding=T.sRGBEncoding;
  wishCard=new T.Mesh(new T.PlaneGeometry(1.5,.94),new T.MeshBasicMaterial({map:wishTex.tex,transparent:true,side:T.DoubleSide}));wishCard.position.copy(wishPos);grp.add(wishCard);
  const gl2=new T.Sprite(new T.SpriteMaterial({map:GT,color:0xffc9e2,opacity:.3,transparent:true,depthWrite:false,blending:T.AdditiveBlending}));gl2.scale.set(2.6,2.6,1);gl2.position.copy(wishPos);grp.add(gl2)}
 const x=wishTex.x;x.clearRect(0,0,256,160);
 const g=x.createLinearGradient(0,0,0,160);g.addColorStop(0,'#2a2140');g.addColorStop(1,'#161022');x.fillStyle=g;x.fillRect(0,0,256,160);
 x.strokeStyle='#f2a4c6';x.lineWidth=2;x.strokeRect(5,5,246,150);
 x.fillStyle='#f6dbe6';x.font='700 11px "Space Grotesk",sans-serif';x.textAlign='center';x.fillText('A MEMORY NOT YET MADE',128,26);
 x.fillStyle='#f0ecf2';x.font='italic 400 15px "Cormorant Garamond","Amiri",serif';
 const words=v.split(' ');let line='',yy=56;for(const wd of words){if(x.measureText(line+wd).width>216){x.fillText(line,128,yy);yy+=22;line=''}line+=wd+' '}x.fillText(line,128,yy);
 x.fillStyle='#b39df0';x.font='400 10px "Space Grotesk",sans-serif';x.fillText('· GS ·',128,144);x.textAlign='left';
 wishTex.tex.needsUpdate=true;wishCard.visible=true;wishCard.userData.ph=0}
function removeCard(){if(wishCard)wishCard.visible=false}
function restoreCard(){const w=LS.wish;if(w&&grp)makeCard(w)}
function finish(){closeOv();focus=null;veil.style.transition='opacity 1.8s ease';veil.style.background='#040410';veil.style.opacity=1;setTimeout(()=>{S.hide();Sky.enter()},1900)}
// ==== معرض صور الغرفة الفارغة ====
function buildGallery(){const G=C.gallery||[];
 galleryFrames.forEach(fr=>grp.remove(fr.g));galleryFrames=[];if(galleryMsg){grp.remove(galleryMsg);galleryMsg=null}
 if(!G.length){const c=document.createElement('canvas');c.width=512;c.height=256;const x=c.getContext('2d');
  const g=x.createLinearGradient(0,0,0,256);g.addColorStop(0,'#221c38');g.addColorStop(1,'#141022');x.fillStyle=g;x.fillRect(0,0,512,256);
  x.strokeStyle='rgba(216,183,136,.7)';x.lineWidth=3;x.strokeRect(10,10,492,236);
  x.fillStyle='#f2ead9';x.font='400 30px "Cormorant Garamond","Amiri",serif';x.textAlign='center';x.direction='rtl';
  x.fillText('هذه المساحة مخصصة لصوركن الجميلة',256,118);
  x.fillStyle='#b8a8cf';x.font='400 22px "Cormorant Garamond","Amiri",serif';
  x.fillText('تُضاف الصور من قائمة الغاليري في ملف المحتوى',256,168);
  const t=new T.CanvasTexture(c);t.encoding=T.sRGBEncoding;
  const m=new T.Mesh(new T.PlaneGeometry(4.6,2.3),new T.MeshBasicMaterial({map:t,transparent:true}));
  m.position.set(12.4,4.6,-24);m.rotation.y=-Math.PI/2;grp.add(m);
  const gl=new T.Sprite(new T.SpriteMaterial({map:GT,color:0xd8b788,opacity:.14,transparent:true,depthWrite:false,blending:T.AdditiveBlending}));gl.scale.set(6,4,1);gl.position.set(12.1,4.6,-24);grp.add(gl);
  galleryMsg=new T.Group();galleryMsg.add(m);galleryMsg.add(gl);grp.add(galleryMsg);
  const h=new T.Mesh(new T.SphereGeometry(2.6,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));h.position.set(11.8,4.2,-24);h.userData.id='galmsg';grp.add(h);hits.push(h);ex.galmsg=new T.Vector3(11.8,0,-24);
  return}
 G.forEach((item,ix)=>{const path=typeof item==='string'?item:item.img;
  const cap=typeof item==='string'?'':(item.caption||'');
  const side=ix%2?1:-1,z=3-ix*7,x=side*10.4;
  const g=new T.Group();g.position.set(x,4.1,z);g.rotation.y=side<0?Math.PI/2:-Math.PI/2;grp.add(g);
  const sil=M(0xd8b788,.35,.8);
  const b=(w,h,d,m,px,py,pz)=>{const k=new T.Mesh(new T.BoxGeometry(w,h,d),m);k.position.set(px,py,pz);g.add(k);return k};
  b(2.5,3.1,.1,sil,0,0,-.04);b(2.3,2.9,.06,M(0x14101e,.6,.2),0,0,0);
  const pl=new T.Mesh(new T.PlaneGeometry(2.14,2.74),new T.MeshBasicMaterial({color:0x0c0916}));pl.position.z=.05;g.add(pl);
  const lb=Museum.lab(cap||('PHOTO '+(ix+1)),2);lb.scale.set(2.2,.5,1);lb.position.set(0,-1.85,.1);g.add(lb);
  const h=new T.Mesh(new T.SphereGeometry(2,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));h.position.set(0,0,.6);h.userData.id='gal'+ix;g.add(h);hits.push(h);ex['gal'+ix]=new T.Vector3(x,0,z);
  const fr={g,pl,path,cap};galleryFrames.push(fr);
  const im=new Image();im.onload=()=>{const cv=document.createElement('canvas');cv.width=im.naturalWidth;cv.height=im.naturalHeight;const cx=cv.getContext('2d');cx.drawImage(im,0,0);
   const t=new T.CanvasTexture(cv);t.encoding=T.sRGBEncoding;fr.pl.material.map=t;fr.pl.material.color.set(0xffffff);fr.pl.material.needsUpdate=true};
  im.onerror=()=>{grp.remove(g);const hi=hits.indexOf(h);if(hi>=0)hits.splice(hi,1);if(ex['gal'+ix])delete ex['gal'+ix]};
  im.src=path})}
// ==== بناء المشهد ====
function build(){
 grp=new T.Group();scene.add(grp);const r=rnd(31),add=(m,x,y,z)=>{m.position.set(x,y,z);grp.add(m);return m},mk=(w,h,d,m,x,y,z)=>add(new T.Mesh(new T.BoxGeometry(w,h,d),m),x,y,z);
 const marble=M(0x2a2e3c,.28,.5),marble2=M(0x343949,.32,.45),sil=M(0xc3c5da,.22,.9),gold=M(0x9a7c40,.35,.8,0x1a1206);
 const wallM=M(0x2b3040,.7,.25),panelM=M(0x363d52,.6,.3);
 const glow=(c,op,s,x,y,z,p)=>{const q=new T.Sprite(new T.SpriteMaterial({map:GT,color:c,opacity:op,transparent:true,depthWrite:false,blending:T.AdditiveBlending}));q.scale.set(s,s,1);q.position.set(x,y,z);(p||grp).add(q);return q};
 const beam=(c,x,z,ry=0)=>{const b=new T.Mesh(new T.ConeGeometry(2.6,9,20,1,true),new T.MeshBasicMaterial({color:c,transparent:true,opacity:.05,blending:T.AdditiveBlending,depthWrite:false,side:T.DoubleSide}));b.position.set(x,8.4,z);b.rotation.x=Math.PI;b.rotation.y=ry;grp.add(b)};
 // أرضية رخامية فاخرة بخطوط فضية
 add(new T.Mesh(new T.PlaneGeometry(26,52),new T.MeshStandardMaterial({color:0x272b38,roughness:.22,metalness:.5,bumpMap:NT,bumpScale:.035})),0,0,-16).rotation.x=-Math.PI/2;
 const aisle=add(new T.Mesh(new T.PlaneGeometry(5,48),new T.MeshStandardMaterial({color:0x3a415a,roughness:.16,metalness:.55,bumpMap:NT,bumpScale:.03})),0,.012,-16);aisle.rotation.x=-Math.PI/2;
 [-2.7,2.7].forEach(x=>mk(.1,.02,48,gold,x,.02,-16));
 for(let z=6;z>-40;z-=4)mk(5.4,.015,.1,sil,0,.015,z);
 // جدران بألواح فاخرة وإطارات فضية
 mk(.5,13,52,wallM,-13.2,6.5,-16);mk(.5,13,52,wallM,13.2,6.5,-16);mk(26.5,13,.5,wallM,0,6.5,-42.2);mk(26.5,13,.5,M(0x232838,.75,.2),0,6.5,10.2);mk(26.5,.5,52,M(0x10121b,.92),0,13.2,-16);
 [-1,1].forEach(s=>{for(let z=4;z>-40;z-=6){mk(.14,9.5,.14,sil,s*12.9,4.75,z);mk(1.6,3.2,.1,panelM,s*12.9,4.4,z-3);
  mk(1.8,3.4,.06,sil,s*12.92,4.4,z-3);mk(.05,2.8,.05,z%2?gold:sil,s*12.8,4.4,z-3);
  const gp=glow(0x8a7fd4,.12,3,s*12.6,4.4,z-3);gp.material.opacity=.1}});
 // سقف معشق + ثريا كريستالية على طول القاعة
 for(let z=6;z>-40;z-=6){mk(26,.18,.24,sil,0,12.9,z);[-1,1].forEach(s=>mk(.24,.18,5.6,sil,s*6,12.9,z-3))}
 const chand=(z)=>{const c=new T.Group();c.position.set(0,10.6,z);grp.add(c);
  const r1=new T.Mesh(new T.TorusGeometry(1.5,.05,8,40),gold);r1.rotation.x=Math.PI/2;c.add(r1);
  const r2=new T.Mesh(new T.TorusGeometry(.9,.04,8,32),sil);r2.rotation.x=Math.PI/2;r2.position.y=-.5;c.add(r2);
  mk2(0,.5,0,c);const cr=new T.Mesh(new T.OctahedronGeometry(.28,0),new T.MeshBasicMaterial({color:0xfff0f8}));cr.position.y=-1;c.add(cr);
  for(let k=0;k<8;k++){const a=k/8*Math.PI*2;const ch=new T.Mesh(new T.OctahedronGeometry(.1,0),new T.MeshBasicMaterial({color:0xe8d9ff}));ch.position.set(Math.cos(a)*1.5,-.25,Math.sin(a)*1.5);c.add(ch)}
  glow(0xd9c2ff,.2,3.4,0,-.6,0,c);beam(0xb9a8e8,0,z);return c};
 function mk2(x,y,z,p){const k=new T.Mesh(new T.CylinderGeometry(.03,.03,1.6,6),sil);k.position.set(x,y,z);p.add(k);return k}
 chand(-6);chand(-22);
 const amb2=new T.PointLight(0xcfc0ee,.45,30,2);amb2.position.set(0,9.5,-6);grp.add(amb2);
 const amb3=new T.PointLight(0xcfc0ee,.45,30,2);amb3.position.set(0,9.5,-22);grp.add(amb3);
 // أعمدة ملكية: قاعدة مزدوجة، جذع مخدد (أسطوانات متراصة)، تاج ذهبي
 [-1,1].forEach(s=>{for(let z=4;z>-40;z-=8.8){
  mk(1.5,.4,1.5,marble2,s*10.6,.2,z);mk(1.2,.35,1.2,marble,s*10.6,.55,z);mk(1.05,.25,1.05,gold,s*10.6,.85,z);
  for(let k=0;k<3;k++)mk(.8-k*.08,3.2,.8-k*.08,marble,s*10.6,2.6+k*3.2,z);
  mk(1,0.22,1,gold,s*10.6,6.4,z);mk(1.1,.3,1.1,marble2,s*10.6,9.7,z);mk(1.35,.28,1.35,gold,s*10.6,9.95,z);
  const a=new T.Mesh(new T.TorusGeometry(2.1,.08,8,26,Math.PI),sil);a.position.set(s*10.55,8.8,z-4.4);a.rotation.y=s<0?Math.PI/2:-Math.PI/2;grp.add(a)}});
 // ==== منصة الضوء الملكية ====
 const pg2=new T.Group();pg2.position.set(0,0,-33);grp.add(pg2);
 const pb=(w,h,d,m,x,y,z)=>{const k=new T.Mesh(new T.BoxGeometry(w,h,d),m);k.position.set(x,y,z);pg2.add(k);return k};
 const cyl=(r1,h,m,x,y,z)=>{const k=new T.Mesh(new T.CylinderGeometry(r1,r1*1.06,h,32),m);k.position.set(x,y,z);pg2.add(k);return k};
 cyl(3.2,.34,marble2,0,.17,0);cyl(2.5,.3,marble,0,.49,0);cyl(1.8,.26,sil,0,.77,0);
 const runeRing=new T.Mesh(new T.TorusGeometry(1.45,.045,8,56),gold);runeRing.rotation.x=Math.PI/2;runeRing.position.y=.92;pg2.add(runeRing);
 for(let k=0;k<12;k++){const a=k/12*Math.PI*2;const rn=new T.Mesh(new T.BoxGeometry(.16,.05,.08),gold);rn.position.set(Math.cos(a)*1.45,.92,Math.sin(a)*1.45);rn.rotation.y=-a;pg2.add(rn)}
 const colP=new T.Mesh(new T.CylinderGeometry(.16,.22,1.5,12),sil);colP.position.set(0,1.65,0);pg2.add(colP);
 const cup=new T.Mesh(new T.CylinderGeometry(.42,.28,.24,12),gold);cup.position.set(0,2.5,0);pg2.add(cup);
 lightP=new T.Mesh(new T.OctahedronGeometry(.38,0),new T.MeshBasicMaterial({color:0xfff4fa}));lightP.position.set(0,2.95,0);pg2.add(lightP);
 lightGlow=glow(0xffd9ec,.55,5.5,0,2.95,0,pg2);glow(0xb99bff,.25,7.5,0,2.95,-.5,pg2);
 const pl=new T.PointLight(0xffe9f4,1.1,28,2);pl.position.set(0,3.4,-33);grp.add(pl);
 for(let i=0;i<10;i++){const s2=glow(0xffd9ec,.5,.1,(r()-.5)*1.8,2.4+r()*1.4,(r()-.5)*1.8,pg2);dust.push({s:s2,ph:r()*6.283,rad:.3+r()*.5,sp:.4+r()*.6})}
 const lh=new T.Mesh(new T.SphereGeometry(2.1,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));lh.position.set(0,2.4,0);lh.userData.id='light';pg2.add(lh);hits.push(lh);ex.light=new T.Vector3(0,0,-33);
 // ==== قاعدة بلا تمثال — نسخة فاخرة ====
 const pd=new T.Group();pd.position.set(-9,0,-14);pd.rotation.y=.5;grp.add(pd);
 const qb=(w,h,d,m,x,y,z)=>{const k=new T.Mesh(new T.BoxGeometry(w,h,d),m);k.position.set(x,y,z);pd.add(k);return k};
 qb(2,.28,2,marble2,0,.14,0);qb(1.5,.24,1.5,marble,0,.4,0);qb(1.1,1.15,1.1,marble2,0,1.1,0);
 qb(1.4,.16,1.4,sil,0,1.75,0);qb(.9,.14,.9,marble,0,1.9,0);
 const pv=glow(0xb99bff,.12,2.6,0,2.2,0,pd);
 const ph=new T.Mesh(new T.SphereGeometry(2,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));ph.position.set(0,1.2,0);ph.userData.id='pedestal';pd.add(ph);hits.push(ph);ex.pedestal=new T.Vector3(-9,0,-14);
 // ==== إطار بلا صورة — إطار ذهبي مهيب ====
 const fr=new T.Group();fr.position.set(12.9,4.6,-24);fr.rotation.y=-Math.PI/2;grp.add(fr);
 const fb=(w,h,d,m,x,y,z)=>{const k=new T.Mesh(new T.BoxGeometry(w,h,d),m);k.position.set(x,y,z);fr.add(k);return k};
 fb(3.4,4.4,.2,gold,0,0,0);fb(3,.4,.26,gold,0,2.2,0);fb(3,.4,.26,gold,0,-2.2,0);fb(.4,4,.26,gold,-1.7,0,0);fb(.4,4,.26,gold,1.7,0,0);
 const fv=glow(0xd9c2ff,.2,4.2,0,0,.3,fr);
 fv.material.opacity=.18;
 const fh=new T.Mesh(new T.SphereGeometry(2.4,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));fh.userData.id='frame';fr.add(fh);hits.push(fh);ex.frame=new T.Vector3(12.9,0,-24);
 // ==== النقش الأرضي — خط زمني مفتوح بفخامة ====
 const tl2=new T.Group();tl2.position.set(0,0,-20);grp.add(tl2);
 const line=new T.Mesh(new T.PlaneGeometry(14,.14),new T.MeshBasicMaterial({color:0xa9acc4,transparent:true,opacity:.55}));line.rotation.x=-Math.PI/2;line.position.y=.03;tl2.add(line);
 [['mark1',-5,'WHAT WAS'],['mark2',0,'WHAT IS'],['mark3',5,'WHAT MAY BE']].forEach(a=>{const ring=new T.Mesh(new T.TorusGeometry(.6,.06,8,36),gold);ring.rotation.x=Math.PI/2;ring.position.set(a[1],.05,0);tl2.add(ring);
  const dot=new T.Mesh(new T.CircleGeometry(.2,20),new T.MeshBasicMaterial({color:0xffd9ec}));dot.rotation.x=-Math.PI/2;dot.position.set(a[1],.045,0);tl2.add(dot);
  const lb=Museum.lab(a[2],2.2);lb.scale.set(2.6,.55,1);lb.position.set(a[1],.08,1.3);lb.rotation.x=-Math.PI/2;tl2.add(lb);
  const hh=new T.Mesh(new T.SphereGeometry(1.5,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));hh.position.set(a[1],.5,0);hh.userData.id=a[0];tl2.add(hh);hits.push(hh);ex[a[0]]=new T.Vector3(a[1],0,-20)});
 // ==== بوابة المخرج المهيبة ====
 const eg=new T.Group();eg.position.set(0,0,-41);grp.add(eg);
 const egb=(w,h,d,m,x,y,z)=>{const k=new T.Mesh(new T.BoxGeometry(w,h,d),m);k.position.set(x,y,z);eg.add(k);return k};
 egb(1.2,10,1.4,marble2,-3.2,5,0);egb(1.2,10,1.4,marble2,3.2,5,0);
 const ea=new T.Mesh(new T.TorusGeometry(3.2,.5,10,44,Math.PI),marble);ea.position.set(0,10,0);eg.add(ea);
 [-1,1].forEach(s=>{const gr2=new T.Mesh(new T.TorusGeometry(.3,.07,8,22),gold);gr2.position.set(s*3.2,8.4,.2);eg.add(gr2)});
 exitGlow=glow(0xcfc4ee,0,7,0,3.4,.4,eg);
 const doorLight=new T.Mesh(new T.PlaneGeometry(4.6,8),new T.MeshBasicMaterial({color:0x0c0e18,transparent:true,opacity:.94}));doorLight.position.set(0,4.4,.1);eg.add(doorLight);
 const exl=new T.PointLight(0xcfc4ee,0,22,2);exl.position.set(0,3.6,-40);grp.add(exl);exitGlow.userData.l=exl;
 const eh=new T.Mesh(new T.SphereGeometry(3.6,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));eh.position.set(0,3.6,.6);eh.userData.id='exit';eg.add(eh);hits.push(eh);ex.exit=new T.Vector3(0,0,-40);exitHit=eh;
 // غبار فضي قليل
 const MN=mobile?40:90,mp=new Float32Array(MN*3);for(let i=0;i<MN;i++)mp.set([(r()-.5)*24,r()*11,8-r()*48],i*3);
 grp.add(new T.Points(new T.BufferGeometry().setAttribute('position',new T.BufferAttribute(mp,3)),new T.PointsMaterial({map:GT,size:.08,color:0xd9dbee,transparent:true,opacity:.2,depthWrite:false,blending:T.AdditiveBlending})));
 // إضاءة عامة هادئة
 const amb=new T.PointLight(0xb9c0e8,.5,44,2);amb.position.set(0,10,-10);grp.add(amb);
 const l2=new T.PointLight(0xd9c2ff,.4,40,2);l2.position.set(0,10,-30);grp.add(l2);
 // المقدمة السينمائية
 buildCine()}
function startIntro(){intro=1;introT=0;cine.style.display='flex';cine.style.opacity=1;nav();
 cam.position.set(0,3.2,7.6);look.set(0,3,-14);
 setTimeout(()=>{if(intro)cineText(C.intro1)},900);
 setTimeout(()=>{if(intro)cineText(C.intro2)},5600);
 setTimeout(()=>{if(intro)cineText(C.intro3)},10300);
 setTimeout(()=>{endIntro()},16000)}
return Object.assign(S,{
 reset(){viewed.clear();if(int)endIntro();closeOv();if(grp)buildGallery()},
 enter(){if(!grp){build();nb=mkb('تقدّمي ‹','left:calc(50% + 8px)',()=>go(1));pb2=mkb('› رجوع','right:calc(50% + 8px)',()=>go(-1));buildOv()}
  if(!exBtn)exBtn=mkb('تابعي ‹','left:calc(50% + 8px);bottom:calc(205px + env(safe-area-inset-bottom,0px));border-color:#b39df0;color:#e2d9ff',()=>{if(viewed.has('light'))finish()});
  if(!msgBtn)msgBtn=mkb('✦ الرسالة','right:calc(50% + 8px);bottom:calc(205px + env(safe-area-inset-bottom,0px));border-color:#f2a4c6;color:#f6dbe6',()=>{if(viewed.has('light')&&!focus&&!intro)lightOv()});
  View.reset();S.active=true;fogS.forEach(f=>f.visible=false);const h=scene.children.find(o=>o.isHemisphereLight);if(h){ch5=h.intensity;h.intensity=.3}grp.visible=true;buildGallery();
  scene.fog.color.set(0x11131c);scene.fog.near=20;scene.fog.far=90;si=0;focus=null;ti=0;restoreCard();
  veil.style.transition='background .9s ease, opacity 2.4s ease 2.4s';veil.style.background='#0a0b12';veil.style.opacity=0;
  gh.classList.add('on');gt.innerHTML='<b>'+C.title+'</b><i>'+C.sub+'</i>';gt.classList.remove('show');void gt.offsetWidth;gt.classList.add('show');
  if(!LS.seen)startIntro();else{intro=0;say();setTimeout(()=>{if(S.active)nav()},800)}},
 hide(){S.active=false;grp.visible=false;nb.style.display=pb2.style.display='none';if(exBtn)exBtn.style.display='none';if(msgBtn)msgBtn.style.display='none';gh.classList.remove('on');gt.classList.remove('show');closeOv();if(intro)endIntro();const h=scene.children.find(o=>o.isHemisphereLight);if(h)h.intensity=ch5;fogS.forEach(f=>f.visible=true)},
 leave(){if(!grp)return;S.active=false;grp.visible=false;nb.style.display=pb2.style.display='none';if(exBtn)exBtn.style.display='none';if(msgBtn)msgBtn.style.display='none';gh.classList.remove('on');gt.classList.remove('show');closeOv();focus=null;if(intro)endIntro();const h=scene.children.find(o=>o.isHemisphereLight);if(h)h.intensity=ch5;fogS.forEach(f=>f.visible=true)},
 tap(e){if(intro){endIntro();return}if(window.__ehOv&&window.__ehOv.style.display=='flex')return;
  v2.set(e.clientX/innerWidth*2-1,-(e.clientY/innerHeight)*2+1);ray.setFromCamera(v2,cam);
  if(viewed.has('light')&&exitHit){const qe=ray.intersectObjects([exitHit])[0];if(qe){finish();return}}
  const q=ray.intersectObjects(hits)[0];if(!q)return;const id=q.object.userData.id;
  if(id==='light'){viewed.add('light');lightOv();return}
  if(id==='galmsg'){focus='galmsg';UI.exhibit({title:'معرض الصور',text:'هذه المساحة تنتظر صوركن. أضيفي الصور إلى مجلد assets/images/empty-hall/ واكتبي مساراتها في قائمة gallery بملف js/content.js لتظهر هنا.'},()=>{focus=null});return}
  const gm=id.match(/^gal(\d+)$/);if(gm){const fr=galleryFrames[+gm[1]];if(fr){viewed.add(id);focus=id;UI.exhibit({title:fr.cap||'ذكرى',text:'',img:fr.path},()=>{focus=null})}return}
  const it=C.items.find(x=>x.id===id);if(it){viewed.add(id);focus=id;UI.exhibit({title:it.title,text:it.text,img:it.img},()=>{focus=null})}},
 update(dt,t){sx+=(nx-sx)*.04;const f=focus&&ex[focus];ti+=dt;
  if(intro){introT+=dt;cam.position.z=7.6-introT*.24;cam.position.y=3.2+Math.sin(introT*.3)*.06;cam.position.x=sx*1.5;look.set(0,3.2,-14);cam.lookAt(look);View.apply(cam,dt,true)}
  else{if(f){if(focus==='light'){tp.set(0,2.7,-27.5);tl.set(0,1.8,-33)}else{tp.set(f.x*.32,2.8,f.z+6.4);tl.set(f.x,2.6,f.z)}}else{tp.set(sx*1.6,2.9,zs[si]);tl.set(-sx*1.6,3,zs[si]-13)}
   cam.position.lerp(tp,1-Math.exp(-dt*(ti<4?.8:2.1)));look.lerp(tl,1-Math.exp(-dt*2.3));cam.lookAt(look);View.apply(cam,dt,!!focus)}
  lightP.rotation.y+=dt*.5;lightP.position.y=2.95+Math.sin(t*.9)*.1;
  lightGlow.material.opacity=.45+.1*Math.sin(t*1.3);
  const exT=viewed.has('light')?1:0;exitGlow.material.opacity+=((exT?.4:.08)-exitGlow.material.opacity)*.04;exitGlow.userData.l.intensity=exitGlow.material.opacity*1.4;
  if(exBtn)exBtn.style.display=(exT&&!focus&&!intro)?'block':'none';
  if(msgBtn)msgBtn.style.display=(exT&&!focus&&!intro)?'block':'none';
  if(exT&&performance.now()%4600<70&&!focus)say(C.exitHint);
  if(wishCard&&wishCard.visible){wishCard.userData.ph+=dt;wishCard.position.y=wishPos.y+Math.sin(wishCard.userData.ph*.8)*.08;wishCard.rotation.y=Math.sin(wishCard.userData.ph*.5)*.3}
  if(!reduce){dust.forEach(d=>{d.ph+=dt*d.sp;d.s.position.x=Math.cos(d.ph)*d.rad;d.s.position.z=Math.sin(d.ph)*d.rad})}
  if(!intro&&!focus){/* تلميح قرب الضوء */if(Math.abs(cam.position.z+28)<3)gh.textContent=C.hint;else if(performance.now()%4000<60)say()}
  R.render(scene,cam)}
})})();