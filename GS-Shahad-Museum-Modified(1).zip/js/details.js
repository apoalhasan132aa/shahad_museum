/* القسم 03 — THE DETAILS */
window.Details=(()=>{
const S={active:false},C=CONTENT.details,L=66,ex={},hits=[],viewed=new Set(),tp=new T.Vector3(),tl=new T.Vector3(),look=new T.Vector3(0,3.5,-10),zs=[8,3,-5,-13,-21,-29,-37,-45,-53],ND=mobile?80:160;
let grp,dust3,focus=null,si=0,nb,pb2,gate,hemi,hv=1,dL,dR,ti=0,leaving=0;
const gt=document.getElementById('gt'),gh=document.getElementById('gh'),say=m=>{gh.textContent=m||`${C.hint} · ${viewed.size}/7`};
const nav=()=>{nb.style.display=si<zs.length-1?'block':'none';pb2.style.display=si>0?'block':'none'};
const go=d=>{if(focus)return;si=Math.max(0,Math.min(zs.length-1,si+d));nav()};
function mkb(t,css,fn){const b=document.createElement('button');b.className='go';b.textContent=t;b.style.cssText='position:fixed;bottom:calc(140px + env(safe-area-inset-bottom,0px));background:rgba(12,8,22,.6);z-index:3;display:none;'+css;b.onclick=fn;document.body.appendChild(b);return b}
function tx(w,h,fn,rep){const c=document.createElement('canvas');c.width=w;c.height=h;fn(c.getContext('2d'),w,h);const t=new T.CanvasTexture(c);t.wrapS=t.wrapT=T.RepeatWrapping;t.repeat.set(rep[0],rep[1]);t.anisotropy=ANISO;t.encoding=T.sRGBEncoding;return t}
function build(){
 grp=new T.Group();scene.add(grp);const r=rnd(33),o=new T.Object3D(),add=(m,x,y,z)=>{m.position.set(x,y,z);grp.add(m);return m},
 mk=(w,h,d,m,x,y,z)=>add(new T.Mesh(new T.BoxGeometry(w,h,d),m),x,y,z),trim=M(0x2c2038,.4,.5);
 const wp=tx(256,256,(x,w,h)=>{x.fillStyle='#1d1528';x.fillRect(0,0,w,h);x.strokeStyle='rgba(217,194,138,.18)';x.lineWidth=2;for(let i=0;i<2;i++)for(let j=0;j<2;j++){const cx=64+i*128,cy=64+j*128;x.beginPath();x.moveTo(cx,cy-46);x.quadraticCurveTo(cx+30,cy,cx,cy+46);x.quadraticCurveTo(cx-30,cy,cx,cy-46);x.stroke();x.beginPath();x.arc(cx,cy,8,0,6.283);x.stroke()}},[13,3]);
 const wallM=new T.MeshStandardMaterial({map:wp,bumpMap:wp,bumpScale:.8,roughness:.7,metalness:.05}),wp2=wp.clone();wp2.repeat.set(4,3);wp2.needsUpdate=true;const wallE=new T.MeshStandardMaterial({map:wp2,bumpMap:wp2,bumpScale:.8,roughness:.7,metalness:.05}),mb=M(0x8a8399,.25,.1),cry=new T.MeshBasicMaterial({color:0xfff0fa});
 const fm=tx(128,128,(x,w,h)=>{x.fillStyle='#120d19';x.fillRect(0,0,w,h);x.fillStyle='#1d1527';x.fillRect(0,0,64,64);x.fillRect(64,64,64,64);x.strokeStyle='rgba(217,194,138,.25)';x.lineWidth=2;x.strokeRect(0,0,w,h)},[8,27]);
 const glow=(c,op,s,x,y,z)=>{const q=new T.Sprite(new T.SpriteMaterial({map:GT,color:c,opacity:op,transparent:true,depthWrite:false,blending:T.AdditiveBlending}));q.scale.set(s,s,1);q.position.set(x,y,z);grp.add(q)};
 add(new T.Mesh(new T.PlaneGeometry(16,L),new T.MeshStandardMaterial({map:fm,bumpMap:fm,bumpScale:.5,roughness:.42,metalness:.1})),0,0,-23).rotation.x=-Math.PI/2;
 mk(3.2,.03,L-2,new T.MeshStandardMaterial({color:0x5a1a40,roughness:.8,emissive:0x2a0a1e}),0,.03,-23);[-1.7,1.7].forEach(x=>mk(.08,.04,L-2,pinkM,x,.05,-23));
 mk(16.5,11,.5,wallE,0,5.5,-56.25);mk(5.75,11,.5,wallE,-5.375,5.5,10.25);mk(5.75,11,.5,wallE,5.375,5.5,10.25);mk(5,3.5,.5,wallE,0,9.25,10.25);
 [-1,1].forEach(s=>{const pv=new T.Group();pv.position.set(s*2.5,0,10.3);grp.add(pv);const dd=new T.Mesh(new T.BoxGeometry(2.5,7.4,.2),M(0x0c0910,.3,.6));dd.position.set(-s*1.25,3.7,0);pv.add(dd);const ed=new T.Mesh(new T.BoxGeometry(.06,7.2,.24),pinkM);ed.position.set(-s*1.25,3.7,0);pv.add(ed);if(s<0)dL=pv;else dR=pv});
 const ea=new T.Mesh(new T.TorusGeometry(2.5,.08,8,32,Math.PI),pinkM);add(ea,0,7.5,10.35);const el=Museum.lab('THE DETAILS',9.7);el.position.set(0,9.7,10.6);grp.add(el);mk(16.5,.5,L,M(0x0c0912,.9),0,11.25,-23);
 [-1,1].forEach(s=>{mk(.5,11,L,wallM,s*8.25,5.5,-23);mk(.2,.15,L,trim,s*7.9,2.35,-23);mk(.9,.5,L,trim,s*7.7,10.7,-23);mk(.15,.06,L-4,pinkM,s*2.5,10.95,-23);
  for(let i=0;i<18;i++)mk(.12,1.8,2.3,trim,s*7.95,1.3,8-i*2.9);
  [0,-8,-16,-24,-32,-40,-48,-56].forEach(z=>{mk(.5,11,.7,trim,s*7.8,5.5,z);mk(.7,.25,.9,goldM2,s*7.75,10.2,z)})});
 const co=new T.InstancedMesh(new T.BoxGeometry(2.8,.35,2.8),trim,48);for(let i=0;i<42;i++){o.position.set((i%3-1)*5,10.95,6-Math.floor(i/3)*3.8);o.updateMatrix();co.setMatrixAt(i,o.matrix)}grp.add(co);
 // chandeliers + lights
 [-2,-18,-34,-50].forEach(z=>{mk(.04,2.6,.04,goldM2,0,9.7,z);const rg=new T.Mesh(new T.TorusGeometry(1.3,.05,8,32),goldM2);rg.rotation.x=Math.PI/2;add(rg,0,8.4,z);
  for(let i=0;i<10;i++){const a=i/10*6.283;add(new T.Mesh(new T.SphereGeometry(.09,8,6),new T.MeshBasicMaterial({color:0xffe2f1})),Math.cos(a)*1.3,8.5,z+Math.sin(a)*1.3)}glow(0xffb3dc,.6,7,0,8.3,z)});
 [[0xff9fd2,-2],[0xb99bff,-14],[0xff9fd2,-26],[0xb99bff,-38],[0xff9fd2,-50]].forEach(a=>{const l=new T.PointLight(a[0],1.3,24,2);l.position.set(0,7,a[1]);grp.add(l)});
 // ---- extra detail ----
 [-1,1].forEach(s=>{[-4,-12,-20,-28,-36,-44,-52].forEach(z=>{const a=new T.Mesh(new T.TorusGeometry(3.3,.07,6,28,Math.PI),goldM2);a.rotation.y=Math.PI/2;add(a,s*7.8,6.9,z)});
  [0,-8,-16,-24,-32,-40].forEach(z=>{add(new T.Mesh(new T.CylinderGeometry(.04,.07,.5,8),goldM2),s*7.35,5.2,z);add(new T.Mesh(new T.SphereGeometry(.13,10,8),cry),s*7.35,5.6,z);glow(0xffb3dc,.55,3.2,s*7.35,5.6,z)})});
 [-2,-18,-34].forEach(z=>{[3.2,2.6,2].forEach(rd=>{const t=new T.Mesh(new T.TorusGeometry(rd,.03,6,40),goldM2);t.rotation.x=Math.PI/2;add(t,0,10.93,z)});
  const r2=new T.Mesh(new T.TorusGeometry(.7,.04,8,24),goldM2);r2.rotation.x=Math.PI/2;add(r2,0,7.9,z);add(new T.Mesh(new T.SphereGeometry(.14,10,8),goldM2),0,8.1,z);
  for(let i=0;i<20;i++){const a=i/20*6.283;add(new T.Mesh(new T.OctahedronGeometry(.07),cry),Math.cos(a)*1.3,8.15,z+Math.sin(a)*1.3)}});
 {const SN=34,sp=new T.InstancedMesh(new T.CylinderGeometry(.04,.06,1,8),goldM2,SN),sb=new T.InstancedMesh(new T.SphereGeometry(.09,10,8),goldM2,SN),rp2=new T.InstancedMesh(new T.CylinderGeometry(.025,.025,1,6).rotateX(Math.PI/2),M(0xa02060,.6),32);
  for(let i=0;i<17;i++)[-1,1].forEach((s,k)=>{o.position.set(s*1.95,.5,8-i*4);o.scale.set(1,1,1);o.updateMatrix();sp.setMatrixAt(i*2+k,o.matrix);o.position.y=1.05;o.updateMatrix();sb.setMatrixAt(i*2+k,o.matrix);if(i<16){o.position.set(s*1.95,.85,6-i*4);o.scale.set(1,1,4);o.updateMatrix();rp2.setMatrixAt(i*2+k,o.matrix)}});
  grp.add(sp,sb,rp2);o.scale.set(1,1,1)}
 [-1,1].forEach(s=>{const wm=new T.MeshBasicMaterial({color:0xd9b8ff,transparent:true,opacity:.5}),w=new T.Mesh(new T.PlaneGeometry(2.2,5.5),wm);add(w,s*6,6,-55.95);add(new T.Mesh(new T.CircleGeometry(1.1,20,0,Math.PI),wm),s*6,8.75,-55.95);
  for(let i=0;i<4;i++)mk(2.2,.04,.05,goldM2,s*6,4+i*1.1+.1,-55.9);mk(.05,7.3,.05,goldM2,s*6,6.4,-55.9);add(new T.Mesh(urnG,pale),s*5,0,-54.5).scale.setScalar(2.2)});
 for(let i=0;i<3;i++)mk(6.4-i*.4,.2,.9,trim,0,.1+i*.2,-53.4-i*.6);
 {const PT=new T.InstancedMesh(new T.SphereGeometry(1,8,6).scale(.09,.01,.06),M(0xff9fc8,.5,0,0x8a2a58),60);for(let i=0;i<60;i++){o.position.set((r()-.5)*3,.05,8-r()*62);o.rotation.set(0,r()*6,0);o.updateMatrix();PT.setMatrixAt(i,o.matrix)}o.rotation.set(0,0,0);grp.add(PT)}
 // frames
 const pc=document.createElement('canvas');pc.width=256;pc.height=336;{const x=pc.getContext('2d'),g=x.createLinearGradient(0,0,0,336);g.addColorStop(0,'#1d1428');g.addColorStop(1,'#33203f');x.fillStyle=g;x.fillRect(0,0,256,336);x.setLineDash([8,8]);x.strokeStyle='#a68bff';x.lineWidth=2;x.strokeRect(14,14,228,308);x.fillStyle='#cdb6ff';x.textAlign='center';x.font='300 22px "Cormorant Garamond",serif';if('letterSpacing' in x)x.letterSpacing='5px';x.fillText('ADD PHOTO',128,176)}
 const ptex=new T.CanvasTexture(pc);ptex.encoding=T.sRGBEncoding;
 const fr=(i,s,z)=>{const ee=C.exhibits[i],g=new T.Group();g.position.set(s*7.75,4.2,z);g.rotation.y=-s*Math.PI/2;grp.add(g);
  const b=(w,h,d,m,x,y,zz)=>{const k=new T.Mesh(new T.BoxGeometry(w,h,d),m);k.position.set(x,y,zz);g.add(k);return k};
  b(3.9,4.9,.25,trim,0,0,0);b(3.9,.12,.32,goldM2,0,2.4,0);b(3.9,.12,.32,goldM2,0,-2.4,0);b(.12,4.9,.32,goldM2,-1.9,0,0);b(.12,4.9,.32,goldM2,1.9,0,0);
  const pm=new T.MeshBasicMaterial({map:ptex,color:0xdddddd}),pl=new T.Mesh(new T.PlaneGeometry(3.3,4.3),pm);pl.position.z=.14;g.add(pl);
  if(ee.img)new T.TextureLoader().load(ee.img,t=>{t.encoding=T.sRGBEncoding;pm.map=t;pm.color.set(0xffffff);pm.needsUpdate=true});
  b(3.6,4.6,.02,M(0xeee8f2,.9),0,0,.12);[-1,1].forEach(a=>[-1,1].forEach(c2=>{const k=new T.Mesh(new T.SphereGeometry(.09,8,6),goldM2);k.position.set(a*1.9,c2*2.4,.18);g.add(k)}));
  b(3.1,.1,.85,mb,0,-3.3,.55);[-1.4,1.4].forEach(a=>[.25,.85].forEach(c2=>b(.1,.9,.1,trim,a,-3.75,c2)));
  const va=new T.Mesh(urnG,pale);va.scale.setScalar(.45);va.position.set(1.1,-3.25,.55);g.add(va);for(let i=0;i<3;i++){const fl=new T.Mesh(new T.SphereGeometry(.1,8,6),M(0xff9fc8,.5,0,0x8a2a58));fl.position.set(1.1+(i-1)*.09,-2.75+(i%2)*.05,.55+(i-1)*.05);g.add(fl)}
  const lb=Museum.lab(ee.title,-2.85);lb.scale.set(4,.76,1);lb.position.z=.7;g.add(lb);
  b(.4,.12,.5,goldM2,0,2.75,.3);const bm=new T.Mesh(new T.CylinderGeometry(.12,1.8,2.6,16,1,true),new T.MeshBasicMaterial({color:0xffd9ee,transparent:true,opacity:.07,blending:T.AdditiveBlending,depthWrite:false,side:T.DoubleSide}));bm.position.set(0,1.45,.8);g.add(bm);
  const h=new T.Mesh(new T.SphereGeometry(2.4,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));h.position.z=1.5;h.userData.id=ee.id;g.add(h);hits.push(h);ex[ee.id]=g.position};
 [[-1,-4],[1,-12],[-1,-20],[1,-28],[-1,-36],[1,-44],[-1,-48]].forEach((a,i)=>fr(i,a[0],a[1]));
 // door
 const dg=new T.Group();dg.position.set(0,0,-55.8);grp.add(dg);const db=(w,h,d,m,x,y,z)=>{const k=new T.Mesh(new T.BoxGeometry(w,h,d),m);k.position.set(x,y,z);dg.add(k)};
 [-1,1].forEach(s=>{db(2.6,7,.3,M(0x0c0910,.3,.6),s*1.35,3.5,0);db(.4,7.4,.5,goldM2,s*2.9,3.7,0);for(let j=0;j<5;j++)db(.12,.12,.06,goldM2,s*.5,.9+j*1.3,.2)});
 db(5.8,.4,.5,goldM2,0,7.2,0);const ar=new T.Mesh(new T.TorusGeometry(2.9,.1,8,32,Math.PI),pinkM);ar.position.y=7.4;dg.add(ar);
 gate=new T.Mesh(new T.PlaneGeometry(5.4,7),new T.MeshBasicMaterial({color:0xff8fcf,transparent:true,opacity:.03,blending:T.AdditiveBlending,depthWrite:false}));gate.position.set(0,3.5,.3);dg.add(gate);
 const dl=Museum.lab('THE DOOR',9.2);dg.add(dl);
 const dh=new T.Mesh(new T.SphereGeometry(4,8,6),new T.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));dh.position.set(0,3.5,3);dh.userData.id='door';dg.add(dh);hits.push(dh);ex.door=new T.Vector3(0,0,-55.8);
 // dust motes
 const dp=new Float32Array(ND*3);for(let i=0;i<ND;i++)dp.set([(r()-.5)*14,1+r()*9,8-r()*62],i*3);
 dust3=new T.Points(new T.BufferGeometry().setAttribute('position',new T.BufferAttribute(dp,3)),new T.PointsMaterial({map:GT,size:.14,color:0xffd9ee,transparent:true,opacity:.6,depthWrite:false,blending:T.AdditiveBlending}));grp.add(dust3)}
function finish(){leaving=.001;gh.classList.remove('on');nb.style.display=pb2.style.display='none'}
return Object.assign(S,{
 reset(){viewed.clear()},
 hide(){S.active=false;grp.visible=false;nb.style.display=pb2.style.display='none';gh.classList.remove('on');gt.classList.remove('show')},
 enter(){if(!grp){build();nb=mkb('تقدّمي ‹','left:calc(50% + 8px)',()=>go(1));pb2=mkb('› رجوع','right:calc(50% + 8px)',()=>go(-1))}
  View.reset();S.active=true;fogS.forEach(f=>f.visible=false);hemi=scene.children.find(o=>o.isHemisphereLight);if(hemi){hv=hemi.intensity;hemi.intensity=.3}moonL.visible=false;grp.visible=true;
  scene.fog.color.set(0x14060f);scene.fog.near=18;scene.fog.far=75;si=0;focus=null;ti=0;setTimeout(()=>{if(S.active)nav()},4300);cam.position.set(0,3.2,19);look.set(0,3.5,0);
  veil.style.transition='background .9s ease, opacity 2.4s ease 2.4s';veil.style.background='#07050d';veil.style.opacity=0;say();gh.classList.add('on');
  gt.innerHTML='<b>'+C.title+'</b><i>'+C.sub+'</i>';gt.classList.remove('show');void gt.offsetWidth;gt.classList.add('show')},
 leave(){if(!grp)return;S.active=false;grp.visible=false;fogS.forEach(f=>f.visible=true);if(hemi)hemi.intensity=hv;moonL.visible=true;nb.style.display=pb2.style.display='none';gh.classList.remove('on');gt.classList.remove('show');UI.close()},
 tap(e){if(leaving)return;v2.set(e.clientX/innerWidth*2-1,-(e.clientY/innerHeight)*2+1);ray.setFromCamera(v2,cam);const q=ray.intersectObjects(hits)[0];if(!q)return;const id=q.object.userData.id;
  if(id==='door'){if(viewed.size<7){say(C.lock);return}focus='door';UI.puzzle(C.puzzle,finish,()=>{focus=null})}
  else{focus=id;viewed.add(id);say();UI.exhibit(C.exhibits.find(x=>x.id===id),()=>{focus=null})}},
 update(dt,t){sx+=(nx-sx)*.04;const f=focus&&ex[focus];
  if(leaving){tp.set(0,3.5,-40);tl.set(0,3.6,-52)}else if(f){tp.set(f.x*.45,3.4,f.z+5);tl.set(f.x,3.7,f.z)}else{tp.set(sx*1.5,3.2,zs[si]);tl.set(-sx*1.5,3.5,zs[si]-14)}
  ti+=dt;if(!f&&ti<2.6)tp.set(0,3.2,19);const op=Math.min(1,Math.max(0,(ti-2)/2.4));dL.rotation.y=op*1.6;dR.rotation.y=-op*1.6;cam.position.lerp(tp,1-Math.exp(-dt*(ti<6?.8:2.2)));look.lerp(tl,1-Math.exp(-dt*2.5));cam.lookAt(look);View.apply(cam,dt,!!focus||!!leaving);
  gate.material.opacity=viewed.size>6?.12+.05*Math.sin(t*2):.03;
  if(leaving){leaving+=dt;gate.material.opacity=.14+.45*Math.min(1,leaving/2);veil.style.transition='none';veil.style.background='#fff0fa';veil.style.opacity=Math.max(0,Math.min(1,(leaving-1.4)/1.8));if(leaving>3.3){leaving=0;Details.hide();Calls.enter()}}
  if(!reduce){const a=dust3.geometry.attributes.position;for(let i=0;i<ND;i++){let y=a.array[i*3+1]+dt*(.1+(i%3)*.05);if(y>10)y=1;a.array[i*3+1]=y;a.array[i*3]+=Math.sin(t*.4+i)*dt*.08}a.needsUpdate=true}
  R.render(scene,cam)}
})})();
