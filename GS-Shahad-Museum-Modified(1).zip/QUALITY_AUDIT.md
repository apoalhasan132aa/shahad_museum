# QUALITY_AUDIT — GS | THE SHAHAD MUSEUM

نتائج فعلية من فحص المشروع واختباره (ليست تخمينات). تاريخ الفحص: بعد ترقية الحديقة الرومانية.

## A. Audit (ما وُجد فعلًا)
- **بنية العرض:** Renderer واحد + Scene واحد + Camera واحدة، مشتركة بين كل المشاهد (`entrance.js`). كل مشهد (Museum/Details/Calls/Trends/Places) مجموعة `THREE.Group` داخل نفس الـScene، ويُسلَّم التحكم عبر `*.active`.
- **Animation Loop:** `requestAnimationFrame(tick)` واحد فقط للرسم. `polish.js` عنده rAF ثانٍ لكنه عدّاد FPS فقط ولا يرسم. نافذة التسجيل (`UI.recording`) عندها rAF لرسم 2D داخل canvas صغير وتتوقف عند النهاية.
- **WebGL context:** واحد فقط. لا يوجد إنشاء Renderer إضافي، ولا `dispose()` على موارد مشتركة.
- **تسليم التحكم:** `tick` يوجّه التحديث للمشهد الفعّال ويعود فورًا، فلا يستمر المشهد القديم بتحديث الكاميرا.
- **سبب شاشة سوداء سابقة (مُصلَح):** `view.js` كان يحمّل قبل تعريف `T` فيفشل `View` ويتعطل أول إطار فيبقى الغطاء. تم الإصلاح، وصار رفع الغطاء محميًا بـtry/catch.
- **مشكلة حالة السماء (مُصلَحة):** تغيير السماء/الضباب/الإضاءة للغروب كان سيتسرب للقاعات التالية؛ أُضيفت `sunset(false)` في `hide()` و`leave()`.
- **المشاهد لا تُتلف بعد المغادرة (مقصود):** تبقى في الذاكرة لتسريع العودة (replay). مقبول لأن عدد المشاهد 6 فقط.

## B. Stability
- `GS.goToSection2()` صار داخل try/catch: عند فشل بناء الحديقة يظهر رسالة واضحة بدل شاشة عالقة، ويُسجَّل الخطأ في Console.
- الغطاء الأسود في الإطار الأول لا يعتمد على نجاح `tick`.

## C. ما غُيّر في الحديقة (THE GARDEN OF HER)
ممر رخامي من ألواح فردية (InstancedMesh بتباين لوني ودوران مختلف) — أعمدة كورنثية مشتركة (قاعدة + جسم مخدّد بـbump + تاج بأوراق وفولوتات) — إفريز وكورنيش ودنتيل وعوارض بيرغولا — نباتات متسلقة ووردات معلّقة — أربعة تماثيل رخامية بطيّات منحوتة — نافورة قلب بحافة مبثوقة وسماكة وماء وبتلات طافية — مجرى ماء وجسر روماني بقوس ودرابزين وأعمدة صغيرة — سماء غروب وإضاءة مفتاحية دافئة من العمق وفِل من الهيمسفير — قطة مع حركة تنفس — جزيئات وفراشات وبتلات متساقطة بكثافة تتبع وضع الجودة.

## D. أوضاع الجودة (`QL` في entrance.js)
| الوضع | الاختيار | pixel ratio | عشب | شجيرات ورد | أوراق/ورد معلّق | ظلال |
|---|---|---|---|---|---|---|
| 0 Performance | هاتف ضعيف | 1.0 | 1400 | 10 | 70 / 8 | لا |
| 1 Balanced | هاتف قوي | 1.35 | 3000 | 18 | 160 / 22 | لا |
| 2 High | كمبيوتر | 2.0 | 7000 | 34 | 280 / 40 | نعم |
يمكن فرض الوضع بـ`?q=0|1|2` في الرابط. بالإضافة لدقة تكيفية تنزل تلقائيًا إذا بطؤ الجهاز.

## E. الاختبارات
**نجحت (بمحاكاة THREE داخل Chromium بلا GPU — `qa/smoke_test.py`):**
- تحميل كل ملفات JS/CSS بدون أخطاء Console، وترتيب التحميل سليم.
- الإطارات تُرسم بعد كل انتقال والغطاء يُرفع.
- الباب → الحديقة → التفاصيل → المكالمات → الترندات → الأماكن: كل المعروضات تفتح، كل لغز يرفض الخطأ ويقبل الصحيح، والتسجيل بدون الملف يعرض زر «متابعة» بدون أخطاء.
- لا يوجد Scroll أفقي عند 390×844.
- مسار الخطأ في انتقال الحديقة (تم تفعيله بالصدفة أثناء الاختبار) أظهر رسالة وسجّل الخطأ ولم يعلّق الشاشة.
- فحص Syntax لكل ملفات JS.

**لم يُنفَّذ:**
- أي اختبار بصري أو أداء على WebGL حقيقي أو جهاز Android فعلي (المكتبة تُحمَّل من الإنترنت وبيئة العمل بلا شبكة/GPU). المحاكاة تتحقق من المنطق والتدفق فقط، **لا** من الشكل أو سرعة الرسم.
- اختبار عرض 360 و412 و768 و1024 و1440 (جُرّب 390 فقط).
- تشغيل الصوت الحقيقي (الملف غير موجود هنا).

## F. أصول خارجية يدوية
- `assets/audio/sway.mp3` (الأغنية) و`assets/audio/calls-final.mp3` (تسجيل المكالمات) — يضيفهما المستخدم.
- صور المعروضات عبر حقول `img` في `js/content.js`.

## G. تحديثات بعد الاختبار على جهاز حقيقي (من صور المستخدم)
- **عطل الرسم في الحديقة (السبب الجذري):** في Three.js r128 إذا شارك `InstancedMesh` بلا `instanceColor` مادةً رُسمت مع `instanceColor` يفشل الرسم بـ`Cannot read properties of null (reading 'isInterleavedBufferAttribute')` ويتوقف الإطار فيختفي ما يُرسم بعده. الحل: `fixInst()` في `museum.js` تعطي كل InstancedMesh نسخة مادة خاصة بنمطه. أدوات التشخيص (`heal` و`bisect` والمربع الأحمر) بقيت لتكشف أي عطل مشابه.
- **المشي في الحديقة:** عصا يسار للمشي (WASD للكيبورد)، يمين للنظر (الأسهم). تصادم مع النافورة والأعمدة والتماثيل والمعروضات والأشجار والماء، ويرتفع المستوى على الجسر. الاختبار بالمحاكاة نجح (مشي، حدود، فتح معروض أثناء المشي)، لكن لم يُجرَّب على جهاز حقيقي.

## H. Exterior refinement (V5)
- Expanded the ceremonial staircase, added fine edge trim and low side balustrades.
- Added layered column bases/capitals and vertical fluting to strengthen the classical portico silhouette.
- Added restrained rose planters, small path lanterns, and a pediment medallion as exterior-only details.
- Adjusted portrait viewport camera FOV/distance to reduce the extreme wide-angle look on tall phones.
- Restyled the entrance hint button to be less visually dominant.
- Validation: `node --check` passed for all project JavaScript files. Browser-based smoke tests could not run in this execution environment because Playwright's local HTTP navigation is blocked; visual confirmation on the target Android device is still required.


## I. Controller and fidelity refinement (V6 development pass)
- Shared texture anisotropy now respects the actual GPU limit; balanced/high modes use up to 8x anisotropy, while performance mode stays conservative.
- Pixel-ratio caps changed to 1.0 / 1.5 / 2.1 for Performance / Balanced / High; the existing adaptive FPS downscale remains enabled.
- Dual-stick controls now have clearer accessible labels, pointer-cancel/lost-capture handling, keyboard default prevention for arrow keys, and a complete neutral reset on scene transitions.
- Look sensitivity is time-based, pitch has a safe limit, yaw is wrapped during free-walk, and camera offsets are applied only after each scene's `lookAt()` call.
- Walking diagonal speed is normalized, collision checks include a player radius, the bridge height transition is smoothed, and resuming after an exhibit dialog clamps the player position safely.
- QA scripts now resolve the project and mock renderer relative to their own location instead of hard-coded `/home/claude` paths.
- Static validation: all project JavaScript files passed `node --check`; all QA Python scripts passed `py_compile`. The Playwright mock test was attempted but the execution environment blocked local browser navigation (`ERR_BLOCKED_BY_ADMINISTRATOR`), so browser-flow checks and real-device WebGL/performance remain unverified. Next mandatory check is visual testing on the target Android device.


## J. Input stability patch (V7)
- The joystick now has a 12% input dead zone. The thumb still follows the same physical range, but tiny touches near the centre are treated as neutral to reduce unintended camera drift/walking.
- A shared input-clear routine resets pressed keyboard keys and both joystick axes on window blur and `visibilitychange` to hidden, covering common Android app-switch interruptions.
- Validation: JavaScript syntax and Python QA-script compilation are checked for this archive. The Playwright browser navigation restriction remains; no claim is made that real-device visuals or FPS were verified.
