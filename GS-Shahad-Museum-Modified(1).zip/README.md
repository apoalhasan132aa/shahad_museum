# GS — The Shahad Museum

شغّلي `index.html` عبر سيرفر محلي (مثلاً `python3 -m http.server`).

- النصوص والألغاز والإجابات: `js/content.js`
- الصور: ضعي المسار في `img` داخل `content.js` (الملفات في `assets/images/`)
- الموسيقى: `assets/audio/sway.mp3`

الأقسام: الواجهة (`entrance.js`) · الحديقة (`museum.js`)

## جودة العرض
- يختار المشروع وضع جودة تلقائيًا (Performance / Balanced / High). للتجربة اليدوية أضيفي `?q=0` أو `?q=1` أو `?q=2` لرابط الصفحة.
- التفاصيل الكاملة والاختبارات في `QUALITY_AUDIT.md`. أدوات الاختبار بالمحاكاة في مجلد `qa/`.

## Exterior update (V5)
- أعمدة المدخل صارت أكثر تفصيلًا مع قواعد وتيجان وحزوز طولية مستوحاة من العمارة الكلاسيكية.
- درج أعرض مع حواف مضيئة ودرابزين جانبي.
- أحواض ورد صغيرة وفوانيس قرب طريق الدخول.
- زخرفة دائرية في أعلى الواجهة مع إضاءة هادئة.
- ضبط زاوية الكاميرا و مجال الرؤية للهواتف الطويلة حتى تبقى الواجهة أوضح.
- تحسين زر «المسي الباب» ليكون أخف بصريًا ولا ينافس المبنى.

هذه التغييرات محصورة بواجهة الخارج وملفات CSS الخاصة بها؛ بقية القاعات ومحتواها لم تُعد بناؤها.


## Control and sharpness refinement
- In the garden, left stick = walk; right stick = look. Keyboard: WASD to move, arrow keys to look. Double-tap the right stick to recenter the view.
- Renderer quality can still be selected with `?q=0`, `?q=1`, or `?q=2`; automatic FPS downscaling is preserved.
- Texture anisotropy now uses the active GPU capability (conservative in Performance mode, sharper in Balanced/High).
- `qa/` tests resolve local paths relative to this folder. Browser mock tests check flow and input logic; they do not replace real WebGL/device testing.


## V7 — Touch and input stability
- Added a 12% joystick dead zone to prevent accidental near-centre touch drift while keeping the thumb's visual travel unchanged.
- Keyboard and joystick state now clear when the page loses focus or becomes hidden, reducing stuck movement/look input after app switching on Android.
- These are input/stability changes, not a claim of new visual assets. WebGL appearance and device performance still require checking on the target device.
